#ifndef __TYPE_H
#define __TYPE_H

typedef enum
{
  FALSE = 0,
  TRUE = 1
} boolean_type;

typedef enum
{
  TABLE_SIZE_3 = 3,
  TABLE_SIZE_4 = 4,
  TABLE_SIZE_5 = 5,
  TABLE_SIZE_6 = 6
} table_size_type;
#define TABLE_SIZE_MIN TABLE_SIZE_3
#define TABLE_SIZE_DEFAULT TABLE_SIZE_MIN
#define TABLE_SIZE_MAX TABLE_SIZE_6

typedef unsigned char table_row_type;
typedef table_row_type table_type[TABLE_SIZE_MAX];

typedef struct preference_type
{
  table_size_type size;
  table_type table;
  int count;
  boolean_type hint;
  table_type hint_table;
  boolean_type sound;
  boolean_type alert_reset;
  boolean_type alert_shuttle;
  boolean_type alert_hint;
  boolean_type keep_hint_reset;
  boolean_type keep_hint_shuttle;
} preference_type;

#endif
