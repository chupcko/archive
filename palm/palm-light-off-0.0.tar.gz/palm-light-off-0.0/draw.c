#include <stdio.h>

#include "main.h"

static MemHandle bitmap_off_mh;
static BitmapPtr bitmap_off_bp;
static MemHandle bitmap_on_mh;
static BitmapPtr bitmap_on_bp;
static MemHandle bitmap_hint_off_mh;
static BitmapPtr bitmap_hint_off_bp;
static MemHandle bitmap_hint_on_mh;
static BitmapPtr bitmap_hint_on_bp;

void load_bitmaps(void)
{
  bitmap_off_mh = DmGetResource(bitmapRsc, RCP_Bitmap_Off_ID);
  bitmap_off_bp = MemHandleLock(bitmap_off_mh);
  bitmap_on_mh = DmGetResource(bitmapRsc, RCP_Bitmap_On_ID);
  bitmap_on_bp = MemHandleLock(bitmap_on_mh);
  bitmap_hint_off_mh = DmGetResource(bitmapRsc, RCP_Bitmap_Hint_Off_ID);
  bitmap_hint_off_bp = MemHandleLock(bitmap_hint_off_mh);
  bitmap_hint_on_mh = DmGetResource(bitmapRsc, RCP_Bitmap_Hint_On_ID);
  bitmap_hint_on_bp = MemHandleLock(bitmap_hint_on_mh);
}

static void draw_status(void)
{
  char buffer[100];
  Int16 buffer_length;

  buffer_length = StrPrintF(buffer, "Light Off (%dx%d) - %d", Preference.size, Preference.size, Preference.count);
  WinDrawChars(buffer, buffer_length, (RESOLUTION_X-FntCharsWidth(buffer, buffer_length))/2, 0);
}

static void draw_bitmap(int x, int y, boolean_type state, boolean_type state_hint)
{
  if(state == TRUE)
    if(Preference.hint == TRUE && state_hint == TRUE)
      WinDrawBitmap(bitmap_hint_on_bp, OFFSET_X+x*BITMAP_SIZE, OFFSET_Y+y*BITMAP_SIZE);
    else
      WinDrawBitmap(bitmap_on_bp, OFFSET_X+x*BITMAP_SIZE, OFFSET_Y+y*BITMAP_SIZE);
  else
    if(Preference.hint == TRUE && state_hint == TRUE)
      WinDrawBitmap(bitmap_hint_off_bp, OFFSET_X+x*BITMAP_SIZE, OFFSET_Y+y*BITMAP_SIZE);
    else
      WinDrawBitmap(bitmap_off_bp, OFFSET_X+x*BITMAP_SIZE, OFFSET_Y+y*BITMAP_SIZE);
}

void redraw(void)
{
  RectangleType rectangle;
  int x;
  int y;

  rectangle.topLeft.x = 0;
  rectangle.topLeft.y = 0;
  rectangle.extent.x = RESOLUTION_X;
  rectangle.extent.y = MENU_STATUS_SIZE+RESOLUTION_Y;
  WinEraseRectangle(&rectangle, 0);
  draw_status();
  for(x = 0; x < Preference.size; x++)
    for(y = 0; y < Preference.size; y++)
      draw_bitmap(x, y, get_state_table(&Preference.table, x, y), get_state_table(&Preference.hint_table, x, y));
}

void free_bitmaps(void)
{
  MemPtrUnlock(bitmap_off_bp);
  DmReleaseResource(bitmap_off_mh);
  MemPtrUnlock(bitmap_on_bp);
  DmReleaseResource(bitmap_on_mh);
  MemPtrUnlock(bitmap_hint_off_bp);
  DmReleaseResource(bitmap_hint_off_mh);
  MemPtrUnlock(bitmap_hint_on_bp);
  DmReleaseResource(bitmap_hint_on_mh);
}
