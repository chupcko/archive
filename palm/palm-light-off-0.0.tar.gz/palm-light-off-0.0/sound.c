#include <stdio.h>

#include "main.h"

void sound(void)
{
  SndCommandType sound;

  sound.cmd = sndCmdFreqDurationAmp;
  sound.param1 = 110;
  sound.param2 = 25;
  sound.param3 = Game_volume;
  SndDoCmd(NULL, &sound, true);
}
