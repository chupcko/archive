#include "main.h"

boolean_type get_state_row(table_row_type *row, int y)
{
  if((*row&0x1<<y) != 0)
    return TRUE;
  else
    return FALSE;
}

boolean_type get_state_table(table_type *table, int x, int y)
{
  if(((*table)[x]&0x1<<y) != 0)
    return TRUE;
  else
    return FALSE;
}

void turn_off_state_table(table_type *table, int x, int y)
{
  (*table)[x] &= ~(0x1<<y);
}

void turn_on_state_table(table_type *table, int x, int y)
{
  (*table)[x] |= 0x1<<y;
}

void turn_off_table(table_size_type size, table_type *table)
{
  int x;

  for(x = 0; x < size; x++)
    (*table)[x] = 0;
}

void turn_on_table(table_size_type size, table_type *table)
{
  int x;

  for(x = 0; x < size; x++)
    (*table)[x] = (0x1<<size)-1;
}

void copy_table(table_type *destination, table_type *source)
{
  int x;

  for(x = 0; x < TABLE_SIZE_MAX; x++)
    (*destination)[x] = (*source)[x];
}

static void change_state_table(table_size_type size, table_type *table, int x, int y)
{
  if(x >= 0 && x < size && y >=0 && y < size)
  {
    if(get_state_table(table, x, y) == TRUE)
      turn_off_state_table(table, x, y);
    else
      turn_on_state_table(table, x, y);
  }
}

void change_states_table(table_size_type size, table_type *table, int x, int y)
{
  change_state_table(size, table, x-1, y);
  change_state_table(size, table, x, y-1);
  change_state_table(size, table, x+1, y);
  change_state_table(size, table, x, y+1);
  change_state_table(size, table, x, y);
}
