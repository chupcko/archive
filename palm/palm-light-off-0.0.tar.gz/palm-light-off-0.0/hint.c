#include "main.h"

typedef struct hint_magic_type
{
  table_size_type size;
  table_row_type begin;
  table_row_type end;
} hint_magic_type;

#define HINT_MAGIC_MAX_NUMBER ((0x1<<TABLE_SIZE_MAX+1)-(0x1<<TABLE_SIZE_MIN))
static hint_magic_type hint_magic[HINT_MAGIC_MAX_NUMBER];
static int hint_magic_number;

static table_row_type calculate_end(table_size_type size, table_row_type begin)
{
  table_type table;
  int x;
  int y;

  turn_off_table(size, &table);
  for(y = 0; y < size; y++)
    if(get_state_row(&begin, y) == TRUE)
      change_states_table(size, &table, 0, y);
  for(x = 1; x < size; x++)
    for(y = 0; y < size; y++)
      if(get_state_table(&table, x-1, y) == TRUE)
        change_states_table(size, &table, x, y);
  return table[size-1];
}

void init_hint(void)
{
  table_size_type size;
  table_row_type begin;
  table_row_type end;

  hint_magic_number = 0;
  for(size = TABLE_SIZE_MIN; size <= TABLE_SIZE_MAX; size++)
    for(begin = 0; begin < 0x1<<size; begin++)
      if(hint_magic_number < HINT_MAGIC_MAX_NUMBER)
      {
        hint_magic[hint_magic_number].size = size;
        hint_magic[hint_magic_number].begin = begin;
        hint_magic[hint_magic_number].end = calculate_end(size, begin);
        hint_magic_number++;
      }
}

void calculate_hint(table_size_type size, table_type *hint, table_type *table)
{
  table_type tmp_table;
  int x;
  int y;
  table_row_type row;
  int i;
  table_type tmp_hint;
  int tmp_hint_number;
  int tmp_hint_difference;
  table_type result_hint;
  int result_hint_number;
  int result_hint_difference;
  boolean_type first;

  copy_table(&tmp_table, table);
  for(x = 1; x < size; x++)
    for(y = 0; y < size; y++)
      if(get_state_table(&tmp_table, x-1, y) == TRUE)
        change_states_table(size, &tmp_table, x, y);
  row = tmp_table[size-1];
  first = TRUE;
  for(i = 0; i < hint_magic_number; i++)
    if(size == hint_magic[i].size && row == hint_magic[i].end)
    {
      copy_table(&tmp_table, table);
      turn_off_table(size, &tmp_hint);
      tmp_hint_number = 0;
      tmp_hint_difference = 0;
      for(y = 0; y < size; y++)
      {
        if(get_state_row(&hint_magic[i].begin, y) == TRUE)
        {
          change_states_table(size, &tmp_table, 0, y);
          turn_on_state_table(&tmp_hint, 0, y);
          tmp_hint_number++;
        }
        if(get_state_table(&tmp_hint, 0, y) != get_state_table(hint, 0, y))
          tmp_hint_difference++;
      }
      for(x = 1; x < size; x++)
        for(y = 0; y < size; y++)
        {
          if(get_state_table(&tmp_table, x-1, y) == TRUE)
          {
            change_states_table(size, &tmp_table, x, y);
            turn_on_state_table(&tmp_hint, x, y);
            tmp_hint_number++;
          }
          if(get_state_table(&tmp_hint, x, y) != get_state_table(hint, x, y))
            tmp_hint_difference++;
        }
      if
      (
        first == TRUE ||
        tmp_hint_number < result_hint_number ||
        (tmp_hint_number == result_hint_number && tmp_hint_difference < result_hint_difference)
      )
      {
        first = FALSE;
        copy_table(&result_hint, &tmp_hint);
        result_hint_number = tmp_hint_number;
        result_hint_difference = tmp_hint_difference;
      }
    }
  copy_table(hint, &result_hint);
}
