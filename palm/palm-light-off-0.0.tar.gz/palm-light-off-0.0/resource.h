#ifndef __RESOURCE_H
#define __RESOURCE_H

#define PROGRAM_NAME "Light Off"
#define PROGRAM_CREATOR_ID "LiOf"
#define PROGRAM_VERSION "0.0"
#define PROGRAM_AUTHOR "Goran \"CHUPCKO\" Lazic"
#define PROGRAM_URL "http://palm-light-off.sf.net/"

#define RCP_ApplicationIconName_ID 1000
#define RCP_Application_ID 1001

#define RCP_Bitmap_Off_ID 1100
#define RCP_Bitmap_On_ID 1101
#define RCP_Bitmap_Hint_Off_ID 1102
#define RCP_Bitmap_Hint_On_ID 1103

#define RCP_Menu_ID 1200
#define RCP_MenuItem_Reset_ID 1201
#define RCP_MenuItem_Shuttle_ID 1202
#define RCP_MenuItem_Hint_ID 1203
#define RCP_MenuItem_Preferences_ID 1204
#define RCP_MenuItem_3_ID 1205
#define RCP_MenuItem_4_ID 1206
#define RCP_MenuItem_5_ID 1207
#define RCP_MenuItem_6_ID 1208
#define RCP_MenuItem_Help_ID 1209
#define RCP_MenuItem_About_ID 1210

#define RCP_Form_Main_ID 1300

#define RCP_String_Info_ID 1400

#define RCP_Alert_Reset_ID 1500

#define RCP_Alert_Shuttle_ID 1600

#define RCP_Alert_Hint_ID 1700

#define RCP_Form_Preferences_ID 1800
#define RCP_Form_Preferences_Sound_ID 1801
#define RCP_Form_Preferences_AlertReset_ID 1802
#define RCP_Form_Preferences_AlertShuttle_ID 1803
#define RCP_Form_Preferences_AlertHint_ID 1804
#define RCP_Form_Preferences_KeepHintReset_ID 1805
#define RCP_Form_Preferences_KeepHintShuttle_ID 1806
#define RCP_Form_Preferences_Button_OK_ID 1807
#define RCP_Form_Preferences_Button_Cancel_ID 1808

#define RCP_Form_Help_ID 1900
#define RCP_Form_Help_Button_OK_ID 1901

#define RCP_Form_About_ID 2000
#define RCP_Form_About_Button_OK_ID 2001

#endif
