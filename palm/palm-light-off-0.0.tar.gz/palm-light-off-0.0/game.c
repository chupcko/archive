#include "main.h"

void reset_game(void)
{
  turn_on_table(Preference.size, &Preference.table);
  Preference.count = 0;
  if(Preference.keep_hint_reset != TRUE)
    Preference.hint = FALSE;
  if(Preference.hint == TRUE)
  {
    turn_off_table(Preference.size, &Preference.hint_table);
    calculate_hint(Preference.size, &Preference.hint_table, &Preference.table);
  }
}

void shuttle_game(void)
{
  int x;
  int y;

  for(x = 0; x < Preference.size; x++)
    for(y = 0; y < Preference.size; y++)
      if(SysRandom(0)%2 != 0)
        change_states_table(Preference.size, &Preference.table, x, y);
  Preference.count = 0;
  if(Preference.keep_hint_shuttle != TRUE)
    Preference.hint = FALSE;
  if(Preference.hint == TRUE)
  {
    turn_off_table(Preference.size, &Preference.hint_table);
    calculate_hint(Preference.size, &Preference.hint_table, &Preference.table);
  }
}

boolean_type tap_game(int x, int y)
{
  if
  (
    x < 0 ||
    x >= Preference.size ||
    y < 0 ||
    y >= Preference.size
  )
    return FALSE;
  if(Preference.sound == TRUE)
    sound();
  change_states_table(Preference.size, &Preference.table, x, y);
  Preference.count++;
  if(Preference.hint == TRUE)
    calculate_hint(Preference.size, &Preference.hint_table, &Preference.table);
  return TRUE;
}
