#ifndef __PROTOTYPE_H
#define __PROTOTYPE_H

/* draw.c */
void load_bitmaps(void);
void redraw(void);
void free_bitmaps(void);

/* event.c */
void event_loop(void);

/* game.c */
void reset_game(void);
void shuttle_game(void);
boolean_type tap_game(int, int);

/* hint.c */
void init_hint(void);
void calculate_hint(table_size_type, table_type *, table_type *);

/* sound.c */
void sound(void);

/* table.c */
boolean_type get_state_row(table_row_type *, int);
boolean_type get_state_table(table_type *, int, int);
void turn_off_state_table(table_type *, int, int);
void turn_on_state_table(table_type *, int, int);
void turn_off_table(table_size_type, table_type *);
void turn_on_table(table_size_type, table_type *);
void copy_table(table_type *, table_type *);
void change_states_table(table_size_type, table_type *, int, int);

#endif
