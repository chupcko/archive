#ifndef __VARIABLE_H
#define __VARIABLE_H

EXTERN preference_type Preference;

EXTERN UInt16 Game_volume;

#endif
