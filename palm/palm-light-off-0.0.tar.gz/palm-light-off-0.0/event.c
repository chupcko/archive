#include <stdio.h>

#include "main.h"

static void show_menu(void)
{
  EventType event;

  MemSet((void *)&event, sizeof(EventType), 0);
  event.eType = keyDownEvent;
  event.data.keyDown.chr = menuChr;
  event.data.keyDown.keyCode = 0;
  event.data.keyDown.modifiers = commandKeyMask;
  EvtAddEventToQueue(&event);
}

static Boolean form_main_event(EventPtr event)
{
  Boolean handled;
  FormPtr form;
  Int16 pen_x;
  Int16 pen_y;
  Boolean button_state;

  handled = false;
  switch(event->eType)
  {
    case frmOpenEvent:
    case frmUpdateEvent:
      form = FrmGetActiveForm();
      FrmDrawForm(form);
      redraw();
      handled = true;
      break;
    case penDownEvent:
      EvtGetPen(&pen_x, &pen_y, &button_state);
      if(pen_y < MENU_STATUS_SIZE)
      {
        show_menu();
        break;
      }
      pen_x -= OFFSET_X;
      pen_y -= OFFSET_Y;
      if
      (
        pen_x >= 0 &&
        pen_x < Preference.size*BITMAP_SIZE &&
        pen_y >= 0 &&
        pen_y < Preference.size*BITMAP_SIZE &&
        tap_game(pen_x/BITMAP_SIZE, pen_y/BITMAP_SIZE) == TRUE
      )
        redraw();
      handled = true;
      break;
    case menuEvent:
      MenuEraseStatus(NULL);
      switch(event->data.menu.itemID)
      {
        case RCP_MenuItem_Reset_ID:
          if(Preference.alert_reset != TRUE || FrmAlert(RCP_Alert_Reset_ID) == 0)
          {
            reset_game();
            redraw();
          }
          handled = true;
          break;
        case RCP_MenuItem_Shuttle_ID:
          if(Preference.alert_shuttle != TRUE || FrmAlert(RCP_Alert_Shuttle_ID) == 0)
          {
            shuttle_game();
            redraw();
          }
          handled = true;
          break;
        case RCP_MenuItem_Hint_ID:
          if(Preference.hint == TRUE)
          {
            Preference.hint = FALSE;
            turn_off_table(Preference.size, &Preference.hint_table);
            redraw();
          }
          else
            if(Preference.alert_hint != TRUE || FrmAlert(RCP_Alert_Hint_ID) == 0)
            {
              calculate_hint(Preference.size, &Preference.hint_table, &Preference.table);
              Preference.hint = TRUE;
              redraw();
            }
          handled = true;
          break;
        case RCP_MenuItem_Preferences_ID:
          FrmPopupForm(RCP_Form_Preferences_ID);
          handled = true;
          break;
        case RCP_MenuItem_3_ID:
          Preference.size = TABLE_SIZE_3;
          reset_game();
          redraw();
          handled = true;
          break;
        case RCP_MenuItem_4_ID:
          Preference.size = TABLE_SIZE_4;
          reset_game();
          redraw();
          handled = true;
          break;
        case RCP_MenuItem_5_ID:
          Preference.size = TABLE_SIZE_5;
          reset_game();
          redraw();
          handled = true;
          break;
        case RCP_MenuItem_6_ID:
          Preference.size = TABLE_SIZE_6;
          reset_game();
          redraw();
          handled = true;
          break;
        case RCP_MenuItem_About_ID:
          FrmPopupForm(RCP_Form_About_ID);
          handled = true;
          break;
        case RCP_MenuItem_Help_ID:
          FrmPopupForm(RCP_Form_Help_ID);
          handled = true;
          break;
      }
      break;
  }
  return handled;
}

static Boolean form_preferences_event(EventPtr event)
{
  Boolean handled;
  FormPtr form;

  handled = false;
  switch(event->eType)
  {
    case frmOpenEvent:
      form = FrmGetActiveForm();
      FrmSetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_Sound_ID), Preference.sound == TRUE ? 1 : 0);
      FrmSetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_AlertReset_ID), Preference.alert_reset == TRUE ? 1 : 0);
      FrmSetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_AlertShuttle_ID), Preference.alert_shuttle == TRUE ? 1 : 0);
      FrmSetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_AlertHint_ID), Preference.alert_hint == TRUE ? 1 : 0);
      FrmSetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_KeepHintReset_ID), Preference.keep_hint_reset == TRUE ? 1 : 0);
      FrmSetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_KeepHintShuttle_ID), Preference.keep_hint_shuttle == TRUE ? 1 : 0);
      FrmDrawForm(form);
      handled = true;
      break;
    case frmUpdateEvent:
      form = FrmGetActiveForm();
      FrmDrawForm(form);
      handled = true;
      break;
    case ctlSelectEvent:
      switch(event->data.ctlEnter.controlID)
      {
        case RCP_Form_Preferences_Button_OK_ID:
          Preference.sound = FrmGetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_Sound_ID)) != 0 ? TRUE : FALSE;
          Preference.alert_reset = FrmGetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_AlertReset_ID)) != 0 ? TRUE : FALSE;
          Preference.alert_shuttle = FrmGetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_AlertShuttle_ID)) != 0 ? TRUE : FALSE;
          Preference.alert_hint = FrmGetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_AlertHint_ID)) != 0 ? TRUE : FALSE;
          Preference.keep_hint_reset = FrmGetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_KeepHintReset_ID)) != 0 ? TRUE : FALSE;
          Preference.keep_hint_shuttle = FrmGetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_KeepHintShuttle_ID)) != 0 ? TRUE : FALSE;
          FrmReturnToForm(0);
          handled = true;
          break;
        case RCP_Form_Preferences_Button_Cancel_ID:
          FrmReturnToForm(0);
          handled = true;
          break;
      }
  }
  return handled;
}

static Boolean form_help_event(EventPtr event)
{
  Boolean handled;
  FormPtr form;

  handled = false;
  switch(event->eType)
  {
    case frmOpenEvent:
    case frmUpdateEvent:
      form = FrmGetActiveForm();
      FrmDrawForm(form);
      handled = true;
      break;
    case ctlSelectEvent:
      if(event->data.ctlEnter.controlID == RCP_Form_Help_Button_OK_ID)
      {
        FrmReturnToForm(0);
        handled = true;
        break;
      }
      break;
  }
  return handled;
}

static Boolean form_about_event(EventPtr event)
{
  Boolean handled;
  FormPtr form;

  handled = false;
  switch(event->eType)
  {
    case frmOpenEvent:
    case frmUpdateEvent:
      form = FrmGetActiveForm();
      FrmDrawForm(form);
      handled = true;
      break;
    case ctlSelectEvent:
      if(event->data.ctlEnter.controlID == RCP_Form_About_Button_OK_ID)
      {
        FrmReturnToForm(0);
        handled = true;
        break;
      }
      break;
  }
  return handled;
}

#define EVENT_SLEEP evtWaitForever

void event_loop(void)
{
  EventType event;
  UInt16 error;
  Int16 form_id;
  FormPtr form;

  do
  {
    EvtGetEvent(&event, EVENT_SLEEP);
    if(SysHandleEvent(&event) == true)
      continue;
    if(MenuHandleEvent(NULL, &event, &error) == true)
      continue;
    if(event.eType == frmLoadEvent)
    {

      form_id = event.data.frmLoad.formID;
      form = FrmInitForm(form_id);
      FrmSetActiveForm(form);
      switch(form_id)
      {
        case RCP_Form_Main_ID:
          FrmSetEventHandler(form, (FormEventHandlerPtr)form_main_event);
          break;
        case RCP_Form_Preferences_ID:
          FrmSetEventHandler(form, (FormEventHandlerPtr)form_preferences_event);
          break;
        case RCP_Form_Help_ID:
          FrmSetEventHandler(form, (FormEventHandlerPtr)form_help_event);
          break;
        case RCP_Form_About_ID:
          FrmSetEventHandler(form, (FormEventHandlerPtr)form_about_event);
          break;
      }
    }
    else
      FrmDispatchEvent(&event);
  } while(event.eType != appStopEvent);
}
