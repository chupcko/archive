#include "main.h"

void clear_table(table_type *table)
{
  int x;
  int y;

  for(x = 0; x < TABLE_SIZE_MAX; x++)
    for(y = 0; y < TABLE_SIZE_MAX; y++)
    {
      (*table)[x][y].color = CELL_COLOR_GRAY;
      (*table)[x][y].count = 0;
      (*table)[x][y].result = CELL_RESULT_EMPTY;
      (*table)[x][y].auxiliary = FALSE;
    }
}

boolean_type change_cell(int size_x, int size_y, table_type *table, int x, int y)
{
  if
  (
    x < 0 ||
    x >= size_x ||
    y < 0 ||
    y >= size_y ||
    (*table)[x][y].result == CELL_RESULT_NUMBER
  )
    return FALSE;
  (*table)[x][y].color = ((*table)[x][y].color+1)%CELL_COLOR_MOD;
  return TRUE;
}

void copy_table(table_type *destination, table_type *source)
{
  int x;
  int y;

  for(x = 0; x < TABLE_SIZE_MAX; x++)
    for(y = 0; y < TABLE_SIZE_MAX; y++)
      (*destination)[x][y] = (*source)[x][y];
}
