#include <stdio.h>

#include "main.h"

static MemHandle bitmap_digits_mh[10];
static BitmapPtr bitmap_digits_bp[10];

void load_bitmaps(void)
{
  int i;

  for(i = 0; i < 10; i++)
  {
    bitmap_digits_mh[i] = DmGetResource(bitmapRsc, RCP_Bitmap_Digit_0_ID+i);
    bitmap_digits_bp[i] = (BitmapPtr)MemHandleLock(bitmap_digits_mh[i]);
  }
}

static void set_color(int l)
{
  RGBColorType color;

  color.r = l;
  color.g = l;
  color.b = l;
  color.index = 0;
  WinSetForeColorRGB(&color, NULL);
}

#define DIGIT_SPACE 1

void draw_cell(int x, int y)
{
  RGBColorType color;
  RectangleType rectangle;

  switch(Preference.table[x][y].color)
  {
    case CELL_COLOR_GRAY:
      set_color(0xc3);
      break;
    case CELL_COLOR_BLACK:
      set_color(0x58);
      break;
    case CELL_COLOR_WHITE:
      set_color(0xff);
      break;
  }
  rectangle.topLeft.x = OFFSET_X+x*FRAME_SIZE;
  rectangle.topLeft.y = OFFSET_Y+y*FRAME_SIZE;
  rectangle.extent.x = BLOCK_SIZE;
  rectangle.extent.y = BLOCK_SIZE;
  WinDrawRectangle(&rectangle, 0);
  if(Preference.table[x][y].count > 0 && Preference.table[x][y].count < 10)
  {
    Coord width;
    Coord height;

    BmpGetDimensions(bitmap_digits_bp[Preference.table[x][y].count], &width, &height, NULL);
    WinDrawBitmap
    (
      bitmap_digits_bp[Preference.table[x][y].count],
      OFFSET_X+x*FRAME_SIZE+(BLOCK_SIZE-width)/2,
      OFFSET_Y+y*FRAME_SIZE+(BLOCK_SIZE-height)/2
    );
  }
  else if(Preference.table[x][y].count >= 10 && Preference.table[x][y].count < 100)
  {
    Coord width_1;
    Coord height;
    Coord width_2;

    BmpGetDimensions(bitmap_digits_bp[Preference.table[x][y].count/10], &width_1, &height, NULL);
    BmpGetDimensions(bitmap_digits_bp[Preference.table[x][y].count%10], &width_2, NULL, NULL);
    WinDrawBitmap
    (
      bitmap_digits_bp[Preference.table[x][y].count/10],
      OFFSET_X+x*FRAME_SIZE+(BLOCK_SIZE-width_1-DIGIT_SPACE-width_2)/2,
      OFFSET_Y+y*FRAME_SIZE+(BLOCK_SIZE-height)/2
    );
    WinDrawBitmap
    (
      bitmap_digits_bp[Preference.table[x][y].count%10],
      OFFSET_X+x*FRAME_SIZE+(BLOCK_SIZE+width_1+DIGIT_SPACE-width_2)/2,
      OFFSET_Y+y*FRAME_SIZE+(BLOCK_SIZE-height)/2
    );
  }
}

void redraw(void)
{
  RGBColorType color;
  RectangleType rectangle;
  int x;
  int y;

  rectangle.topLeft.x = 0;
  rectangle.topLeft.y = 0;
  rectangle.extent.x = RESOLUTION_X;
  rectangle.extent.y = RESOLUTION_Y;
  WinEraseRectangle(&rectangle, 0);
  set_color(0x00);
  rectangle.topLeft.x = OFFSET_X;
  rectangle.topLeft.y = OFFSET_Y;
  rectangle.extent.x = FRAME_SIZE*Preference.size_x-1;
  rectangle.extent.y = FRAME_SIZE*Preference.size_y-1;
  WinDrawRectangleFrame(simpleFrame, &rectangle);
  rectangle.topLeft.x = OFFSET_X-1;
  rectangle.topLeft.y = OFFSET_Y-1;
  rectangle.extent.x = FRAME_SIZE*Preference.size_x+1;
  rectangle.extent.y = FRAME_SIZE*Preference.size_y+1;
  WinDrawRectangleFrame(simpleFrame, &rectangle);
  set_color(0x80);
  for(x = 0; x < Preference.size_x-1; x++)
    WinDrawLine
    (
      OFFSET_X+x*FRAME_SIZE+BLOCK_SIZE,
      OFFSET_Y,
      OFFSET_X+x*FRAME_SIZE+BLOCK_SIZE,
      OFFSET_Y+(Preference.size_y-1)*FRAME_SIZE+BLOCK_SIZE-1
    );
  for(y = 0; y < Preference.size_y-1; y++)
    WinDrawLine
    (
      OFFSET_X,
      OFFSET_Y+y*FRAME_SIZE+BLOCK_SIZE,
      OFFSET_X+(Preference.size_x-1)*FRAME_SIZE+BLOCK_SIZE-1,
      OFFSET_Y+y*FRAME_SIZE+BLOCK_SIZE
    );
  for(x = 0; x < Preference.size_x; x++)
    for(y = 0; y < Preference.size_y; y++)
      draw_cell(x, y);
}

void free_bitmaps(void)
{
  int i;

  for(i = 0; i < 10; i++)
  {
    MemPtrUnlock((MemPtr)bitmap_digits_bp[i]);
    DmReleaseResource(bitmap_digits_mh[i]);
  }
}
