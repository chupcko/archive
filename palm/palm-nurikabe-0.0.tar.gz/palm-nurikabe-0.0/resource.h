#ifndef __RESOURCE_H
#define __RESOURCE_H

#define PROGRAM_NAME "Nurikabe"
#define PROGRAM_CREATOR_ID "Nrkb"
#define PROGRAM_DATA_ID "DATA"
#define PROGRAM_VERSION "0.0"
#define PROGRAM_AUTHOR "Goran \"CHUPCKO\" Lazic"
#define PROGRAM_URL "(none)"

#define RCP_ApplicationIconName_ID 1000
#define RCP_Application_ID 1001

#define RCP_Bitmap_Digit_0_ID 1100
#define RCP_Bitmap_Digit_1_ID 1101
#define RCP_Bitmap_Digit_2_ID 1102
#define RCP_Bitmap_Digit_3_ID 1103
#define RCP_Bitmap_Digit_4_ID 1104
#define RCP_Bitmap_Digit_5_ID 1105
#define RCP_Bitmap_Digit_6_ID 1106
#define RCP_Bitmap_Digit_7_ID 1107
#define RCP_Bitmap_Digit_8_ID 1108
#define RCP_Bitmap_Digit_9_ID 1109

#define RCP_Menu_ID 1200
#define RCP_MenuItem_Select_ID 1201
#define RCP_MenuItem_Random_ID 1202
#define RCP_MenuItem_Reset_ID 1203
#define RCP_MenuItem_Preferences_ID 1204
#define RCP_MenuItem_Begin_ID 1205
#define RCP_MenuItem_Rollback_ID 1206
#define RCP_MenuItem_Help_ID 1207
#define RCP_MenuItem_About_ID 1208

#define RCP_Form_Main_ID 1300

#define RCP_String_Info_ID 1400

#define RCP_Form_Select_ID 1500
#define RCP_Form_Select_List_ID 1501
#define RCP_Form_Select_Button_OK_ID 1502
#define RCP_Form_Select_Button_Cancel_ID 1503

#define RCP_Alert_Random_ID 1600

#define RCP_Alert_Reset_ID 1700

#define RCP_Form_Preferences_ID 1800
#define RCP_Form_Preferences_SoundTap_ID 1801
#define RCP_Form_Preferences_SoundNoAlert_ID 1802
#define RCP_Form_Preferences_AlertRandom_ID 1803
#define RCP_Form_Preferences_AlertReset_ID 1804
#define RCP_Form_Preferences_AlertBegin_ID 1805
#define RCP_Form_Preferences_AlertRoolback_ID 1806
#define RCP_Form_Preferences_Button_OK_ID 1807
#define RCP_Form_Preferences_Button_Cancel_ID 1808

#define RCP_Alert_Begin_ID 1900

#define RCP_Alert_Rollback_ID 2000

#define RCP_Form_About_ID 2100
#define RCP_Form_About_Button_OK_ID 2101

#define RCP_Form_Help_ID 2200
#define RCP_Form_Help_Button_OK_ID 2201

#define RCP_Alert_Finish_ID 2300

#endif
