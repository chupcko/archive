#include <stdio.h>

#include "main.h"

static int count_levels(void)
{
  Boolean first_search;
  DmSearchStateType search_state;
  int record_number;

  record_number = 0;
  first_search = true;
  while(TRUE)
  {
    UInt16 card;
    LocalID db_id;
    DmOpenRef db;

    if(DmGetNextDatabaseByTypeCreator(first_search, &search_state, make_id(PROGRAM_DATA_ID), make_id(PROGRAM_CREATOR_ID), false, &card, &db_id) == dmErrCantFind)
      break;
    first_search = false;
    db = DmOpenDatabase(card, db_id, dmModeReadOnly);
    record_number += (int)DmNumRecords(db);
    DmCloseDatabase(db);
  }
  return record_number;
}

static void fill_levels(void)
{
  Boolean first_search;
  DmSearchStateType search_state;
  int n;

  n = 0;
  first_search = true;
  while(TRUE)
  {
    UInt16 card_number;
    LocalID db_id;
    DmOpenRef db;
    int record_number;
    int i;

    if(DmGetNextDatabaseByTypeCreator(first_search, &search_state, make_id(PROGRAM_DATA_ID), make_id(PROGRAM_CREATOR_ID), false, &card_number, &db_id) == dmErrCantFind)
      break;
    first_search = false;
    db = DmOpenDatabase(card_number, db_id, dmModeReadOnly);
    record_number = (int)DmNumRecords(db);
    for(i = 0; i < record_number; i++)
      if(n < Levels_number)
      {
        MemHandle record;
        Char *string;
        int record_length;
        int j;

        Levels[n].card_number = card_number;
        Levels[n].db_id = db_id;
        Levels[n].record_number = (UInt16)i;
        record = DmGetRecord(db, (UInt16)i);
        record_length = (int)MemHandleSize(record);
        string = (Char *)MemHandleLock(record);
        j = 0;
        while
        (
          j < MAX_LEVEL_NAME_LENGTH &&
          j < record_length &&
          string[j] != '\n'
        )
        {
          Levels[n].name[j] = string[j];
          j++;
        }
        Levels[n].name[j] = '\0';
        List_options[n] = Levels[n].name;
        MemPtrUnlock((MemPtr)string);
        DmReleaseRecord(db, (UInt16)i, true);
        n++;
      }
    DmCloseDatabase(db);
  }
}

boolean_type load_levels(void)
{
  Levels_number = count_levels();
  if(Levels_number <= 0)
    return FALSE;
  List_options = (Char **)MemPtrNew(Levels_number*sizeof(Char *));
  if(List_options == NULL)
    return FALSE;
  Levels = (level_type *)MemPtrNew(Levels_number*sizeof(level_type));
  if(Levels == NULL)
    return FALSE;
  fill_levels();
  return TRUE;
}

static boolean_type equal_level(level_type *level_1, level_type *level_2)
{
  if
  (
    (
      level_1->card_number == level_2->card_number &&
      level_1->db_id == level_2->db_id &&
      level_1->record_number == level_2->record_number
    ) ||
    StrNCompare(level_1->name, level_2->name, MAX_LEVEL_NAME_LENGTH) == 0
  )
    return TRUE;
  return FALSE;
}

int find_level(level_type *level)
{
  int i;

  i = 0;
  while
  (
    i < Levels_number &&
    equal_level(level, &Levels[i]) != TRUE
  )
    i++;
  if(i >= Levels_number)
  {
    *level = Levels[0];
    return 0;
  }
  return i;
}

boolean_type select_level(int index)
{
  DmOpenRef db;
  MemHandle record;
  MemPtr string;

  if(index >= Levels_number)
    return FALSE;
  db = DmOpenDatabase(Levels[index].card_number, Levels[index].db_id, dmModeReadOnly);
  if(db == NULL)
    return FALSE;
  record = DmGetRecord(db, Levels[index].record_number);
  if(record == NULL)
  {
    DmCloseDatabase(db);
    return FALSE;
  }
  string = MemHandleLock(record);
  fill_table((char *)string, (int)MemHandleSize(record));
  MemPtrUnlock(string);
  DmReleaseRecord(db, Levels[index].record_number, true);
  DmCloseDatabase(db);
  return TRUE;
}

void free_levels(void)
{
  MemPtrFree((MemPtr)Levels);
  MemPtrFree((MemPtr)List_options);
}
