#include <stdio.h>

#include "main.h"

static Boolean form_main_event(EventPtr event)
{
  Boolean handled;
  FormPtr form;
  Int16 pen_x;
  Int16 pen_y;
  Boolean button_state;

  handled = false;
  switch(event->eType)
  {
    case frmOpenEvent:
    case frmUpdateEvent:
      form = FrmGetActiveForm();
      FrmDrawForm(form);
      redraw();
      handled = true;
      break;
    case penDownEvent:
      EvtGetPen(&pen_x, &pen_y, &button_state);
      if(Preference.finish != TRUE)
      {
        pen_x -= OFFSET_X;
        pen_y -= OFFSET_Y;
        if
        (
          pen_x >= 0 &&
          pen_x < Preference.size_x*FRAME_SIZE &&
          pen_x%FRAME_SIZE != BLOCK_SIZE &&
          pen_y >= 0 &&
          pen_y < Preference.size_y*FRAME_SIZE &&
          pen_y%FRAME_SIZE != BLOCK_SIZE
        )
        {
          pen_x /= FRAME_SIZE;
          pen_y /= FRAME_SIZE;
          tap_game(pen_x, pen_y);
        }
      }
      handled = true;
      break;
    case menuEvent:
      MenuEraseStatus(NULL);
      switch(event->data.menu.itemID)
      {
        case RCP_MenuItem_Select_ID:
          if(form_select_execute(&Selected_level) == TRUE)
          {
            Preference.level = Levels[Selected_level];
            select_level(Selected_level);
            redraw();
          }
          handled = true;
          break;
        case RCP_MenuItem_Random_ID:
          if(Preference.alert_random != TRUE || FrmAlert(RCP_Alert_Random_ID) == 0)
          {
            Selected_level = SysRandom(0)%Levels_number;
            Preference.level = Levels[Selected_level];
            select_level(Selected_level);
            redraw();
            if(Preference.alert_random != TRUE && Preference.sound_no_alert)
              SndPlaySystemSound(sndInfo);
          }
          handled = true;
          break;
        case RCP_MenuItem_Reset_ID:
          if(Preference.alert_reset != TRUE || FrmAlert(RCP_Alert_Reset_ID) == 0)
          {
            select_level(Selected_level);
            redraw();
            if(Preference.alert_reset != TRUE && Preference.sound_no_alert)
              SndPlaySystemSound(sndInfo);
          }
          handled = true;
          break;
        case RCP_MenuItem_Preferences_ID:
          FrmPopupForm(RCP_Form_Preferences_ID);
          handled = true;
          break;
        case RCP_MenuItem_Begin_ID:
          if
          (
            Preference.finish != TRUE &&
            (
              Preference.alert_begin != TRUE ||
              FrmAlert(RCP_Alert_Begin_ID) == 0
            )
          )
          {
            copy_table(&Preference.table_backup, &Preference.table);
            if(Preference.alert_begin != TRUE && Preference.sound_no_alert)
              SndPlaySystemSound(sndInfo);
          }
          handled = true;
          break;
        case RCP_MenuItem_Rollback_ID:
          if
          (
            Preference.finish != TRUE &&
            (
              Preference.alert_rollback != TRUE ||
              FrmAlert(RCP_Alert_Rollback_ID) == 0
            )
          )
          {
            copy_table(&Preference.table, &Preference.table_backup);
            redraw();
            if(Preference.alert_rollback != TRUE && Preference.sound_no_alert)
              SndPlaySystemSound(sndInfo);
          }
          handled = true;
          break;
        case RCP_MenuItem_About_ID:
          FrmPopupForm(RCP_Form_About_ID);
          handled = true;
          break;
        case RCP_MenuItem_Help_ID:
          FrmPopupForm(RCP_Form_Help_ID);
          handled = true;
          break;
      }
      break;
  }
  return handled;
}

static Boolean form_preference_event(EventPtr event)
{
  Boolean handled;
  FormPtr form;

  handled = false;
  switch(event->eType)
  {
    case frmOpenEvent:
      form = FrmGetActiveForm();
      FrmSetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_SoundTap_ID), Preference.sound_tap == TRUE ? 1 : 0);
      FrmSetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_SoundNoAlert_ID), Preference.sound_no_alert == TRUE ? 1 : 0);
      FrmSetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_AlertRandom_ID), Preference.alert_random == TRUE ? 1 : 0);
      FrmSetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_AlertReset_ID), Preference.alert_reset == TRUE ? 1 : 0);
      FrmSetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_AlertBegin_ID), Preference.alert_begin == TRUE ? 1 : 0);
      FrmSetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_AlertRoolback_ID), Preference.alert_rollback == TRUE ? 1 : 0);
      FrmDrawForm(form);
      handled = true;
      break;
    case frmUpdateEvent:
      form = FrmGetActiveForm();
      FrmDrawForm(form);
      handled = true;
      break;
    case ctlSelectEvent:
      switch(event->data.ctlEnter.controlID)
      {
        case RCP_Form_Preferences_Button_OK_ID:
          Preference.sound_tap = FrmGetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_SoundTap_ID)) != 0 ? TRUE : FALSE;
          Preference.sound_no_alert = FrmGetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_SoundNoAlert_ID)) != 0 ? TRUE : FALSE;
          Preference.alert_random = FrmGetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_AlertRandom_ID)) != 0 ? TRUE : FALSE;
          Preference.alert_reset = FrmGetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_AlertReset_ID)) != 0 ? TRUE : FALSE;
          Preference.alert_begin = FrmGetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_AlertBegin_ID)) != 0 ? TRUE : FALSE;
          Preference.alert_rollback = FrmGetControlValue(form, FrmGetObjectIndex(form, RCP_Form_Preferences_AlertRoolback_ID)) != 0 ? TRUE : FALSE;
          FrmReturnToForm(0);
          handled = true;
          break;
        case RCP_Form_Preferences_Button_Cancel_ID:
          FrmReturnToForm(0);
          handled = true;
          break;
      }
      break;
  }
  return handled;
}

static Boolean form_help_event(EventPtr event)
{
  Boolean handled;
  FormPtr form;

  handled = false;
  switch(event->eType)
  {
    case frmOpenEvent:
    case frmUpdateEvent:
      form = FrmGetActiveForm();
      FrmDrawForm(form);
      handled = true;
      break;
    case ctlSelectEvent:
      if(event->data.ctlEnter.controlID == RCP_Form_Help_Button_OK_ID)
      {
        FrmReturnToForm(0);
        handled = true;
        break;
      }
      break;
  }
  return handled;
}

static Boolean form_about_event(EventPtr event)
{
  Boolean handled;
  FormPtr form;

  handled = false;
  switch(event->eType)
  {
    case frmOpenEvent:
    case frmUpdateEvent:
      form = FrmGetActiveForm();
      FrmDrawForm(form);
      handled = true;
      break;
    case ctlSelectEvent:
      if(event->data.ctlEnter.controlID == RCP_Form_About_Button_OK_ID)
      {
        FrmReturnToForm(0);
        handled = true;
        break;
      }
      break;
  }
  return handled;
}

#define EVENT_SLEEP evtWaitForever

void event_loop(void)
{
  EventType event;
  UInt16 error;
  Int16 form_id;
  FormPtr form;

  do
  {
    EvtGetEvent(&event, EVENT_SLEEP);
    if(SysHandleEvent(&event) == true)
      continue;
    if(MenuHandleEvent(NULL, &event, &error) == true)
      continue;
    if(event.eType == frmLoadEvent)
    {

      form_id = event.data.frmLoad.formID;
      form = FrmInitForm(form_id);
      FrmSetActiveForm(form);
      switch(form_id)
      {
        case RCP_Form_Main_ID:
          FrmSetEventHandler(form, (FormEventHandlerPtr)form_main_event);
          break;
        case RCP_Form_Preferences_ID:
          FrmSetEventHandler(form, (FormEventHandlerPtr)form_preference_event);
          break;
        case RCP_Form_Help_ID:
          FrmSetEventHandler(form, (FormEventHandlerPtr)form_help_event);
          break;
        case RCP_Form_About_ID:
          FrmSetEventHandler(form, (FormEventHandlerPtr)form_about_event);
          break;
      }
    }
    else
      FrmDispatchEvent(&event);
  } while(event.eType != appStopEvent);
}
