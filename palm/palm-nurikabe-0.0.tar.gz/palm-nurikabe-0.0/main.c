#include <stdio.h>

#define __MAIN_C

#include "main.h"

#define PREFERENCE_SAVED 0
#define PREFERENCE_VERSION 0

UInt32 make_id(char *name)
{
  return (UInt32)name[0]<<24|(UInt32)name[1]<<16|(UInt32)name[2]<<8|(UInt32)name[3];
}

static boolean_type start_application(void)
{
  UInt32 rom_version;
  UInt32 depth;
  RGBColorType color;
  Int16 preference_version;
  UInt16 preference_size;

  FtrGet(sysFtrCreator, sysFtrNumROMVersion, &rom_version);
  if(rom_version < sysMakeROMVersion(3, 5, 0, sysROMStageRelease, 0))
    return FALSE;
  WinScreenMode(winScreenModeGetSupportedDepths, NULL, NULL, &depth, NULL);
  if((depth & 0x8000) == 0)
    return FALSE;
  color.r = 0xff;
  color.g = 0xff;
  color.b = 0xff;
  color.index = 0;
  color.index = WinRGBToIndex(&color);
  UIColorSetTableEntry(UIDialogFill, &color);
  UIColorSetTableEntry(UIFormFill, &color);
  WinSetBackColor(color.index);
  load_bitmaps();
  if(load_levels() != TRUE)
    return FALSE;
  preference_size = (UInt16)sizeof(Preference);
  preference_version = PrefGetAppPreferences(make_id(PROGRAM_CREATOR_ID), PREFERENCE_SAVED, (void *)&Preference, &preference_size, true);
  if(preference_version == noPreferenceFound || preference_version != PREFERENCE_VERSION)
  {
    Selected_level = 0;
    Preference.level = Levels[Selected_level];
    select_level(Selected_level);
    Preference.sound_tap = TRUE;
    Preference.sound_no_alert = TRUE;
    Preference.alert_random = TRUE;
    Preference.alert_reset = TRUE;
    Preference.alert_begin = TRUE;
    Preference.alert_rollback = TRUE;
  }
  else
    Selected_level = find_level(&Preference.level);
  FrmGotoForm(RCP_Form_Main_ID);
  return TRUE;
}

static void stop_application(void)
{
  PrefSetAppPreferences(make_id(PROGRAM_CREATOR_ID), PREFERENCE_SAVED, PREFERENCE_VERSION, (void *)&Preference, (UInt16)sizeof(Preference), true);
  free_levels();
  free_bitmaps();
  FrmCloseAllForms();
}

UInt32 PilotMain(UInt16 command, void *command_parameters, UInt16 launch_flags)
{
  if(command == sysAppLaunchCmdNormalLaunch)
  {
    if(start_application() != TRUE)
      return appErrorClass;
    event_loop();
    stop_application();
  }
  return 0;
}
