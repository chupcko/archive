#ifndef __TYPE_H
#define __TYPE_H

typedef enum
{
  FALSE = 0,
  TRUE = 1
} boolean_type;

typedef enum
{
  CELL_COLOR_GRAY = 0,
  CELL_COLOR_BLACK = 1,
  CELL_COLOR_WHITE = 2
} cell_color_type;
#define CELL_COLOR_MOD (CELL_COLOR_WHITE+1)

typedef enum
{
  CELL_RESULT_EMPTY = 0,
  CELL_RESULT_BLACK = 1,
  CELL_RESULT_WHITE = 2,
  CELL_RESULT_NUMBER = 3
} cell_result_type;

typedef struct cell_type
{
  cell_color_type color;
  int count;
  cell_result_type result;
  boolean_type auxiliary;
} cell_type;

#define TABLE_SIZE_MAX 15
typedef cell_type table_type[TABLE_SIZE_MAX][TABLE_SIZE_MAX];

#define MAX_LEVEL_NAME_LENGTH 15
typedef struct level_type
{
  UInt16 card_number;
  LocalID db_id;
  UInt16 record_number;
  Char name[MAX_LEVEL_NAME_LENGTH+1];
} level_type;

typedef struct preference_type
{
  int size_x;
  int size_y;
  table_type table;
  table_type table_backup;
  boolean_type finish;
  level_type level;
  boolean_type sound_tap;
  boolean_type sound_no_alert;
  boolean_type alert_random;
  boolean_type alert_reset;
  boolean_type alert_begin;
  boolean_type alert_rollback;
} preference_type;

#endif
