#include "main.h"

static int count_in_result(int x, int y)
{
  if
  (
    x < 0 ||
    x >= Preference.size_x ||
    y < 0 ||
    y >= Preference.size_y ||
    Preference.table[x][y].auxiliary == TRUE ||
    (
      Preference.table[x][y].result != CELL_RESULT_WHITE &&
      Preference.table[x][y].result != CELL_RESULT_NUMBER
    )
  )
  return 0;
  Preference.table[x][y].auxiliary = TRUE;
  return
    1+
    count_in_result(x-1, y)+
    count_in_result(x, y-1)+
    count_in_result(x+1, y)+
    count_in_result(x, y+1);
}

void fill_table(char *string, int length)
{
  int i;
  int x;
  int y;

  i = 0;
  while(i < length && string[i] != '\n')
    i++;
  i++;
  clear_table(&Preference.table);
  Preference.size_x = 0;
  Preference.size_y = 0;
  Preference.finish = FALSE;
  while(Preference.size_y < TABLE_SIZE_MAX && i < length)
  {
    x = 0;
    while(x < TABLE_SIZE_MAX && i < length && string[i] != '\n')
    {
      switch(string[i])
      {
        case '*':
          Preference.table[x][Preference.size_y].color = CELL_COLOR_GRAY;
          Preference.table[x][Preference.size_y].result = CELL_RESULT_BLACK;
          break;
        case '.':
          Preference.table[x][Preference.size_y].color = CELL_COLOR_GRAY;
          Preference.table[x][Preference.size_y].result = CELL_RESULT_WHITE;
          break;
        case '+':
          Preference.table[x][Preference.size_y].color = CELL_COLOR_WHITE;
          Preference.table[x][Preference.size_y].result = CELL_RESULT_NUMBER;
          break;
      }
      i++;
      x++;
    }
    i++;
    if(x > Preference.size_x)
      Preference.size_x = x;
    Preference.size_y++;
  }
  for(x = 0; x < Preference.size_x; x++)
    for(y = 0; y < Preference.size_y; y++)
      if(Preference.table[x][y].result == CELL_RESULT_NUMBER)
        Preference.table[x][y].count = count_in_result(x, y);
  copy_table(&Preference.table_backup, &Preference.table);
}

static finish(void)
{
  int x;
  int y;

  for(x = 0; x < Preference.size_x; x++)
    for(y = 0; y < Preference.size_y; y++)
      switch(Preference.table[x][y].result)
      {
        case CELL_RESULT_BLACK:
          if(Preference.table[x][y].color != CELL_COLOR_BLACK)
            return FALSE;
          break;
        case CELL_RESULT_WHITE:
          if(Preference.table[x][y].color != CELL_COLOR_WHITE)
            return FALSE;
          break;
      }
  return TRUE;
}

void tap_game(int x, int y)
{
  if(change_cell(Preference.size_x, Preference.size_y, &Preference.table, x, y) == TRUE)
  {
    if(Preference.sound_tap == TRUE)
      SndPlaySystemSound(sndClick);
    draw_cell(x, y);
    if(finish() == TRUE)
    {
      Preference.finish = TRUE;
      FrmAlert(RCP_Alert_Finish_ID);
    }
  }
}
