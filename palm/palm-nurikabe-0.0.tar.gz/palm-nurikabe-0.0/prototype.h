#ifndef __PROTOTYPE_H
#define __PROTOTYPE_H

/* draw.c */
void load_bitmaps(void);
void draw_cell(int, int);
void redraw(void);
void free_bitmaps(void);

/* event.c */
void event_loop(void);

/* game.c */
void fill_table(char *, int);
void tap_game(int, int);

/* level.c */
boolean_type load_levels(void);
int find_level(level_type *);
boolean_type select_level(int);
void free_levels(void);

/* main.c */
UInt32 make_id(char *);

/* select.c */
boolean_type form_select_execute(int *);

/* table.c */
void clear_table(table_type *);
boolean_type change_cell(int, int, table_type *, int, int);
void copy_table(table_type *, table_type *);

#endif
