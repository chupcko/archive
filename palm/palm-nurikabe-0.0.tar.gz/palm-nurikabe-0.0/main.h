#ifndef __MAIN_H
#define __MAIN_H

#undef EXTERN
#undef INIT
#ifdef __MAIN_C
  #define EXTERN
  #define INIT(...) = __VA_ARGS__
#else
  #define EXTERN extern
  #define INIT(...)
#endif

#include "PalmOS.h"

#include "configuration.h"
#include "type.h"
#include "variable.h"
#include "prototype.h"

#include "resource.h"

#endif
