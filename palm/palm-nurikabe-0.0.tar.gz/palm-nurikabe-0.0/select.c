#include "main.h"

boolean_type form_select_execute(int *index)
{
  FormPtr form;
  ListType *list;
  boolean_type return_value;

  form = FrmInitForm(RCP_Form_Select_ID);
  list = (ListType *)FrmGetObjectPtr(form, FrmGetObjectIndex(form, RCP_Form_Select_List_ID));
  LstSetListChoices(list, List_options, Levels_number);
  LstSetSelection(list, *index);
  LstSetTopItem(list, *index);
  return_value = FALSE;
  if(FrmDoDialog(form) == RCP_Form_Select_Button_OK_ID)
  {
    *index = LstGetSelection(list);
    return_value = TRUE;
  }
  FrmDeleteForm(form);
  return return_value;
}
