#ifndef __VARIABLE_H
#define __VARIABLE_H

EXTERN preference_type Preference;

EXTERN Char **List_options;
EXTERN int Levels_number;
EXTERN level_type *Levels;
EXTERN int Selected_level;

#endif
