#ifndef __PROTOTYPE_H
#define __PROTOTYPE_H

/* event.c */
void event_loop(void);

#endif
