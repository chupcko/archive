#include <stdio.h>

#include "main.h"

static Boolean form_main_event(EventPtr event)
{
  Boolean handled;
  FormPtr form;

  handled = false;
  switch(event->eType)
  {
    case frmOpenEvent:
    case frmUpdateEvent:
      form = FrmGetActiveForm();
      FrmDrawForm(form);
      handled = true;
      break;
    case ctlSelectEvent:
      if(event->data.ctlEnter.controlID == RCP_Form_Main_Button_RESET_ID)
      {
        SysReset();
        handled = true;
      }
      break;
  }
  return handled;
}

#define EVENT_SLEEP evtWaitForever

void event_loop(void)
{
  EventType event;
  UInt16 error;
  Int16 form_id;
  FormPtr form;

  do
  {
    EvtGetEvent(&event, EVENT_SLEEP);
    if(SysHandleEvent(&event) == true)
      continue;
    if(MenuHandleEvent(NULL, &event, &error) == true)
      continue;
    if(event.eType == frmLoadEvent)
    {

      form_id = event.data.frmLoad.formID;
      form = FrmInitForm(form_id);
      FrmSetActiveForm(form);
      if(form_id == RCP_Form_Main_ID)
        FrmSetEventHandler(form, (FormEventHandlerPtr)form_main_event);
    }
    else
      FrmDispatchEvent(&event);
  } while(event.eType != appStopEvent);
}
