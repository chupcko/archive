#ifndef __RESOURCE_H
#define __RESOURCE_H

#define PROGRAM_NAME "Sys Reset"
#define PROGRAM_CREATOR_ID "SyRe"
#define PROGRAM_VERSION "0.0"
#define PROGRAM_AUTHOR "Goran \"CHUPCKO\" Lazic"

#define RCP_ApplicationIconName_ID 1000
#define RCP_Application_ID 1001

#define RCP_String_Info_ID 1100

#define RCP_Form_Main_ID 1200
#define RCP_Form_Main_Button_RESET_ID 1201

#endif
