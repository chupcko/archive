#ifndef __TYPE_H
#define __TYPE_H

typedef enum
{
  FALSE = 0,
  TRUE = 1
} boolean_type;

#endif
