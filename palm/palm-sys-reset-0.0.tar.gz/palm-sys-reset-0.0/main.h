#ifndef __MAIN_H
#define __MAIN_H

#include "PalmOS.h"

#include "type.h"
#include "prototype.h"

#include "resource.h"

#endif
