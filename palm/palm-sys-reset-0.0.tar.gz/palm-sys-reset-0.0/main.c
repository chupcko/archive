#include <stdio.h>

#include "main.h"

UInt32 PilotMain(UInt16 command, void *command_parameters, UInt16 launch_flags)
{
  if(command == sysAppLaunchCmdNormalLaunch)
  {
    FrmGotoForm(RCP_Form_Main_ID);
    event_loop();
    FrmCloseAllForms();
  }
  return 0;
}
