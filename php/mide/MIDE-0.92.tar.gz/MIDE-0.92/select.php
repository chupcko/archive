<?
  if($first!==true)
    die('Internal Error');

  html_begin('Select Database and Table');

  #
?>

<table>
  <form action="<?= $PHP_SELF ?>" method="post">
  <tr>
    <td>Project:</td>
    <td><input type="text" name="project" value="<?= $project ?>"></td>
    <td><input type="submit" value="Change"></td>
  </tr>
  </form>
</table>

<?
  #

  $f1=new DB_Query($db);
  $f2=new DB_Query($db);
  $f1->list_databases();
  if($f1->error!==false)
    return set_error('Permission Denied');

  while($f1->eor()===false)
  {
    if($database!=$f1->field(0))
    {
      #
?>

<a href="<?= $PHP_SELF ?>?database=<?= $f1->field(0) ?>&table="><?= $f1->field(0) ?></a><br>

<?
      #
    }
    else
    {
      #
?>

<b><?= $f1->field(0) ?></b><br>

<?
      #
      $f2->list_tables($database);
      if($f2->error!==false)
        return set_error('Permission Denied');
      while($f2->eor()===false)
      {
        if($table!=$f2->field(0))
        {
          #
?>

&nbsp;&nbsp;&nbsp;<a href="<?= $PHP_SELF ?>?table=<?= $f2->field(0) ?>"><?= $f2->field(0) ?></a><br>

<?
          #
        }
        else
        {
          #
?>

&nbsp;&nbsp;&nbsp;<b><?= $f2->field(0) ?></b><br>

<?
          #
        }
        $f2->next();
      }
    }
    $f1->next();
  }
  $f2->close();
  $f1->close();

  if($table!='')
  {
    #
?>

<hr>
database: <?= $database ?><br>
table: <?= $table ?>
<p>
<a href="<?= $PHP_SELF ?>?generate=index">Generate index.php</a><br>
<a href="<?= $PHP_SELF ?>?generate=error">Generate error.php</a><br>
<a href="<?= $PHP_SELF ?>?generate=session">Generate session.php</a><br>
<a href="<?= $PHP_SELF ?>?generate=session_mysql">Generate session.mysql</a><br>
<a href="<?= $PHP_SELF ?>?generate=DB">Generate DB.php</a>
<p>
<a href="<?= $PHP_SELF ?>?generate=list">Generate code/list.php</a><br>
<a href="<?= $PHP_SELF ?>?generate=simple_list">Generate code/simple_list.php</a><br>
<a href="<?= $PHP_SELF ?>?generate=view">Generate code/view.php</a><br>
<a href="<?= $PHP_SELF ?>?generate=add_form">Generate code/add_form.php</a><br>
<a href="<?= $PHP_SELF ?>?generate=add_confirm">Generate code/add_confirm.php</a><br>
<a href="<?= $PHP_SELF ?>?generate=add">Generate code/add.php</a><br>
<a href="<?= $PHP_SELF ?>?generate=edit_form">Generate code/edit_form.php</a><br>
<a href="<?= $PHP_SELF ?>?generate=edit_confirm">Generate code/edit_confirm.php</a><br>
<a href="<?= $PHP_SELF ?>?generate=edit">Generate code/edit.php</a><br>
<a href="<?= $PHP_SELF ?>?generate=delete_confirm">Generate code/delete_confirm.php</a><br>
<a href="<?= $PHP_SELF ?>?generate=delete">Generate code/delete.php</a>
<p>
<a href="<?= $PHP_SELF ?>?generate=tar.gz">Generate all (tar.gz)</a>

<?
    #
  }

  html_end();
?>
