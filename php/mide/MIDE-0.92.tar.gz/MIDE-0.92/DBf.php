<?

  #
  # DBf 1.2 by CHUPCKO
  #

  class DB_Connection
  {
    var $link_id;
    var $queries;
    var $error;

    function set_error($description)
    {
      $this->error=$description;
      return false;
    }

    function error()
    {
      if($this->error===false)
        return false;
      return 'DB Connection: '.$this->error;
    }

    function DB_Connection($host='localhost',$user='root',$password='')
    {
      if(($this->link_id=@mysql_connect($host,$user,$password))===false)
      {
        $this->link_id=false;
        return $this->set_error('Bad connection parameters');
      }
      $this->queries=false;
      $this->error=false;
      return true;
    }

    function database($database)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      if(@mysql_select_db($database,$this->link_id)===false)
      {
        $this->link_id=false;
        return $this->set_error('Bad database');
      }
      $this->error=false;
      return true;
    }

    function link_id()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      return $this->link_id;
    }

    function register(&$query)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->queries[]=&$query;
    }

    function close()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      if($this->queries!==false)
        foreach($this->queries as $v)
          $v->close();
      @mysql_close($this->link_id);
      $this->link_id=false;
      $this->queries=false;
      $this->error=false;
      return true;
    }
  }

  class DB_Query
  {
    var $link_id;
    var $query_id;

    var $number_rows;
    var $row;

    var $error;

    function set_error($description)
    {
      $this->error=$description;
      return false;
    }

    function error()
    {
      if($this->error===false)
        return false;
      return 'DB Query: '.$this->error;
    }

    function DB_Query(&$connection)
    {
      $this->link_id=$connection->link_id;
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $connection->register($this);
      $this->query_id=false;
      $this->number_rows=false;
      $this->row=false;
      $this->error=false;
      return true;
    }

    function list_databases()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      if($this->query_id!==false)
        @mysql_free_result($this->query_id);
      if(($this->query_id=@mysql_list_dbs($this->link_id))===false)
      {
        $this->query_id=false;
        $this->number_rows=false;
        $this->row=false;
        return $this->set_error('Bad list databases');
      }
      $this->number_rows=@mysql_num_rows($this->query_id);
      $this->row=@mysql_fetch_array($this->query_id);
      $this->error=false;
      return true;
    }

    function list_tables($database)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      if($this->query_id!==false)
        @mysql_free_result($this->query_id);
      if(($this->query_id=@mysql_list_tables($database,$this->link_id))===false)
      {
        $this->query_id=false;
        $this->number_rows=false;
        $this->row=false;
        return $this->set_error('Bad list tables for '.$database);
      }
      $this->number_rows=@mysql_num_rows($this->query_id);
      $this->row=@mysql_fetch_array($this->query_id);
      $this->error=false;
      return true;
    }

    function eor()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->row!==false)
        return false;
      return true;
    }

    function number_rows()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      return $this->number_rows;
    }

    function seek($pos)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->number_rows===false)
        return false;
      @mysql_data_seek($this->query_id,$pos);
      if(($this->row=@mysql_fetch_array($this->query_id))===false)
        return false;
      return true;
    }

    function row()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      return $this->row;
    }

    function field($name)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->row===false)
        return false;
      return $this->row[$name];
    }

    function next()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->row===false or ($this->row=@mysql_fetch_array($this->query_id))===false)
        return false;
      return true;
    }

    function close()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      if($this->query_id!==false)
      {
        @mysql_free_result($this->query_id);
        $this->query_id=false;
      }
      $this->number_rows=false;
      $this->row=false;
      $this->error=false;
      return true;
    }
  }

  class DB_Field
  {
    var $link_id;
    var $query_id;

    var $curent_field;
    var $number_fields;
    var $name;
    var $len;
    var $type;
    var $flags;

    var $error;

    function set_error($description)
    {
      $this->error=$description;
      return false;
    }

    function error()
    {
      if($this->error===false)
        return false;
      return 'DB Field: '.$this->error;
    }

    function DB_Field(&$connection)
    {
      $this->link_id=$connection->link_id;
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $connection->register($this);
      $this->query_id=false;
      $this->current_filed=false;
      $this->number_fields=false;
      $this->name=false;
      $this->len=false;
      $this->type=false;
      $this->flags=false;
      $this->error=false;
      return true;
    }

    function query($database,$table)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      if($this->query_id!==false)
        @mysql_free_result($this->query_id);
      if(($this->query_id=@mysql_list_fields($database,$table,$this->link_id))===false)
      {
        $this->query_id=false;
        $this->number_fields=false;
        $this->name=false;
        $this->len=false;
        $this->type=false;
        $this->flags=false;
        return $this->set_error('Bad query: '.$query);
      }
      $this->number_fields=@mysql_num_fields($this->query_id);
      $this->current_field=0;
      $this->name=@mysql_field_name($this->query_id,$this->current_field);
      $this->len=@mysql_field_len($this->query_id,$this->current_field);
      $this->type=@mysql_field_type($this->query_id,$this->current_field);
      $this->flags=@mysql_field_flags($this->query_id,$this->current_field);
      $this->error=false;
      return true;
    }

    function eor()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->current_field!==false)
        return $this->current_field>=$this->number_fields;
      return true;
    }

    function curent_field()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      return $this->curent_field;
    }

    function number_fields()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      return $this->number_fields;
    }

    function name()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      return $this->name;
    }

    function len()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      return $this->len;
    }

    function type()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      return $this->type;
    }

    function flags()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      return $this->flags;
    }

    function next()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->current_field++;
      $this->name=@mysql_field_name($this->query_id,$this->current_field);
      $this->len=@mysql_field_len($this->query_id,$this->current_field);
      $this->type=@mysql_field_type($this->query_id,$this->current_field);
      $this->flags=@mysql_field_flags($this->query_id,$this->current_field);
      $this->error=false;
      return true;
      return true;
    }

    function close()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      if($this->query_id!==false)
      {
        @mysql_free_result($this->query_id);
        $this->query_id=false;
      }
      $this->current_field=false;
      $this->number_fields=false;
      $this->name=false;
      $this->len=false;
      $this->type=false;
      $this->flags=false;
      $this->error=false;
      return true;
    }
  }
?>
