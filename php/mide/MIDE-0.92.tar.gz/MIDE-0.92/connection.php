<?
  if($first!==true)
    die('Internal Error');

  html_begin('Connection');

  if($error!==false)
  {
    #
?>

<font color="red"><?= $error ?></font>
<hr>

<?
    #
  }
  #
?>

<table>
  <form action="<?= $PHP_SELF ?>" method="post">
  <tr>
    <td>Host:</tr>
    <td><input type="text" name="host" value="<?= $host ?>"></td>
  </tr>
  <tr>
    <td>User:</td>
    <td><input type="text" name="user" value="<?= $user ?>"></td>
  </tr>
  <tr>
    <td>Password:</td>
    <td><input type="password" name="password" value="<?= $password ?>"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" value="Connection"></td>
  </tr>
  </form>
</table>

<?
  #

  html_end();
?>
