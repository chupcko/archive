<?
  if($first!==true)
    die('Internal Error');

  $g_project=$project;
  $g_table=$table;
  $g_headers='';
  foreach(array_merge($id_field,$field) as $v)
    $g_headers.='    <td>'.$v.'</td>'."\n";
  $g_fields='';
  foreach(array_merge($id_field,$field) as $v)
    $g_fields.='    <td><?= '.$project.'_nbsp($'.$project.'_q->field(\''.$v.'\')) ?></td>'."\n";
  $g_id_fields='';
  foreach(array_merge($auto_field,$id_field) as $v)
  {
    if($g_id_fields!='')
      $g_id_fields.='&';
    $g_id_fields.=$v.'=<?= $'.$project.'_q->field(\''.$v.'\') ?>';
  }

  $fd=fopen($in_dir.'simple_list.php.in','r');
  $contents=fread($fd,filesize($in_dir.'simple_list.php.in'));
  fclose($fd);

  $contents=ereg_replace('{{project}}',$g_project,$contents);
  $contents=ereg_replace('{{table}}',$g_table,$contents);
  $contents=ereg_replace('{{headers}}',$g_headers,$contents);
  $contents=ereg_replace('{{fields}}',$g_fields,$contents);
  $contents=ereg_replace('{{id_fields}}',$g_id_fields,$contents);
?>
