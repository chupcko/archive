<?
  if($first!==true)
    die('Internal Error');

  $g_project=$project;
  $g_table=$table;
  $g_fields='';
  foreach(array_merge($id_field,$field) as $v)
    $g_fields.=
       '  <tr>'."\n".
       '    <td>'.$v.':</td>'."\n".
       '    <td><input type="text" name="'.$v.'" value="<?= $'.$v.' ?>"></td>'."\n".
       '  </tr>'."\n";

  $fd=fopen($in_dir.'add_form.php.in','r');
  $contents=fread($fd,filesize($in_dir.'add_form.php.in'));
  fclose($fd);

  $contents=ereg_replace('{{project}}',$g_project,$contents);
  $contents=ereg_replace('{{table}}',$g_table,$contents);
  $contents=ereg_replace('{{fields}}',$g_fields,$contents);
?>
