<?
  if($first!==true)
    die('Internal Error');

  $tar_gz_code='tar c * | gzip -9 -c';

  $tmp_dir='/tmp';
  $code_dir='/code';

  srand((double)microtime()*1000000);
  $uid=md5(uniqid(rand()));

  do
  {
    $root_dir=$tmp_dir.'/MIDE'.md5(uniqid(rand()));
  }
  while(file_exists($root_dir));

  mkdir($root_dir,0755);
  mkdir($root_dir.$code_dir,0755);

  function generate_tar_gz($name,$file)
  {
    global $first;
    global $database;
    global $host;
    global $user;
    global $password;
    global $table;
    global $project;
    global $auto_field;
    global $id_field;
    global $field;
    global $in_dir;
    include('generate_'.$name.'.php');
    $fd=fopen($file,'w');
    fwrite($fd,$contents);
    fclose($fd);
  }

  generate_tar_gz('index',$root_dir.'/index.php');
  generate_tar_gz('error',$root_dir.'/error.php');
  generate_tar_gz('session',$root_dir.'/session.php');
  generate_tar_gz('DB',$root_dir.'/DB.php');
  generate_tar_gz('session_mysql', $root_dir.'/session.mysql');
  generate_tar_gz('list',$root_dir.$code_dir.'/'.$table.'_list.php');
  generate_tar_gz('simple_list',$root_dir.$code_dir.'/'.$table.'_simple_list.php');
  generate_tar_gz('view',$root_dir.$code_dir.'/'.$table.'_view.php');
  generate_tar_gz('add_form',$root_dir.$code_dir.'/'.$table.'_add_form.php');
  generate_tar_gz('add_confirm',$root_dir.$code_dir.'/'.$table.'_add_confirm.php');
  generate_tar_gz('add',$root_dir.$code_dir.'/'.$table.'_add.php');
  generate_tar_gz('edit_form',$root_dir.$code_dir.'/'.$table.'_edit_form.php');
  generate_tar_gz('edit_confirm',$root_dir.$code_dir.'/'.$table.'_edit_confirm.php');
  generate_tar_gz('edit',$root_dir.$code_dir.'/'.$table.'_edit.php');
  generate_tar_gz('delete_confirm',$root_dir.$code_dir.'/'.$table.'_delete_confirm.php');
  generate_tar_gz('delete',$root_dir.$code_dir.'/'.$table.'_delete.php');

  $old_dir=getcwd();
  chdir($root_dir);
  passthru($tar_gz_code);

  function delete_dir($dir)
  {
    $fd=opendir($dir);
    while($file=readdir($fd))
      if($file!='.' and $file!='..')
        if(is_dir($dir.'/'.$file))
          delete_dir($dir.'/'.$file);
        else
          unlink($dir.'/'.$file);
    closedir($fd);
    rmdir($dir);
  }

  chdir($old_dir);
  delete_dir($root_dir);
?>
