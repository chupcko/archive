<?
  if($first!==true)
    die('Internal Error');

  $fd=fopen($in_dir.'DB.php.in','r');
  $contents=fread($fd,filesize($in_dir.'DB.php.in'));
  fclose($fd);
?>
