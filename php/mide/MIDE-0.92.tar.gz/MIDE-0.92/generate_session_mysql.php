<?
  if($first!==true)
    die('Internal Error');

  $fd=fopen($in_dir.'session.mysql.in','r');
  $contents=fread($fd,filesize($in_dir.'session.mysql.in'));
  fclose($fd);
?>
