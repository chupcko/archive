<?
  if($first!==true)
    die('Internal Error');

  $f=new DB_Field($db);
  $f->query($database,$table);
  if($f->error()!==false)
    return set_error('Permission Denied');

  $auto_field=array();
  $id_field=array();
  $field=array();
  while($f->eor()===false)
  {
    if(eregi('primary_key',$f->flags()))
      if(eregi('auto_increment',$f->flags()))
        $auto_field[]=$f->name();
      else
        $id_field[]=$f->name();
    else
      $field[]=$f->name();
    $f->next();
  }
  $f->close();

  $in_dir='in/';

  if($generate=='tar.gz')
  {
    header('Content-type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.$table.'.tar.gz');
    header('Content-Transfer-Encoding: binary');
    include('generate_tar.gz.php');
  }
  elseif(file_exists('generate_'.$generate.'.php'))
  {
#   header('Content-type: text/plain');
    header('Content-type: application/octet-stream');
    switch($generate)
    {
      case 'index':
      case 'error':
      case 'session':
      case 'DB':
        header('Content-Disposition: attachment; filename='.$generate.'.php');
        break;
      case 'session_mysql':
        header('Content-Disposition: attachment; filename=session.mysql');
        break;
      default:
        header('Content-Disposition: attachment; filename='.$table.'_'.$generate.'.php');
    }
    header('Content-Transfer-Encoding: binary');
    include('generate_'.$generate.'.php');
    echo($contents);
  }
  else
    return set_error();
?>
