<?
  if($first!==true)
    die('Internal Error');

  $g_project=$project;
  $g_table=$table;
  $g_id_fields_sql='';
  foreach(array_merge($auto_field,$id_field) as $v)
  {
    if($g_id_fields_sql!='')
      $g_id_fields_sql.=' and ';
    $g_id_fields_sql.=$v.'="\'.$'.$v.'.\'"';
  }
  $g_fields='';
  foreach(array_merge($id_field,$field) as $v)
    $g_fields.=
      '  <tr>'."\n".
      '    <td>'.$v.':</td>'."\n".
      '    <td><?= '.$project.'_nbsp($'.$project.'_q->field(\''.$v.'\')) ?></td>'."\n".
      '  </tr>'."\n";
  $g_id_fields='';
  foreach(array_merge($auto_field,$id_field) as $v)
    $g_id_fields.='  <input type="hidden" name="'.$v.'" value="<?= $'.$v.' ?>">'."\n";

  $fd=fopen($in_dir.'view.php.in','r');
  $contents=fread($fd,filesize($in_dir.'view.php.in'));
  fclose($fd);

  $contents=ereg_replace('{{project}}',$g_project,$contents);
  $contents=ereg_replace('{{table}}',$g_table,$contents);
  $contents=ereg_replace('{{id_fields_sql}}',$g_id_fields_sql,$contents);
  $contents=ereg_replace('{{fields}}',$g_fields,$contents);
  $contents=ereg_replace('{{id_fields}}',$g_id_fields,$contents);
?>
