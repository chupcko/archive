<?
  ini_set('session.use_trans_sid',false);

  function html_begin($title)
  {
    #
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html>
<head><title><?= $title ?></title></head>
<body bgcolor="#FFFFFF" text="#000000" link="#000080" alink="#000080" vlink="#000080">

<?
    #
  }

  function html_end()
  {
    #
?>

<hr>
<b>CHUPCKO</b>
</body>
</html>

<?
    #
  }

  function register($variable,$default=false)
  {
    global $HTTP_GET_VARS;
    global $HTTP_POST_VARS;
    session_register($variable);
    if(isset($GLOBALS[$variable])===false)
      $GLOBALS[$variable]=$default;
    if(isset($HTTP_GET_VARS[$variable])!==false)
      $GLOBALS[$variable]=$HTTP_GET_VARS[$variable];
    if(isset($HTTP_POST_VARS[$variable])!==false)
      $GLOBALS[$variable]=$HTTP_POST_VARS[$variable];
  }

  function set_error($message='Bad call')
  {
    global $error;
    $error=$message;
    return false;
  }

  session_start();
  register('host');
  register('user');
  register('password');
  register('database','');
  register('table','');
  register('project','MIDE');

  $first=true;
  $error=false;

  if($host==='' or $host===false or $user===false or $password===false)
  {
    if($host==='')
      $error='Host is Required';
    include('connection.php');
  }
  else
  {
    include_once('DBf.php');
    $db=new DB_Connection($host,$user,$password);
    if($db->error()!==false)
      $error='Bad Connection Parameters';
    else
    {
      ob_start();
      if(isset($generate)===false)
      {
        include('select.php');
      }
      else
      {
        include('generate.php');
      }
      if($error!==false)
        ob_end_clean();
      else
        ob_end_flush();
    }
    if($error!==false)
    {
      include('connection.php');
    }
    $db->close();
  }
?>
