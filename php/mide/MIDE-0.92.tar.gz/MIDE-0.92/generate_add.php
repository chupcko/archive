<?
  if($first!==true)
    die('Internal Error');

  $g_project=$project;
  $g_table=$table;
  $g_names='';
  foreach(array_merge($id_field,$field) as $v)
  {
    if($g_names!='')
      $g_names.=', ';
    $g_names.=$v;
  }
  $g_values='';
  foreach(array_merge($id_field,$field) as $v)
  {
    if($g_values!='')
      $g_values.=', ';
    $g_values.='"\'.$'.$v.'.\'"';
  }

  $fd=fopen($in_dir.'add.php.in','r');
  $contents=fread($fd,filesize($in_dir.'add.php.in'));
  fclose($fd);

  $contents=ereg_replace('{{project}}',$g_project,$contents);
  $contents=ereg_replace('{{table}}',$g_table,$contents);
  $contents=ereg_replace('{{names}}',$g_names,$contents);
  $contents=ereg_replace('{{values}}',$g_values,$contents);
?>
