<?
  if($first!==true)
    die('Internal Error');

  $g_project=$project;
  $g_table=$table;
  $g_id_fields='';
  foreach(array_merge($auto_field,$id_field) as $v)
  {
    if($g_id_fields!='')
      $g_id_fields.=' and ';
    $g_id_fields.=$v.'="\'.$'.$v.'.\'"';
  }

  $fd=fopen($in_dir.'delete.php.in','r');
  $contents=fread($fd,filesize($in_dir.'delete.php.in'));
  fclose($fd);

  $contents=ereg_replace('{{project}}',$g_project,$contents);
  $contents=ereg_replace('{{table}}',$g_table,$contents);
  $contents=ereg_replace('{{id_fields}}',$g_id_fields,$contents);
?>
