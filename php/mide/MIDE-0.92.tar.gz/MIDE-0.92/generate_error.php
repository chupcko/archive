<?
  if($first!==true)
    die('Internal Error');

  $g_project=$project;
  $g_table=$table;

  $fd=fopen($in_dir.'error.php.in','r');
  $contents=fread($fd,filesize($in_dir.'error.php.in'));
  fclose($fd);

  $contents=ereg_replace('{{project}}',$g_project,$contents);
  $contents=ereg_replace('{{table}}',$g_table,$contents);
?>
