<?
  if($first!==true)
    die('Internal Error');

  $g_project=$project;
  $g_table=$table;
  $g_field_number=(string)(count($id_field)+count($field));
  $g_orders='';
  $i=0;
  foreach(array_merge($id_field,$field) as $v)
  {
    $g_orders.='  $'.$project.'_orders['.$i.']=\''.$v.'\';'."\n";
    $i++;
  }
  $g_where='';
  foreach(array_merge($id_field,$field) as $v)
  {
    if($g_where!='')
      $g_where.=' or ';
    $g_where.=$v.' like "%\'.$'.$table.'_'.$project.'_search.\'%"';
  }
  $g_headers='';
  $i=0;
  foreach(array_merge($id_field,$field) as $v)
  {
    $g_headers.=
      '    if($'.$table.'_'.$project.'_order=='.$i.')'."\n".
      '    {'."\n".
      '      #'."\n".
      '?>'."\n".
      "\n".
      '    <td><a href="<?= $PHP_SELF ?>?'.$table.'_'.$project.'_way=<?= 1-$'.$table.'_'.$project.'_way ?>"><b>'.$v.' <?= $'.$table.'_'.$project.'_way==1?\'+\':\'-\' ?></b></a></td>'."\n".
      "\n".
      '<?'."\n".
      '      #'."\n".
      '    }'."\n".
      '    else'."\n".
      '    {'."\n".
      '      #'."\n".
      '?>'."\n".
      "\n".
      '    <td><a href="<?= $PHP_SELF ?>?'.$table.'_'.$project.'_order='.$i.'&'.$table.'_'.$project.'_way=0">'.$v.'</a></td>'."\n".
      "\n".
      '<?'."\n".
      '      #'."\n".
      '    }'."\n";
    $i++;
  }
  $g_fields='';
  foreach(array_merge($id_field,$field) as $v)
    $g_fields.='    <td><?= '.$project.'_nbsp($'.$project.'_q->field(\''.$v.'\'),$'.$table.'_'.$project.'_search) ?></td>'."\n";
  $g_id_fields='';
  foreach(array_merge($auto_field,$id_field) as $v)
  {
    if($g_id_fields!='')
      $g_id_fields.='&';
    $g_id_fields.=$v.'=<?= $'.$project.'_q->field(\''.$v.'\') ?>';
  }

  $fd=fopen($in_dir.'list.php.in','r');
  $contents=fread($fd,filesize($in_dir.'list.php.in'));
  fclose($fd);

  $contents=ereg_replace('{{project}}',$g_project,$contents);
  $contents=ereg_replace('{{table}}',$g_table,$contents);
  $contents=ereg_replace('{{field_number}}',$g_field_number,$contents);
  $contents=ereg_replace('{{orders}}',$g_orders,$contents);
  $contents=ereg_replace('{{where}}',$g_where,$contents);
  $contents=ereg_replace('{{headers}}',$g_headers,$contents);
  $contents=ereg_replace('{{fields}}',$g_fields,$contents);
  $contents=ereg_replace('{{id_fields}}',$g_id_fields,$contents);
?>
