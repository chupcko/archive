<?
  if($first!==true)
    die('Internal Error');

  $g_project=$project;

  $fd=fopen($in_dir.'session.php.in','r');
  $contents=fread($fd,filesize($in_dir.'session.php.in'));
  fclose($fd);

  $contents=ereg_replace('{{project}}',$g_project,$contents);
?>
