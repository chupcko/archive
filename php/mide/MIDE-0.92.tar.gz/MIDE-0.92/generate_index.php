<?
  if($first!==true)
    die('Internal Error');

  $g_project=$project;
  $g_database=$database;
  $g_host=$host;
  $g_user=$user;
  $g_password=$password;
  $g_table=$table;

  $fd=fopen($in_dir.'index.php.in','r');
  $contents=fread($fd,filesize($in_dir.'index.php.in'));
  fclose($fd);

  $contents=ereg_replace('{{project}}',$g_project,$contents);
  $contents=ereg_replace('{{database}}',$g_database,$contents);
  $contents=ereg_replace('{{host}}',$g_host,$contents);
  $contents=ereg_replace('{{user}}',$g_user,$contents);
  $contents=ereg_replace('{{password}}',$g_password,$contents);
  $contents=ereg_replace('{{table}}',$g_table,$contents);
?>
