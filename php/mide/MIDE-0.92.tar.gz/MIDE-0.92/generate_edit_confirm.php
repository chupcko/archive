<?
  if($first!==true)
    die('Internal Error');

  $g_project=$project;
  $g_table=$table;
  $g_fields='';
  foreach(array_merge($id_field,$field) as $v)
    $g_fields.=
       '  <tr>'."\n".
       '    <td>'.$v.':</td>'."\n".
       '    <td><?= '.$project.'_nbsp($'.$v.') ?></td>'."\n".
       '  </tr>'."\n";
  $g_parameters='';
  foreach(array_merge($auto_field,$id_field,$field) as $v)
    $g_parameters.='  <input type="hidden" name="'.$v.'" value="<?= $'.$v.' ?>">'."\n";

  $fd=fopen($in_dir.'edit_confirm.php.in','r');
  $contents=fread($fd,filesize($in_dir.'edit_confirm.php.in'));
  fclose($fd);

  $contents=ereg_replace('{{project}}',$g_project,$contents);
  $contents=ereg_replace('{{table}}',$g_table,$contents);
  $contents=ereg_replace('{{fields}}',$g_fields,$contents);
  $contents=ereg_replace('{{parameters}}',$g_parameters,$contents);
?>
