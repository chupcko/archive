<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  $MIDE_contents=ereg_replace('{{project}}',$MIDE_generation_project,$MIDE_contents);

?>
