<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  $MIDE_contents=ereg_replace('{{project}}',$MIDE_generation_project,$MIDE_contents);

  $MIDE_contents=ereg_replace('{{database}}',$MIDE_generation_database,$MIDE_contents);

  $MIDE_contents=ereg_replace('{{hostname}}',$MIDE_generation_hostname,$MIDE_contents);

  $MIDE_contents=ereg_replace('{{username}}',$MIDE_generation_username,$MIDE_contents);

  $MIDE_contents=ereg_replace('{{password}}',$MIDE_generation_password,$MIDE_contents);

?>
