<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  $MIDE_r='';
  foreach(array_merge($MIDE_generation_field_primary,$MIDE_generation_field_unique,$MIDE_generation_field_normal) as $MIDE_v)
  {
    if($MIDE_r!='')
      $MIDE_r.=','."\n";
    $MIDE_r.='    $'.$MIDE_v;
  }
  $MIDE_contents=ereg_replace('{{change1}}',$MIDE_r,$MIDE_contents);

  $MIDE_r='';
  foreach($MIDE_generation_field_unique as $MIDE_v)
  {
    if($MIDE_r!='')
      $MIDE_r.=' or'."\n";
    $MIDE_r.='         '.$MIDE_v.'=\\\'\'.$'.$MIDE_v.'.\'\\\'';
  }
  $MIDE_contents=ereg_replace('{{change2}}',$MIDE_r,$MIDE_contents);

  $MIDE_r='';
  foreach($MIDE_generation_field_unique as $MIDE_v)
  {
    if($MIDE_r!='')
      $MIDE_r.=' or ';
    $MIDE_r.=$MIDE_v;
  }
  $MIDE_contents=ereg_replace('{{change3}}',$MIDE_r,$MIDE_contents);

  $MIDE_r='';
  foreach(array_merge($MIDE_generation_field_auto,$MIDE_generation_field_primary) as $MIDE_v)
  {
    if($MIDE_r!='')
      $MIDE_r.=','."\n";
    $MIDE_r.='    $'.$MIDE_v;
  }
  $MIDE_contents=ereg_replace('{{change4}}',$MIDE_r,$MIDE_contents);

  $MIDE_r='';
  foreach(array_merge($MIDE_generation_field_auto,$MIDE_generation_field_primary) as $MIDE_v)
  {
    if($MIDE_r!='')
      $MIDE_r.=' and'."\n";
    $MIDE_r.='         '.$MIDE_v.'=\\\'\'.$'.$MIDE_v.'.\'\\\'';
  }
  $MIDE_contents=ereg_replace('{{change5}}',$MIDE_r,$MIDE_contents);

  $MIDE_r='';
  foreach(array_merge($MIDE_generation_field_auto,$MIDE_generation_field_primary) as $MIDE_v)
  {
    if($MIDE_r!='')
      $MIDE_r.=','."\n";
    $MIDE_r.='    $edit_'.$MIDE_v;
  }
  foreach(array_merge($MIDE_generation_field_primary,$MIDE_generation_field_unique,$MIDE_generation_field_normal) as $MIDE_v)
  {
    if($MIDE_r!='')
      $MIDE_r.=','."\n";
    $MIDE_r.='    $'.$MIDE_v;
  }
  $MIDE_contents=ereg_replace('{{change6}}',$MIDE_r,$MIDE_contents);

  $MIDE_r='';
  foreach(array_merge($MIDE_generation_field_auto,$MIDE_generation_field_primary) as $MIDE_v)
  {
    if($MIDE_r!='')
      $MIDE_r.=' and'."\n";
    $MIDE_r.='         '.$MIDE_v.'<>\\\'\'.$edit_'.$MIDE_v.'.\'\\\'';
  }
  $MIDE_contents=ereg_replace('{{change7}}',$MIDE_r,$MIDE_contents);

  $MIDE_r='';
  foreach(array_merge($MIDE_generation_field_unique,$MIDE_generation_field_normal) as $MIDE_v)
  {
    if($MIDE_r!='')
      $MIDE_r.="\n";
    $MIDE_r.=
      '  function {{project}}_table_{{table}}_return_'.$MIDE_v."\n".
      '  ('."\n";
    $MIDE_t='';
    foreach(array_merge($MIDE_generation_field_auto,$MIDE_generation_field_primary) as $MIDE_w)
    {
      if($MIDE_t!='')
        $MIDE_t.=','."\n";
      $MIDE_t.='    $'.$MIDE_w;
    }
    $MIDE_r.=
      $MIDE_t."\n".
      '  )'."\n".
      '  {'."\n".
      '    global ${{project}}_db;'."\n".
      '    $query=new DB_query(${{project}}_db);'."\n".
      '    $query->query'."\n".
      '    (\''."\n".
      '      select'."\n".
      '         *'."\n".
      '       from'."\n".
      '         {{table}}'."\n".
      '       where'."\n";
    $MIDE_t='';
    foreach(array_merge($MIDE_generation_field_auto,$MIDE_generation_field_primary) as $MIDE_w)
    {
      if($MIDE_t!='')
        $MIDE_t.=' and'."\n";
      $MIDE_t.='         '.$MIDE_w.'=\\\'\'.$'.$MIDE_w.'.\'\\\'';
    }
    $MIDE_r.=
      $MIDE_t."\n".
      '    \');'."\n".
      '    if($query->error()!==false)'."\n".
      '      return {{project}}_set_error($query->error());'."\n".
      '    if($query->number_rows()==0)'."\n".
      '      $return_value={{project}}_set_error(\'No '.$MIDE_v.'\');'."\n".
      '    else'."\n".
      '      $return_value=$query->field(\''.$MIDE_v.'\');'."\n".
      '    $query->close();'."\n".
      '    return $return_value;'."\n".
      '  }'."\n";
  }
  $MIDE_contents=ereg_replace('{{change8}}',$MIDE_r,$MIDE_contents);

  $MIDE_contents=ereg_replace('{{project}}',$MIDE_generation_project,$MIDE_contents);

  $MIDE_contents=ereg_replace('{{table}}',$MIDE_generation_table,$MIDE_contents);

?>
