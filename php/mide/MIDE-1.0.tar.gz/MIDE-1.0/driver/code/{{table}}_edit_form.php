<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  $MIDE_r='';
  foreach(array_merge($MIDE_generation_field_auto,$MIDE_generation_field_primary) as $MIDE_v)
    $MIDE_r.='  {{project}}_register_argument(\'{{project}}_table_{{table}}_field_'.$MIDE_v.'\');'."\n";
  foreach(array_merge($MIDE_generation_field_primary,$MIDE_generation_field_unique,$MIDE_generation_field_normal) as $MIDE_v)
    $MIDE_r.='  {{project}}_register_argument(\'{{project}}_table_{{table}}_edit_field_'.$MIDE_v.'\');'."\n";
  $MIDE_contents=ereg_replace('{{change1}}',$MIDE_r,$MIDE_contents);

  $MIDE_r='';
  foreach(array_merge($MIDE_generation_field_auto,$MIDE_generation_field_primary) as $MIDE_v)
  {
    if($MIDE_r!='')
      $MIDE_r.=' and'."\n";
    $MIDE_r.='      '.$MIDE_v.'=\\\'\'.${{project}}_table_{{table}}_field_'.$MIDE_v.'.\'\\\'';
  }
  $MIDE_contents=ereg_replace('{{change2}}',$MIDE_r,$MIDE_contents);

  $MIDE_r='';
  foreach(array_merge($MIDE_generation_field_primary,$MIDE_generation_field_unique,$MIDE_generation_field_normal) as $MIDE_v)
    $MIDE_r.=
      '  if(isset(${{project}}_table_{{table}}_edit_field_'.$MIDE_v.')===false)'."\n".
      '    ${{project}}_table_{{table}}_edit_field_'.$MIDE_v.'=${{project}}_query->field(\''.$MIDE_v.'\');'."\n";
  $MIDE_contents=ereg_replace('{{change3}}',$MIDE_r,$MIDE_contents);

  $MIDE_r='';
  foreach(array_merge($MIDE_generation_field_auto,$MIDE_generation_field_primary) as $MIDE_v)
    $MIDE_r.='  <input type="hidden" name="{{project}}_table_{{table}}_field_'.$MIDE_v.'" value="<?= ${{project}}_table_{{table}}_field_'.$MIDE_v.' ?>">'."\n";
  $MIDE_contents=ereg_replace('{{change4}}',$MIDE_r,$MIDE_contents);

  $MIDE_r='';
  foreach(array_merge($MIDE_generation_field_primary,$MIDE_generation_field_unique,$MIDE_generation_field_normal) as $MIDE_v)
    $MIDE_r.=
      '  <tr>'."\n".
      '    <td>'.$MIDE_v.':</td>'."\n".
      '    <td><input type="text" name="{{project}}_table_{{table}}_edit_field_'.$MIDE_v.'" value="<?= ${{project}}_table_{{table}}_edit_field_'.$MIDE_v.' ?>"></td>'."\n".
      '  </tr>'."\n";
  $MIDE_contents=ereg_replace('{{change5}}',$MIDE_r,$MIDE_contents);

  $MIDE_contents=ereg_replace('{{project}}',$MIDE_generation_project,$MIDE_contents);

  $MIDE_contents=ereg_replace('{{table}}',$MIDE_generation_table,$MIDE_contents);

?>
