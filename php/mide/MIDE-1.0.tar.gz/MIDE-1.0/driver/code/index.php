<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  $MIDE_contents=ereg_replace('{{project}}',$MIDE_generation_project,$MIDE_contents);

  $MIDE_contents=ereg_replace('{{table}}',$MIDE_generation_table,$MIDE_contents);

?>
