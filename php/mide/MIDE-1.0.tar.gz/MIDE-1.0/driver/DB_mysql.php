<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

?>
