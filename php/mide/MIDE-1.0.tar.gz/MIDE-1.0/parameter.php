<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  error_reporting(E_ALL^E_NOTICE);

  include_once('function.php');

  MIDE_html_begin('MIDE 1.0 by CHUPCKO');

  #
?>

<table>
  <form enctype="multipart/form-data" action="table.php" method="post">
  <tr>
    <td>Project:</tr>
    <td><input type="text" name="MIDE_generation_project" value="MIDE"></td>
  </tr>
  <tr>
    <td>Host:</tr>
    <td><input type="text" name="MIDE_generation_hostname" value="localhost"></td>
  </tr>
  <tr>
    <td>User:</td>
    <td><input type="text" name="MIDE_generation_username" value="root"></td>
  </tr>
  <tr>
    <td>Password:</td>
    <td><input type="text" name="MIDE_generation_password" value=""></td>
  </tr>
  <tr>
    <td>Database:</td>
    <td><input type="text" name="MIDE_generation_database" value=""></td>
  </tr>
  <tr>
    <td>Dia File:</td>
    <td><input type="file" name="MIDE_generation_dia_file" value="none"></td>
  </tr>
  <tr><td colspan="2"><hr></td></tr>
  <tr>
    <td>Table:</td>
    <td><input type="text" name="MIDE_generation_table" value=""></td>
  </tr>
  <tr>
    <td>Number of fields:</td>
    <td><input type="text" size="4" name="MIDE_generation_number_field" value=""></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" value="NEXT"></td>
  </tr>
  </form>
</table>

<?
  #

  MIDE_html_end();

?>
