<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  error_reporting(E_ALL^E_NOTICE);

  if(isset($HTTP_GET_VARS)===false)
    $HTTP_GET_VARS=&$_GET;
  if(isset($HTTP_POST_VARS)===false)
    $HTTP_POST_VARS=&$_POST;

  include_once('function.php');

  MIDE_register_argument('MIDE_generation_project');
  MIDE_register_argument('MIDE_generation_hostname');
  MIDE_register_argument('MIDE_generation_username');
  MIDE_register_argument('MIDE_generation_password');
  MIDE_register_argument('MIDE_generation_database');
  MIDE_register_argument('MIDE_generation_table');
  MIDE_register_argument('MIDE_generation_number_field');
  MIDE_register_argument('MIDE_generation_field');
  MIDE_register_argument('MIDE_generation_type');

  $MIDE_generation_number_field=(int)$MIDE_generation_number_field;
  if($MIDE_generation_number_field<0 or $MIDE_generation_number_field>256)
    $MIDE_generation_number_field=0;

  if($MIDE_generation_number_field==0)
    MIDE_error();

  $MIDE_tar_gz_code='tar c * | gzip -9 -c';

  $MIDE_current_dir=getcwd();
  $MIDE_driver_dir=$MIDE_current_dir.'/driver';
  $MIDE_template_dir=$MIDE_current_dir.'/template';
  $MIDE_tmp_dir='/tmp';
  srand((double)microtime()*1000000);
  do
    $MIDE_root_dir=$MIDE_tmp_dir.'/MIDE'.md5(uniqid(rand(),true));
  while(file_exists(realpath($MIDE_root_dir))!==false);

  function MIDE_generate_file($driver_file,$input_file,$output_file)
  {
    global $MIDE_generation_project;
    global $MIDE_generation_hostname;
    global $MIDE_generation_username;
    global $MIDE_generation_password;
    global $MIDE_generation_database;
    global $MIDE_generation_table;
    global $MIDE_generation_field_auto;
    global $MIDE_generation_field_primary;
    global $MIDE_generation_field_unique;
    global $MIDE_generation_field_normal;
    if(file_exists(realpath($driver_file))!==false and file_exists(realpath($input_file))!==false)
    {
      $fd=fopen($input_file,'r');
      $MIDE_contents=fread($fd,filesize($input_file));
      fclose($fd);
      include($driver_file);
      $output_file=ereg_replace('{{table}}',$MIDE_generation_table,$output_file);
      $fd=fopen($output_file,'w');
      fwrite($fd,$MIDE_contents);
      fclose($fd);
    }
  }

  function MIDE_pass_dir($driver_dir,$input_dir,$output_dir)
  {
    mkdir($output_dir,0755);
    $fd=opendir($driver_dir);
    while(($file=readdir($fd))!==false)
      if($file!='.' and $file!='..')
        if(((bool)is_dir($driver_dir.'/'.$file))!==false)
          MIDE_pass_dir($driver_dir.'/'.$file,$input_dir.'/'.$file,$output_dir.'/'.$file);
        else
          MIDE_generate_file($driver_dir.'/'.$file,$input_dir.'/'.$file,$output_dir.'/'.$file);
    closedir($fd);
  }

  $MIDE_generation_field_auto=array();
  $MIDE_generation_field_primary=array();
  $MIDE_generation_field_unique=array();
  $MIDE_generation_field_normal=array();
  for($MIDE_i=0;$MIDE_i<$MIDE_generation_number_field;$MIDE_i++)
    if($MIDE_generation_field[$MIDE_i]!='')
      switch($MIDE_generation_type[$MIDE_i])
      {
        case 'auto':
          $MIDE_generation_field_auto[]=$MIDE_generation_field[$MIDE_i];
          break;
        case 'primary':
          $MIDE_generation_field_primary[]=$MIDE_generation_field[$MIDE_i];
          break;
        case 'unique':
          $MIDE_generation_field_unique[]=$MIDE_generation_field[$MIDE_i];
          break;
        default:
          $MIDE_generation_field_normal[]=$MIDE_generation_field[$MIDE_i];
      }

  umask(0022);
  MIDE_pass_dir($MIDE_driver_dir,$MIDE_template_dir,$MIDE_root_dir);
  chdir($MIDE_root_dir);
  header('Content-type: application/octet-stream');
  header('Content-Disposition: attachment; filename='.$MIDE_generation_project.'.'.$MIDE_generation_database.'.'.$MIDE_generation_table.'.tar.gz');
  header('Content-Transfer-Encoding: binary');
  passthru($MIDE_tar_gz_code);
  chdir($MIDE_current_dir);
  MIDE_delete_dir($MIDE_root_dir);

?>
