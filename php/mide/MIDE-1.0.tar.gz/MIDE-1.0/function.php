<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  function MIDE_html_begin($title)
  {
    global $MIDE_error;
    global $MIDE_action_array;
    global $MIDE_action_current;

    #
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html>
<head><title><?= $title ?></title></head>
<body bgcolor="#FFFFFF" text="#000000" link="#000080" alink="#000080" vlink="#000080">
<b><?= $title ?></b>
<hr>

<?
    #
  }

  function MIDE_html_end()
  {
    #
?>

<hr>
<b>MIDE 1.0 by CHUPCKO</b>
</body>
</html>

<?
    #
  }

  function MIDE_error()
  {
    MIDE_html_begin('MIDE 1.0 by CHUPCKO');
    #
?>

<b>ERROR!</b>

<?
  #
    MIDE_html_end();
    die();
  }

  function MIDE_register_argument($variable)
  {
    global $HTTP_GET_VARS;
    global $HTTP_POST_VARS;
    if(isset($HTTP_GET_VARS[$variable])!==false)
      $GLOBALS[$variable]=$HTTP_GET_VARS[$variable];
    if(isset($HTTP_POST_VARS[$variable])!==false)
      $GLOBALS[$variable]=$HTTP_POST_VARS[$variable];
  }

  function MIDE_register_file($variable)
  {
    global $HTTP_POST_FILES;
    if(isset($HTTP_POST_FILES[$variable])!==false)
      $GLOBALS[$variable]=$HTTP_POST_FILES[$variable];
  }

  function MIDE_delete_dir($dir)
  {
    $fd=opendir($dir);
    while($file=readdir($fd))
      if($file!='.' and $file!='..')
        if(is_dir($dir.'/'.$file))
          MIDE_delete_dir($dir.'/'.$file);
        else
          unlink($dir.'/'.$file);
    closedir($fd);
    rmdir($dir);
  }

?>
