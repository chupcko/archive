<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  $MIDE_dia_tables=false;
  $MIDE_dia_number_table=0;
  $MIDE_dia_in_object=false;
  $MIDE_dia_in_umlattribute=false;
  $MIDE_dia_in_string=false;
  $MIDE_dia_in_visibility=false;
  $MIDE_dia_expect_table_name=false;
  $MIDE_dia_expect_field_name=false;
  $MIDE_dia_expect_visibility=false;

  function MIDE_xml_element_begin($parser,$name,$attributes)
  {
    global $MIDE_dia_tables;
    global $MIDE_dia_number_table;
    global $MIDE_dia_in_object;
    global $MIDE_dia_in_umlattribute;
    global $MIDE_dia_in_string;
    global $MIDE_dia_in_visibility;
    global $MIDE_dia_expect_table_name;
    global $MIDE_dia_expect_field_name;
    global $MIDE_dia_expect_visibility;

    if($name=='DIA:OBJECT' and $attributes['TYPE']=='UML - Class')
    {
      $MIDE_dia_tables[$MIDE_dia_number_table]['name']='';
      $MIDE_dia_tables[$MIDE_dia_number_table]['number_field']=0;
      $MIDE_dia_in_object=true;
      $MIDE_dia_in_in_umlattribute=false;
      $MIDE_dia_expect_table_name=true;
      $MIDE_dia_expect_field_name=true;
      $MIDE_dia_expect_visibility=false;
    }
    if($name=='DIA:COMPOSITE' and $attributes['TYPE']=='umlattribute')
    {
      $MIDE_dia_in_umlattribute=true;
      $MIDE_dia_expect_field_name=true;
      $MIDE_dia_expect_visibility=true;
      $MIDE_dia_expect_table_name=false;
    }
    if($name=='DIA:ATTRIBUTE' and $attributes['NAME']=='visibility')
      $MIDE_dia_in_visibility=true;
    if($name=='DIA:STRING')
      $MIDE_dia_in_string=true;
    if($name=='DIA:ENUM' and $MIDE_dia_in_visibility!==false and $MIDE_dia_expect_visibility!==false)
    {
      $MIDE_dia_tables[$MIDE_dia_number_table]['fields'][$MIDE_dia_tables[$MIDE_dia_number_table]['number_field']]['type']=$attributes['VAL'];
      $MIDE_dia_expect_visibility=false;
    }
  }

  function MIDE_xml_element_end($parser,$name)
  {
    global $MIDE_dia_tables;
    global $MIDE_dia_number_table;
    global $MIDE_dia_in_object;
    global $MIDE_dia_in_umlattribute;
    global $MIDE_dia_in_string;
    global $MIDE_dia_in_visibility;
    global $MIDE_dia_expect_table_name;
    global $MIDE_dia_expect_field_name;
    global $MIDE_dia_expect_visibility;

    if($name=='DIA:OBJECT' and $MIDE_dia_in_object!==false)
    {
      $MIDE_dia_number_table++;
      $MIDE_dia_in_object=false;
      $MIDE_dia_expect_table_name=false;
      $MIDE_dia_expect_field_name=false;
      $MIDE_dia_expect_visibility=false;
    }
    if($name=='DIA:COMPOSITE' and $MIDE_dia_in_umlattribute!==false)
    {
      $MIDE_dia_tables[$MIDE_dia_number_table]['number_field']++;
      $MIDE_dia_in_umlattribute=false;
      $MIDE_dia_expect_field_name=false;
      $MIDE_dia_expect_visibility=false;
    }
    if($name=='DIA:ATTRIBUTE')
      $MIDE_dia_in_visibility=false;
    if($name=='DIA:STRING')
      $MIDE_dia_in_string=false;
  }

  function MIDE_xml_character_data($parser,$data)
  {
    global $MIDE_dia_tables;
    global $MIDE_dia_number_table;
    global $MIDE_dia_in_string;
    global $MIDE_dia_expect_table_name;
    global $MIDE_dia_expect_field_name;

    if($MIDE_dia_in_string!==false)
    {
      ereg('^#([^#]*)#$',$data,$result);
      if($MIDE_dia_expect_table_name!==false)
      {
        $MIDE_dia_tables[$MIDE_dia_number_table]['name']=$result[1];
        $MIDE_dia_expect_table_name=false;
      }
      if($MIDE_dia_expect_field_name!==false)
      {
        $MIDE_dia_tables[$MIDE_dia_number_table]['fields'][$MIDE_dia_tables[$MIDE_dia_number_table]['number_field']]['name']=$result[1];
        $MIDE_dia_expect_field_name=false;
      }
    }
  }

?>
