<?

  #
  # DB MySQL 1.3
  # MIDE 1.0
  # CHUPCKO
  #

  class DB_connection
  {
    var $link_id;
    var $queries;
    var $error;

    function set_error($description)
    {
      $this->error=$description;
      return false;
    }

    function error()
    {
      if($this->error===false)
        return false;
      return 'DB Connection: '.$this->error;
    }

    function DB_connection($database,$host='localhost',$user='root',$password='')
    {
      if(($this->link_id=@mysql_connect($host,$user,$password))===false)
      {
        $this->link_id=false;
        return $this->set_error('Bad connection parameters');
      }
      if(@mysql_select_db($database,$this->link_id)===false)
      {
        $this->link_id=false;
        return $this->set_error('Bad database');
      }
      $this->queries=false;
      $this->error=false;
      return true;
    }

    function link_id()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      return $this->link_id;
    }

    function register(&$query)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->queries[]=&$query;
    }

    function close()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      if($this->queries!==false)
        foreach($this->queries as $v)
          $v->close();
      @mysql_close($this->link_id);
      $this->link_id=false;
      $this->queries=false;
      $this->error=false;
      return true;
    }
  }

  class DB_query
  {
    var $link_id;
    var $query_id;
    var $row;

    var $error;

    function set_error($description)
    {
      $this->error=$description;
      return false;
    }

    function error()
    {
      if($this->error===false)
        return false;
      return 'DB Query: '.$this->error;
    }

    function DB_query(&$connection)
    {
      $this->link_id=$connection->link_id;
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $connection->register($this);
      $this->query_id=false;
      $this->row=false;
      $this->error=false;
      return true;
    }

    function query($query)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      if($this->query_id!==false)
        @mysql_free_result($this->query_id);
      if(($this->query_id=@mysql_query($query,$this->link_id))===false)
      {
        $this->row=false;
        return $this->set_error('Bad query: '.$query);
      }
      if(eregi('^[[:space:]]*select',$query)!==false)
        $this->row=@mysql_fetch_array($this->query_id);
      else
        $this->row=false;
      $this->error=false;
      return true;
    }

    function eor()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->row!==false)
        return false;
      return true;
    }

    function number_rows()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->query_id===false)
        return false;
      return @mysql_num_rows($this->query_id);
    }

    function affected_rows()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->query_id===false)
        return false;
      return @mysql_affected_rows($this->query_id);
    }

    function insert_id($key=false)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->query_id===false)
        return false;
      return @mysql_insert_id($this->link_id);
    }

    function seek($pos)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->query_id===false)
        return false;
      @mysql_data_seek($this->query_id,$pos);
      if(($this->row=@mysql_fetch_array($this->query_id))===false)
        return false;
      return true;
    }

    function row()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      return $this->row;
    }

    function field($name)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->row===false)
        return false;
      return $this->row[$name];
    }

    function next()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->row===false or ($this->row=@mysql_fetch_array($this->query_id))===false)
        return false;
      return true;
    }

    function close()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      if($this->query_id!==false)
      {
        @mysql_free_result($this->query_id);
        $this->query_id=false;
      }
      $this->row=false;
      $this->error=false;
      return true;
    }
  }

?>
