<?

  #
  # DB PgSQL 1.3
  # MIDE 1.0
  # CHUPCKO
  #

  class DB_connection
  {
    var $link_id;
    var $queries;
    var $error;

    function set_error($description)
    {
      $this->error=$description;
      return false;
    }

    function error()
    {
      if($this->error===false)
        return false;
      return 'DB Connection: '.$this->error;
    }

    function DB_connection($database,$host='localhost',$user='root',$password='')
    {
      if(($this->link_id=@pg_connect('dbname='.$database.' host='.$host.' port=5432 user='.$user.' password='.$password))===false)
      {
        $this->link_id=false;
        return $this->set_error('Bad connection parameters');
      }
      $this->queries=false;
      $this->error=false;
      return true;
    }

    function link_id()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      return $this->link_id;
    }

    function register(&$query)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->queries[]=&$query;
    }

    function close()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      if($this->queries!==false)
        foreach($this->queries as $v)
          $v->close();
      @pg_close($this->link_id);
      $this->link_id=false;
      $this->queries=false;
      $this->error=false;
      return true;
    }
  }

  class DB_query
  {
    var $link_id;
    var $query_id;
    var $pos;
    var $row;

    var $error;

    function set_error($description)
    {
      $this->error=$description;
      return false;
    }

    function error()
    {
      if($this->error===false)
        return false;
      return 'DB Query: '.$this->error;
    }

    function DB_query(&$connection)
    {
      $this->link_id=$connection->link_id;
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $connection->register($this);
      $this->query_id=false;
      $this->pos=false;
      $this->row=false;
      $this->error=false;
      return true;
    }

    function query($query)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      if($this->query_id!==false)
        @pg_free_result($this->query_id);
      if(($this->query_id=@pg_query($this->link_id,$query))===false)
      {
        $this->row=false;
        return $this->set_error('Bad query: '.$query);
      }
      if(eregi('^[[:space:]]*select',$query)!==false)
      {
        $this->pos=0;
        $this->row=@pg_fetch_array($this->query_id,$this->pos);
      }
      else
      {
        $this->pos=false;
        $this->row=false;
      }
      $this->error=false;
      return true;
    }

    function eor()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->row!==false)
        return false;
      return true;
    }

    function number_rows()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->query_id===false)
        return false;
      return @pg_num_rows($this->query_id);
    }

    function affected_rows()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->query_id===false)
        return false;
      return @pg_affected_rows($this->query_id);
    }

    function insert_id($key=false)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->query_id===false)
        return false;
      if(($q=@pg_query($this->link_id,'select currval(\'"'.$key.'"\'::text) as currval'))===false)
        return false;
      if(($r=@pg_fetch_array($q))===false)
        $r['currval']=false;
      @pg_free_result($q);
      return $r['currval'];
    }

    function seek($pos)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->query_id===false)
        return false;
      $this->pos=$pos;
      if(($this->row=@pg_fetch_array($this->query_id,$this->pos))===false)
        return false;
      return true;
    }

    function row()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      return $this->row;
    }

    function field($name)
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
      if($this->row===false)
        return false;
      return $this->row[$name];
    }

    function next()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      $this->error=false;
     $this->pos++;
      if($this->row===false or ($this->row=@pg_fetch_array($this->query_id,$this->pos))===false)
        return false;
      return true;
    }

    function close()
    {
      if($this->link_id===false)
        return $this->set_error('Not connected');
      if($this->query_id!==false)
      {
        @pg_free_result($this->query_id);
        $this->query_id=false;
      }
      $this->row=false;
      $this->error=false;
      return true;
    }
  }

?>
