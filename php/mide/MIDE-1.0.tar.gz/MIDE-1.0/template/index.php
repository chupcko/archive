<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  error_reporting(E_ALL^E_NOTICE);

  if(isset($HTTP_SESSION_VARS)===false)
    $HTTP_SESSION_VARS=&$_SESSION;
  if(isset($HTTP_GET_VARS)===false)
    $HTTP_GET_VARS=&$_GET;
  if(isset($HTTP_POST_VARS)===false)
    $HTTP_POST_VARS=&$_POST;

  include_once('config.php');
  include_once('DB_mysql.php');

  ${{project}}_db=new DB_connection(${{project}}_db_database,${{project}}_db_hostname,${{project}}_db_username,${{project}}_db_password);
  if(${{project}}_db->error()!==false)
    die(${{project}}_db->error());

  include_once('function.php');
  include_once('session.php');

  session_start();

  {{project}}_register_argument('{{project}}_action');
  {{project}}_register_session('{{project}}_message',false);
  {{project}}_register_session('{{project}}_action_current',0);
  {{project}}_register_session('{{project}}_action_array',false);

  if(isset(${{project}}_action)!==false)
    switch(${{project}}_action)
    {
      case '-':
        ${{project}}_action_current--;
        break;
      case '--':
        ${{project}}_i=${{project}}_action_current-1;
        while(${{project}}_i>0)
        {
          if(${{project}}_action_array[${{project}}_i-1]['form']!==false)
            break;
          ${{project}}_i--;
        }
        ${{project}}_action_current=${{project}}_i;
        break;
      default:
        ${{project}}_i=0;
        while(${{project}}_i<${{project}}_action_current)
        {
          if(${{project}}_action==${{project}}_action_array[${{project}}_i]['name'])
            break;
          ${{project}}_i++;
        }
        if(${{project}}_i==${{project}}_action_current)
        {
          ${{project}}_action_array[${{project}}_action_current]['name']=${{project}}_action;
          ${{project}}_action_array[${{project}}_action_current]['form']=false;
          ${{project}}_action_current++;
        }
        else
          ${{project}}_action_current=${{project}}_i+1;
    }
  if(${{project}}_action_current<=0)
  {
    ${{project}}_action_array[0]['name']='index';
    ${{project}}_action_array[0]['form']=false;
    ${{project}}_action_current=1;
  }

  ${{project}}_first=true;
  ${{project}}_error=false;
  ${{project}}_done=false;
  do
  {
    if(${{project}}_action_current<=0)
      die('Internal Error');
    ${{project}}_action=${{project}}_action_array[${{project}}_action_current-1]['name'];
    if(eregi('[.][.]',${{project}}_action)!==false)
      die('Internal Error');
    if(file_exists(realpath(${{project}}_code_dir.${{project}}_action.'.php'))===false)
    {
      ${{project}}_action_current--;
      ${{project}}_error='Page Not Found';
    }
    else
    {
      ob_start();
      include(${{project}}_code_dir.${{project}}_action.'.php');
      if(${{project}}_error!==false)
      {
        ob_end_clean();
        ${{project}}_action_current--;
      }
      else
      {
        ob_end_flush();
        ${{project}}_done=true;
      }
    }
  }
  while(${{project}}_done===false);

  session_write_close();

  ${{project}}_db->close();

?>
