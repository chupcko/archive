<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  ${{project}}_db_database='{{database}}';
  ${{project}}_db_hostname='{{hostname}}';
  ${{project}}_db_username='{{username}}';
  ${{project}}_db_password='{{password}}';

  ${{project}}_session=false;

  ${{project}}_code_dir='code/';

?>
