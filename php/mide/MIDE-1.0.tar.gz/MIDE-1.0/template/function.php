<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  function {{project}}_html_begin($title,$form=false)
  {
    global ${{project}}_message;
    global ${{project}}_error;
    global ${{project}}_action_array;
    global ${{project}}_action_current;
    ${{project}}_action_array[${{project}}_action_current-1]['form']=$form;

    #
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html>
<head><title><?= $title ?></title></head>
<body bgcolor="#FFFFFF" text="#000000" link="#000080" alink="#000080" vlink="#000080">
<b><?= $title ?></b>
<hr>

<?
    #
    if(${{project}}_message!==false)
    {
      #
?>

<font color="blue"><?= ${{project}}_message ?></font>
<hr>

<?
      #
      ${{project}}_message=false;
    }
    if(${{project}}_error!==false)
    {
      #
?>

<font color="red"><b>Error:</b> <?= ${{project}}_error ?></font>
<hr>

<?
      #
      ${{project}}_error=false;
    }
  }

  function {{project}}_html_end()
  {
    #
?>

<hr>
<b>MIDE 1.0 by CHUPCKO</b>
</body>
</html>

<?
    #
  }

  function {{project}}_set_error($message='Bad call')
  {
    global ${{project}}_error;
    ${{project}}_error=$message;
    return false;
  }

  function {{project}}_set_message($message='Done')
  {
    global ${{project}}_message;
    ${{project}}_message=$message;
  }

  function {{project}}_reload($new_action,$extra='')
  {
    global $PHP_SELF;
    if($extra!='')
      header('Location: '.$PHP_SELF.'?{{project}}_action='.$new_action.'&'.$extra);
    else
      header('Location: '.$PHP_SELF.'?{{project}}_action='.$new_action);
  }

  function {{project}}_register_session($variable,$default=false)
  {
    global $HTTP_SESSION_VARS;
    session_register($variable);
    $GLOBALS[$variable]=&$HTTP_SESSION_VARS[$variable];
    if(isset($GLOBALS[$variable])===false)
      $GLOBALS[$variable]=$default;
  }

  function {{project}}_register_argument($variable)
  {
    global $HTTP_GET_VARS;
    global $HTTP_POST_VARS;
    if(isset($HTTP_GET_VARS[$variable])!==false)
      $GLOBALS[$variable]=$HTTP_GET_VARS[$variable];
    if(isset($HTTP_POST_VARS[$variable])!==false)
      $GLOBALS[$variable]=$HTTP_POST_VARS[$variable];
  }

  function {{project}}_echo($s,$b='')
  {
    if($s=='')
      return '&nbsp;';
    if($b!='')
      return eregi_replace($b,'<b>\0</b>',$s);
    return $s;
  }

?>
