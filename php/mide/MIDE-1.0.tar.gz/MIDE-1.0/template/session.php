<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  if(${{project}}_session!==false)
  {
    ${{project}}_session_table='session';
    ${{project}}_session_query=false;
    ${{project}}_session_name=false;

    function {{project}}_session_open($path,$name)
    {
      global ${{project}}_db;
      global ${{project}}_session_query;
      global ${{project}}_session_name;
      ${{project}}_session_query=new DB_query(${{project}}_db);
      if(${{project}}_session_query->error()!==false)
        return false;
      ${{project}}_session_name=$name;
      return true;
    }

    function {{project}}_session_close()
    {
      global ${{project}}_session_query;
      ${{project}}_session_query->close();
      return true;
    }

    function {{project}}_session_read($key)
    {
      global ${{project}}_session_query;
      global ${{project}}_session_table;
      global ${{project}}_session_name;
      ${{project}}_session_query->query
      ('
        select
          *
        from
          '.${{project}}_session_table.'
        where
          name="'.${{project}}_session_name.'" and
          id="'.$key.'"
      ');
      if(${{project}}_session_query->error()!==false)
        return false;
      if(${{project}}_session_query->number_rows()==0)
        return false;
      return base64_decode(${{project}}_session_query->field('data'));
    }

    function {{project}}_session_write($key,$data)
    {
      global ${{project}}_session_query;
      global ${{project}}_session_table;
      global ${{project}}_session_name;
      ${{project}}_session_query->query
      ('
        select
          *
        from
          '.${{project}}_session_table.'
        where
          name="'.${{project}}_session_name.'" and
          id="'.$key.'"
      ');
      if(${{project}}_session_query->error()!==false)
        return false;
      if(${{project}}_session_query->number_rows()==0)
      {
        ${{project}}_session_query->query
        ('
          insert into
            '.${{project}}_session_table.'
          (
            name,
            id,
            data,
            date
          )
          values
          (
            "'.${{project}}_session_name.'",
            "'.$key.'",
            "'.base64_encode($data).'"
            ,now()
          )
        ');
        if(${{project}}_session_query->error()!==false)
          return false;
      }
      else
      {
        ${{project}}_session_query->query
        ('
          update
            '.${{project}}_session_table.'
          set
            data="'.base64_encode($data).'",
            date=now()
          where
            name="'.${{project}}_session_name.'" and
            id="'.$key.'"
        ');
        if(${{project}}_session_query->error()!==false)
          return false;
      }
      return true;
    }

    function {{project}}_session_destroy($key)
    {
      global ${{project}}_session_query;
      global ${{project}}_session_table;
      global ${{project}}_session_name;
      ${{project}}_session_query->query
      ('
        delete from
          '.${{project}}_session_table.'
        where
          name="'.${{project}}_session_name.'" and
          id="'.$key.'"
      ');
      if(${{project}}_session_query->error()!==false)
        return false;
      return true;
    }

    function {{project}}_session_gc($maxlifetime)
    {
      global ${{project}}_session_query;
      global ${{project}}_session_table;
      global ${{project}}_session_name;
      ${{project}}_session_query->query
      ('
        delete from
          '.${{project}}_session_table.'
        where
          name="'.${{project}}_session_name.'" and
          unix_timestamp()-unix_timestamp(date)>"'.$maxlifetime.'"
      ');
      if(${{project}}_session_query->error()!==false)
        return false;
      return true;
    }

    session_set_save_handler('{{project}}_session_open','{{project}}_session_close','{{project}}_session_read','{{project}}_session_write','{{project}}_session_destroy','{{project}}_session_gc');
    session_name('{{project}}');
  }

?>
