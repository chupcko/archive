<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  if(${{project}}_first!==true)
    die('internal Error');

  include_once('{{table}}.php');

  if(${{project}}_table_{{table}}_delete_confirm===false)
    include('{{table}}_delete.php');
  else
  {
    {{project}}_html_begin('{{table}} - Delete Confirm');

    ${{project}}_query=new DB_query(${{project}}_db);

{{change1}}
    ${{project}}_query->query
    ('
      select
        *
      from
        {{table}}
      where
{{change2}}
    ');
    if(${{project}}_query->error()!==false)
      return {{project}}_set_error(${{project}}_query->error());
    if(${{project}}_query->number_rows()==0)
      return {{project}}_set_error();

    #
?>

<table>
<form action="<?= $PHP_SELF ?>" method="GET">
  <input type="hidden" name="{{project}}_action" value="{{table}}_delete">
{{change3}}
{{change4}}
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" value="DELETE"></td>
  </tr>
</form>
<form action="<?= $PHP_SELF ?>" method="GET">
  <input type="hidden" name="{{project}}_action" value="-">
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" value="CANCEL"></td>
  </tr>
</form>
</table>

<?
    #

    ${{project}}_query->close();

    {{project}}_html_end();
  }

?>
