<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  if(${{project}}_first!==true)
    die('internal Error');

  include_once('{{table}}.php');

  {{project}}_html_begin('{{table}} - Add Form');

{{change1}}
  #
?>

<table>
<form action="<?= $PHP_SELF ?>" method="GET">
  <input type="hidden" name="{{project}}_action" value="{{table}}_add_confirm">
{{change2}}
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" value="ADD"></td>
  </tr>
</form>
<form action="<?= $PHP_SELF ?>" method="GET">
  <input type="hidden" name="{{project}}_action" value="-">
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" value="CANCEL"></td>
  </tr>
</form>
</table>

<?
  #

  {{project}}_html_end();

?>
