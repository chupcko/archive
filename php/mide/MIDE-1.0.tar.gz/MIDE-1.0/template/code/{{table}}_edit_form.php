<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  if(${{project}}_first!==true)
    die('internal Error');

  include_once('{{table}}.php');

  {{project}}_html_begin('{{table}} - Edit Form');

{{change1}}
  ${{project}}_query=new DB_query(${{project}}_db);

  ${{project}}_query->query
  ('
    select
      *
    from
      {{table}}
    where
{{change2}}
  ');
  if(${{project}}_query->error()!==false)
    return {{project}}_set_error(${{project}}_query->error());
  if(${{project}}_query->number_rows()==0)
    return {{project}}_set_error();

{{change3}}
  #
?>

<table>
<form action="<?= $PHP_SELF ?>" method="GET">
  <input type="hidden" name="{{project}}_action" value="{{table}}_edit_confirm">
{{change4}}
{{change5}}
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" value="EDIT"></td>
  </tr>
</form>
<form action="<?= $PHP_SELF ?>" method="GET">
  <input type="hidden" name="{{project}}_action" value="-">
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" value="CANCEL"></td>
  </tr>
</form>
</table>

<?
  #

  ${{project}}_query->close();

  {{project}}_html_end();

?>
