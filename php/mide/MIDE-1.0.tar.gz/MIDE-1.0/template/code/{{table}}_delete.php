<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  if(${{project}}_first!==true)
    die('internal Error');

  include_once('{{table}}.php');

  if(${{project}}_table_{{table}}_delete===false)
    return {{project}}_set_error('Permission Denied');

{{change1}}
  {{project}}_table_{{table}}_check_delete
  (
{{change2}}
  );
  if(${{project}}_error!==false)
    return false;

  ${{project}}_query=new DB_query(${{project}}_db);

  ${{project}}_query->query
  ('
    delete from
      {{table}}
    where
{{change3}}
  ');
  if(${{project}}_query->error()!==false)
    return {{project}}_set_error(${{project}}_query->error());

  ${{project}}_query->close();

  {{project}}_set_message('Deleted');
  {{project}}_reload('{{table}}_list');

?>
