<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  if(${{project}}_first!==true)
    die('internal Error');

  include_once('{{table}}.php');
  ${{project}}_action='index';

  {{project}}_html_begin('Welcome',true);

  #
?>

<a href="<?= $PHP_SELF ?>?{{project}}_action={{table}}_list">LIST</a>

<?
  #

  {{project}}_html_end();

?>
