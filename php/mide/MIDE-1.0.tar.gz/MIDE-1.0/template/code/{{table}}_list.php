<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  if(${{project}}_first!==true)
    die('internal Error');

  include_once('{{table}}.php');

  {{project}}_html_begin('{{table}} - List',true);

  ${{project}}_query=new DB_query(${{project}}_db);

{{change1}}
{{change2}}
  {{project}}_register_session('{{project}}_table_{{table}}_order_query',false);
  {{project}}_register_argument('{{project}}_table_{{table}}_order');
  {{project}}_register_argument('{{project}}_table_{{table}}_way');
  {{project}}_register_session('{{project}}_table_{{table}}_count',10);
  {{project}}_register_argument('{{project}}_table_{{table}}_count');
  {{project}}_register_session('{{project}}_table_{{table}}_search','');
  {{project}}_register_argument('{{project}}_table_{{table}}_search');
  {{project}}_register_session('{{project}}_table_{{table}}_position',1);
  {{project}}_register_argument('{{project}}_table_{{table}}_position');

  if(${{project}}_table_{{table}}_order_query===false)
    foreach(${{project}}_field as ${{project}}_k=>${{project}}_v)
    {
      ${{project}}_table_{{table}}_order_query[${{project}}_k]['name']=${{project}}_v;
      ${{project}}_table_{{table}}_order_query[${{project}}_k]['way']=0;
      ${{project}}_table_{{table}}_order_query[${{project}}_k]['order']=${{project}}_k;
    }

  ${{project}}_table_{{table}}_count=(int)${{project}}_table_{{table}}_count;
  if(${{project}}_table_{{table}}_count<1)
    ${{project}}_table_{{table}}_count=1;

  ${{project}}_search='';
  if(${{project}}_table_{{table}}_search!='')
  {
    foreach(${{project}}_search_field as ${{project}}_k=>${{project}}_v)
    {
      if(${{project}}_search!='')
        ${{project}}_search.=' or ';
      ${{project}}_search.=${{project}}_v.' like \'%'.${{project}}_table_{{table}}_search.'%\'';
    }
    ${{project}}_search=' and ( '.${{project}}_search.' )';
  }

  if(isset(${{project}}_table_{{table}}_order)!==false)
  {
    ${{project}}_table_{{table}}_order=(int)${{project}}_table_{{table}}_order;
    if(${{project}}_table_{{table}}_order<0 or ${{project}}_table_{{table}}_order>=count(${{project}}_field))
      ${{project}}_table_{{table}}_order=0;
    foreach(${{project}}_table_{{table}}_order_query as ${{project}}_k=>${{project}}_v)
      if(${{project}}_table_{{table}}_order_query[${{project}}_k]['order']<${{project}}_table_{{table}}_order_query[${{project}}_table_{{table}}_order]['order'])
        ${{project}}_table_{{table}}_order_query[${{project}}_k]['order']++;
    ${{project}}_table_{{table}}_order_query[${{project}}_table_{{table}}_order]['order']=0;
  }

  if(isset(${{project}}_table_{{table}}_way)!==false)
  {
    ${{project}}_table_{{table}}_way=(int)${{project}}_table_{{table}}_way;
    if(${{project}}_table_{{table}}_way!=0 and ${{project}}_table_{{table}}_way!=1)
      ${{project}}_table_{{table}}_way=0;
    foreach(${{project}}_table_{{table}}_order_query as ${{project}}_k=>${{project}}_v)
      if(${{project}}_table_{{table}}_order_query[${{project}}_k]['order']==0)
        ${{project}}_table_{{table}}_order_query[${{project}}_k]['way']=${{project}}_table_{{table}}_way;
  }

  ${{project}}_table_{{table}}_order=0;
  ${{project}}_table_{{table}}_way=0;
  foreach(${{project}}_table_{{table}}_order_query as ${{project}}_k=>${{project}}_v)
  {
    if(${{project}}_table_{{table}}_order_query[${{project}}_k]['order']==0)
    {
      ${{project}}_table_{{table}}_order=${{project}}_k;
      ${{project}}_table_{{table}}_way=${{project}}_table_{{table}}_order_query[${{project}}_k]['way'];
    }
    ${{project}}_order[${{project}}_table_{{table}}_order_query[${{project}}_k]['order']]=${{project}}_table_{{table}}_order_query[${{project}}_k]['name'];
    if(${{project}}_table_{{table}}_order_query[${{project}}_k]['way']==1)
      ${{project}}_order[${{project}}_table_{{table}}_order_query[${{project}}_k]['order']].=' desc';
  }
  ksort(${{project}}_order);
  ${{project}}_order_query='';
  foreach(${{project}}_order as ${{project}}_k=>${{project}}_v)
  {
    if(${{project}}_order_query!='')
      ${{project}}_order_query.=', ';
    ${{project}}_order_query.=${{project}}_v;
  }

  ${{project}}_query->query
  ('
    select
      *
    from
      {{table}}
    where
      1=1
      '.${{project}}_search.'
    order by
      '.${{project}}_order_query
  );
  if(${{project}}_query->error()!==false)
    return {{project}}_set_error(${{project}}_query->error());
  ${{project}}_count=${{project}}_query->number_rows();

  if(${{project}}_count==0)
  {
    if(${{project}}_table_{{table}}_search!='')
    {
      #
?>

<table>
  <tr>
<form action="<?= $PHP_SELF?>" method="GET">
    <td>
      <input type="text" name="{{project}}_table_{{table}}_search" value="<?= ${{project}}_table_{{table}}_search ?>">
      <input type="submit" value="SEARCH">
    </td>
</form>
<form action="<?= $PHP_SELF?>" method="GET">
  <input type="hidden" name="{{project}}_table_{{table}}_search" value="">
    <td>
      <input type="submit" value="ALL">
    </td>
</form>
  </tr>
</table>

<?
      #
    }
    #
?>

<b>Empty Set</b>

<?
    #
  }
  else
  {
    ${{project}}_table_{{table}}_position=(int)${{project}}_table_{{table}}_position;
    if(${{project}}_table_{{table}}_position>${{project}}_count)
      ${{project}}_table_{{table}}_position=${{project}}_count-${{project}}_table_{{table}}_count;
    if(${{project}}_table_{{table}}_position<1)
      ${{project}}_table_{{table}}_position=1;
    ${{project}}_query->seek(${{project}}_table_{{table}}_position-1);

    #
?>

<table>
  <tr>
    <td>

<?
    #
    if(${{project}}_table_{{table}}_position>1)
    {
      #
?>

      <a href="<?= $PHP_SELF ?>?{{project}}_table_{{table}}_position=1">&lt;&lt;</a>

<?
      #
    }
    else
    {
      #
?>

      &lt;&lt;

<?
      #
    }
    #
?>

    </td>
    <td>

<?
    #
    if(${{project}}_table_{{table}}_position>${{project}}_table_{{table}}_count)
    {
      #
?>

      <a href="<?= $PHP_SELF ?>?{{project}}_table_{{table}}_position=<?= ${{project}}_table_{{table}}_position-${{project}}_table_{{table}}_count ?>">&lt;</a>

<?
      #
    }
    else
    {
      #
?>

      &lt;

<?
      #
    }
    #
?>

    </td>
<form action="<?= $PHP_SELF?>" method="GET">
    <td>
      <input type="text" size="4" name="{{project}}_table_{{table}}_position" value="<?= ${{project}}_table_{{table}}_position ?>">
      <input type="submit" value="Go To">
      - <?= min(${{project}}_count,${{project}}_table_{{table}}_position+${{project}}_table_{{table}}_count-1) ?>
      of <?= ${{project}}_count ?>
    </td>
</form>
<form action="<?= $PHP_SELF?>" method="GET">
    <td>
      <input type="text" size="4" name="{{project}}_table_{{table}}_count" value="<?= ${{project}}_table_{{table}}_count ?>">
      <input type="submit" value="On Page">
    </td>
</form>
    <td>

<?
    #
    if(${{project}}_table_{{table}}_position+${{project}}_table_{{table}}_count<=${{project}}_count)
    {
      #
?>

      <a href="<?= $PHP_SELF ?>?{{project}}_table_{{table}}_position=<?= ${{project}}_table_{{table}}_position+${{project}}_table_{{table}}_count ?>">&gt;</a>

<?
      #
    }
    else
    {
      #
?>

      &gt;

<?
      #
    }
    #
?>

    </td>
    <td>

<?
    #
    if(${{project}}_table_{{table}}_position<=${{project}}_count-${{project}}_table_{{table}}_count)
    {
      #
?>

      <a href="<?= $PHP_SELF ?>?{{project}}_table_{{table}}_position=<?= (int)(${{project}}_count/${{project}}_table_{{table}}_count)*${{project}}_table_{{table}}_count+1 ?>">&gt;&gt;</a>

<?
      #
    }
    else
    {
      #
?>

      &gt;&gt;

<?
      #
    }
    #
?>

    </td>
<form action="<?= $PHP_SELF?>" method="GET">
    <td>
      <input type="text" name="{{project}}_table_{{table}}_search" value="<?= ${{project}}_table_{{table}}_search ?>">
      <input type="submit" value="SEARCH">
    </td>
</form>

<?
    #
    if(${{project}}_table_{{table}}_search!='')
    {
      #
?>

<form action="<?= $PHP_SELF?>" method="GET">
  <input type="hidden" name="{{project}}_table_{{table}}_search" value="">
    <td>
      <input type="submit" value="ALL">
    </td>
</form>

<?
      #
    }
    #
?>

  </tr>
</table>
<table border="1">
  <tr>
<?
    #
    if(${{project}}_table_{{table}}_view!==false)
    {
      #
?>

    <td>&nbsp;</td>

<?
      #
    }
    if(${{project}}_table_{{table}}_edit!==false)
    {
      #
?>

    <td>&nbsp;</td>

<?
      #
    }
    if(${{project}}_table_{{table}}_delete!==false)
    {
      #
?>

    <td>&nbsp;</td>

<?
      #
    }

    ${{project}}_i=0;
{{change3}}
    #
?>

  </tr>

<?
    #
    for(${{project}}_i=${{project}}_table_{{table}}_position-1;${{project}}_i<min(${{project}}_count,${{project}}_table_{{table}}_position+${{project}}_table_{{table}}_count-1);${{project}}_i++)
    {
      #
?>

  <tr>

<?
      #
      if(${{project}}_table_{{table}}_view!==false)
      {
        #
?>

    <td><a href="<?= $PHP_SELF ?>?{{project}}_action={{table}}_view&{{change4}}">V</a></td>

<?
        #
      }
      if(${{project}}_table_{{table}}_edit!==false)
      {
        #
?>

    <td><a href="<?= $PHP_SELF ?>?{{project}}_action={{table}}_edit_form&{{change5}}">E</a></td>

<?
        #
      }
      if(${{project}}_table_{{table}}_delete!==false)
      {
        #
?>

    <td><a href="<?= $PHP_SELF ?>?{{project}}_action={{table}}_delete_confirm&{{change5}}">D</a></td>

<?
        #
      }
      #
?>

{{change6}}
  </tr>

<?
      #
      ${{project}}_query->next();
    }
    #
?>

</table>

<?
    #
  }

  if(${{project}}_table_{{table}}_add!==false)
  {
    #
?>

<table>
<form action="<?= $PHP_SELF ?>" method="GET">
  <input type="hidden" name="{{project}}_action" value="{{table}}_add_form">
  <tr>
    <td><input type="submit" value="ADD"></td>
  </tr>
</form>
</table>

<?
    #
  }

  ${{project}}_query->close();

  {{project}}_html_end();

?>
