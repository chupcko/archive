<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  if(${{project}}_first!==true)
    die('internal Error');

  include_once('{{table}}.php');

  if(${{project}}_table_{{table}}_edit===false)
    return {{project}}_set_error('Permission Denied');

{{change1}}
  {{project}}_table_{{table}}_check_edit
  (
{{change2}}
  );
  if(${{project}}_error!==false)
    return false;

  ${{project}}_query=new DB_query(${{project}}_db);

  ${{project}}_query->query
  ('
    update
      {{table}}
    set
{{change3}}
    where
{{change4}}
  ');
  if(${{project}}_query->error()!==false)
    return {{project}}_set_error(${{project}}_query->error());

  ${{project}}_query->close();

{{change5}}
  {{project}}_set_message('Edited');
  {{project}}_reload('--');

?>
