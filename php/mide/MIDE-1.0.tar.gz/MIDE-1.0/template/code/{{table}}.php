<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  if(${{project}}_first!==true)
    die('internal Error');

  ${{project}}_table_{{table}}_add=true;
  ${{project}}_table_{{table}}_add_confirm=true;
  ${{project}}_table_{{table}}_delete=true;
  ${{project}}_table_{{table}}_delete_confirm=true;
  ${{project}}_table_{{table}}_edit=true;
  ${{project}}_table_{{table}}_edit_confirm=true;
  ${{project}}_table_{{table}}_view=true;

  function {{project}}_table_{{table}}_echo_order($name,$order)
  {
    global $PHP_SELF;
    global ${{project}}_table_{{table}}_order;
    global ${{project}}_table_{{table}}_way;
    if(${{project}}_table_{{table}}_order==$order)
    {
      #
?>

    <td><a href="<?= $PHP_SELF ?>?{{project}}_table_{{table}}_way=<?= 1-${{project}}_table_{{table}}_way ?>&{{project}}_table_{{table}}_position=1"><b><?= $name ?> <?= ${{project}}_table_{{table}}_way==1?'+':'-' ?></b></a></td>

<?
      #
    }
    else
    {
      #
?>

    <td><a href="<?= $PHP_SELF ?>?{{project}}_table_{{table}}_order=<?= $order ?>&{{project}}_table_{{table}}_way=0&{{project}}_table_{{table}}_position=1"><?= $name ?></a></td>

<?
      #
    }
  }

  function {{project}}_table_{{table}}_check_add
  (
{{change1}}
  )
  {
    global ${{project}}_db;
    $query=new DB_query(${{project}}_db);
    $query->query
    ('
      select
         *
       from
         {{table}}
       where
{{change2}}
    ');
    if($query->error()!==false)
      return {{project}}_set_error($query->error());
    $return_value=true;
    if($query->number_rows()!=0)
      $return_value={{project}}_set_error('Duplicate {{change3}}');
    $query->close();
    return $return_value;
  }

  function {{project}}_table_{{table}}_check_delete
  (
{{change4}}
  )
  {
    global ${{project}}_db;
    $query=new DB_query(${{project}}_db);
    $query->query
    ('
      select
         *
       from
         {{table}}
       where
{{change5}}
    ');
    if($query->error()!==false)
      return {{project}}_set_error($query->error());
    $return_value=true;
    if($query->number_rows()==0)
      $return_value={{project}}_set_error('No Exist');
    $query->close();
    return $return_value;
  }

  function {{project}}_table_{{table}}_check_edit
  (
{{change6}}
  )
  {
    global ${{project}}_db;
    $query=new DB_query(${{project}}_db);
    $query->query
    ('
      select
         *
       from
         {{table}}
       where
       (
{{change2}}
       ) and
{{change7}}
    ');
    if($query->error()!==false)
      return {{project}}_set_error($query->error());
    $return_value=true;
    if($query->number_rows()!=0)
      $return_value={{project}}_set_error('Duplicate {{change3}}');
    $query->close();
    return $return_value;
  }

{{change8}}
?>
