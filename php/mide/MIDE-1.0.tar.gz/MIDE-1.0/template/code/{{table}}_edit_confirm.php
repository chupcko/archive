<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  if(${{project}}_first!==true)
    die('internal Error');

  include_once('{{table}}.php');

  if(${{project}}_table_{{table}}_edit_confirm===false)
    include('{{table}}_edit.php');
  else
  {
    {{project}}_html_begin('{{table}} - Edit Confirm');

{{change1}}
    {{project}}_table_{{table}}_check_edit
    (
{{change2}}
    );
    if(${{project}}_error!==false)
      return false;

    #
?>

<table>
<form action="<?= $PHP_SELF ?>" method="GET">
  <input type="hidden" name="{{project}}_action" value="{{table}}_edit">
{{change3}}
{{change4}}
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" value="EDIT"></td>
  </tr>
</form>
<form action="<?= $PHP_SELF ?>" method="GET">
  <input type="hidden" name="{{project}}_action" value="{{table}}_edit_form">
{{change3}}
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" value="CANCEL"></td>
  </tr>
</form>
</table>

<?
    #

    {{project}}_html_end();
  }

?>
