<?

  #
  # MIDE 1.0
  # CHUPCKO
  #

  error_reporting(E_ALL^E_NOTICE);

  if(isset($HTTP_GET_VARS)===false)
    $HTTP_GET_VARS=&$_GET;
  if(isset($HTTP_POST_VARS)===false)
    $HTTP_POST_VARS=&$_POST;
  if(isset($HTTP_POST_FILES)===false)
    $HTTP_POST_FILES=&$_FILES;

  include_once('function.php');

  MIDE_register_argument('MIDE_generation_project');
  MIDE_register_argument('MIDE_generation_hostname');
  MIDE_register_argument('MIDE_generation_username');
  MIDE_register_argument('MIDE_generation_password');
  MIDE_register_argument('MIDE_generation_database');
  MIDE_register_argument('MIDE_generation_table');
  MIDE_register_argument('MIDE_generation_number_field');
  MIDE_register_file('MIDE_generation_dia_file');

  function MIDE_generation_table_html_begin($table,$number_field)
  {
    global $MIDE_generation_project;
    global $MIDE_generation_hostname;
    global $MIDE_generation_username;
    global $MIDE_generation_password;
    global $MIDE_generation_database;

    #
?>

<h1><?= $MIDE_generation_database ?>.<?= $table ?></h1>
<table>
  <form action="generation.php" method="post">
    <input type="hidden" name="MIDE_generation_project" value="<?= $MIDE_generation_project ?>">
    <input type="hidden" name="MIDE_generation_hostname" value="<?= $MIDE_generation_hostname ?>">
    <input type="hidden" name="MIDE_generation_username" value="<?= $MIDE_generation_username ?>">
    <input type="hidden" name="MIDE_generation_password" value="<?= $MIDE_generation_password ?>">
    <input type="hidden" name="MIDE_generation_database" value="<?= $MIDE_generation_database ?>">
    <input type="hidden" name="MIDE_generation_table" value="<?= $table ?>">
    <input type="hidden" name="MIDE_generation_number_field" value="<?= $number_field ?>">
  <tr>
    <td>&nbsp;</tr>
    <td>Name</td>
    <td>Auto</td>
    <td>Primary</td>
    <td>Unique</td>
    <td>Normal</td>
  </tr>

<?
    #
  }

  function MIDE_generation_table_html_end()
  {

    #
?>

  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" value="GENERATION"></td>
  </tr>
  </form>
</table>

<?
    #
  }

  MIDE_html_begin('MIDE 1.0 by CHUPCKO');

  if($MIDE_generation_dia_file['name']!='')
  {
    include_once('dia.php');
    $MIDE_fd=gzopen($MIDE_generation_dia_file['tmp_name'],'r');
    if($MIDE_fd===false)
      MIDE_error();

    $MIDE_xml=xml_parser_create();
    xml_parser_set_option($MIDE_xml,XML_OPTION_CASE_FOLDING,true);
    xml_set_element_handler($MIDE_xml,'MIDE_xml_element_begin','MIDE_xml_element_end');
    xml_set_character_data_handler($MIDE_xml,'MIDE_xml_character_data');
    $MIDE_data='';
    while(gzeof($MIDE_fd)===false)
      $MIDE_data.=gzread($MIDE_fd,4096);
    if(!xml_parse($MIDE_xml,$MIDE_data,true))
      MIDE_error();
    xml_parser_free($MIDE_xml);

    for($MIDE_i=0;$MIDE_i<$MIDE_dia_number_table;$MIDE_i++)
    {
      if($MIDE_i>0)
      {
        #
?>

<hr>

<?
        #
      }
      MIDE_generation_table_html_begin($MIDE_dia_tables[$MIDE_i]['name'],$MIDE_dia_tables[$MIDE_i]['number_field']);
      for($MIDE_j=0;$MIDE_j<$MIDE_dia_tables[$MIDE_i]['number_field'];$MIDE_j++)
      {
        #
?>

  <tr>
    <td>Field <?= $MIDE_j+1 ?>:</tr>
    <td><input type="text" name="MIDE_generation_field[<?= $MIDE_j ?>]" value="<?= $MIDE_dia_tables[$MIDE_i]['fields'][$MIDE_j]['name'] ?>"></td>
    <td><input type="radio" name="MIDE_generation_type[<?= $MIDE_j ?>]" value="auto"<?= $MIDE_dia_tables[$MIDE_i]['fields'][$MIDE_j]['type']==0?' checked':'' ?>></td>
    <td><input type="radio" name="MIDE_generation_type[<?= $MIDE_j ?>]" value="primary"<?= $MIDE_dia_tables[$MIDE_i]['fields'][$MIDE_j]['type']==1?' checked':'' ?>></td>
    <td><input type="radio" name="MIDE_generation_type[<?= $MIDE_j ?>]" value="unique"<?= $MIDE_dia_tables[$MIDE_i]['fields'][$MIDE_j]['type']==2?' checked':'' ?>></td>
    <td><input type="radio" name="MIDE_generation_type[<?= $MIDE_j ?>]" value="normal"<?= $MIDE_dia_tables[$MIDE_i]['fields'][$MIDE_j]['type']==3?' checked':'' ?>></td>
  </tr>

<?

        #
      }
      MIDE_generation_table_html_end();
    }
  }
  else
  {
    $MIDE_generation_number_field=(int)$MIDE_generation_number_field;
    if($MIDE_generation_number_field<0 or $MIDE_generation_number_field>256)
      $MIDE_generation_number_field=0;

    if($MIDE_generation_table=='' or $MIDE_generation_number_field==0)
      MIDE_error();

    MIDE_generation_table_html_begin($MIDE_generation_table,$MIDE_generation_number_field);
    for($MIDE_i=0;$MIDE_i<$MIDE_generation_number_field;$MIDE_i++)
    {
      #
?>

  <tr>
    <td>Field <?= $MIDE_i+1 ?>:</tr>
    <td><input type="text" name="MIDE_generation_field[<?= $MIDE_i ?>]" value=""></td>
    <td><input type="radio" name="MIDE_generation_type[<?= $MIDE_i ?>]" value="auto"></td>
    <td><input type="radio" name="MIDE_generation_type[<?= $MIDE_i ?>]" value="primary"></td>
    <td><input type="radio" name="MIDE_generation_type[<?= $MIDE_i ?>]" value="unique"></td>
    <td><input type="radio" name="MIDE_generation_type[<?= $MIDE_i ?>]" value="normal" checked></td>
  </tr>

<?

      #
    }
    MIDE_generation_table_html_end();
  }

  MIDE_html_end();

?>
