#!/bin/sh

ALBUMPERFORMER="RefACD `cat VERSION`"
PERFORMER="RefACD `cat VERSION`"
ALBUMTITLE="RefACD `cat VERSION`"

SINUS=./sinus
LINEAR=./linear
EXPONENTIAL=./exponential
WHITE=./white
PINK=./pink

if [ ! \( -x $SINUS -a -x $LINEAR -a -x $EXPONENTIAL -a -x $WHITE -a -x $PINK \) ] ; then
  echo "First Do 'make'"
  exit 1
fi

TIMES=20
TIMEM=60
TIMEL=180
OUTDIR=out
OUT=${OUTDIR}/cdr
COUNTN=0

if [ ! -d $OUTDIR ] ; then
  mkdir $OUTDIR >& /dev/null
  if [ $? != 0 ] ; then
    echo "Write Error (mkdir)"
    exit 2
  fi
fi

function create()
{
  COMMAND=$1
  ARGUMENTS=$2
  FILE=$3
  DESCRIPTIONS=$4

  let COUNTN=COUNTN+1
  COUNT=$(printf %02d $COUNTN)

  $COMMAND $ARGUMENTS > ${OUT}_${COUNT}_${FILE}.cdr
  cat <<EOF > ${OUT}_${COUNT}_${FILE}.inf
Albumperformer='${ALBUMPERFORMER}'
Performer='${PERFORMER}'
Albumtitle='${ALBUMTITLE}'
Tracktitle='${DESCRIPTIONS}'
Tracknumber=${COUNTN}
EOF
}

create \
  $SINUS \
  "-v -t $TIMEM -l 0.0 -r 0.0" \
  zero-INFdb \
  'Digital Zero -INFdb'

create \
  $SINUS \
  "-v -t $TIMEM 440.0" \
  440.0Hz_0db \
  'Sinus 440.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMEM -l 0.75 -r 0.75 440.0" \
  440.0Hz_-2.5db \
  'Sinus 440.0Hz -2.5db'
create \
  $SINUS \
  "-v -t $TIMEM -l 0.5  -r 0.5 440.0" \
  440.0Hz_-6db \
  'Sinus 440.0Hz -6db'
create \
  $SINUS \
  "-v -t $TIMEM -l 0.25 -r 0.25 440.0" \
  440.0Hz_-12db \
  'Sinus 440.0Hz -12db'
create \
  $SINUS \
  "-v -t $TIMEM -l 0.0 -L 1.0 -r 0.0 -R 1.0 440.0" \
  440.0Hz_fade_in \
  'Sinus 440.0Hz Fade In -INFdb .. 0db'
create \
  $SINUS \
  "-v -t $TIMEM -l 1.0 -L 0.0 -r 1.0 -R 0.0 440.0" \
  440.0Hz_fade_out \
  'Sinus 440.0Hz Fade Out 0db .. -INFdb'
create \
  $SINUS \
  "-v -t $TIMEM -r 0.0 440.0" \
  440.0Hz_left_0db \
  'Sinus 440.0Hz Left 0db'
create \
  $SINUS \
  "-v -t $TIMEM -l 0.0 440.0" \
  440.0Hz_right_0db \
  'Sinus 440.0Hz Right 0db'
create \
  $SINUS \
  "-v -t $TIMEM -p 440.0" \
  440.0Hz_phase_0db \
  'Sinus 440.0Hz Phase 0db'

create \
  $SINUS \
  "-v -t $TIMEM 1000.0" \
  1000.0Hz_0db \
  'Sinus 1000.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMEM -l 0.75 -r 0.75 1000.0" \
  1000.0Hz_-2.5db \
  'Sinus 1000.0Hz -2.5db'
create \
  $SINUS \
  "-v -t $TIMEM -l 0.5 -r 0.5 1000.0" \
  1000.0Hz_-6db \
  'Sinus 1000.0Hz -6db'
create \
  $SINUS \
  "-v -t $TIMEM -l 0.25 -r 0.25 1000.0" \
  1000.0Hz_-12db \
  'Sinus 1000.0Hz -12db'
create \
  $SINUS \
  "-v -t $TIMEM -l 0.0 -L 1.0 -r 0.0 -R 1.0 1000.0" \
  1000.0Hz_fade_in \
  'Sinus 1000.0Hz Fade In -INFdb .. 0db'
create \
  $SINUS \
  "-v -t $TIMEM -l 1.0 -L 0.0 -r 1.0 -R 0.0 1000.0" \
  1000.0Hz_fade_out \
  'Sinus 1000.0Hz Fade Out 0db .. -INFdb'
create \
  $SINUS \
  "-v -t $TIMEM -r 0.0 1000.0" \
  1000.0Hz_left_0db \
  'Sinus 1000.0Hz Left 0db'
create \
  $SINUS \
  "-v -t $TIMEM -l 0.0 1000.0" \
  1000.0Hz_right_0db \
  'Sinus 1000.0Hz Right 0db'
create \
  $SINUS \
  "-v -t $TIMEM -p 1000.0" \
  1000.0Hz_phase_0db \
  'Sinus 1000.0Hz Phase 0db'

create \
  $SINUS \
  "-v -t $TIMEM 10000.0" \
  10000.0Hz_0db \
  'Sinus 10000.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMEM -l 0.75 -r 0.75 10000.0" \
  10000.0Hz_-2.5db \
  'Sinus 10000.0Hz -2.5db'
create \
  $SINUS \
  "-v -t $TIMEM -l 0.5 -r 0.5 10000.0" \
  10000.0Hz_-6db \
  'Sinus 10000.0Hz -6db'
create \
  $SINUS \
  "-v -t $TIMEM -l 0.25 -r 0.25 10000.0" \
  10000.0Hz_-12db \
  'Sinus 10000.0Hz -12db'
create \
  $SINUS \
  "-v -t $TIMEM -l 0.0 -L 1.0 -r 0.0 -R 1.0 10000.0" \
  10000.0Hz_fade_in \
  'Sinus 10000.0Hz Fade In -INFdb .. 0db'
create \
  $SINUS \
  "-v -t $TIMEM -l 1.0 -L 0.0 -r 1.0 -R 0.0 10000.0" \
  10000.0Hz_fade_out \
  'Sinus 10000.0Hz Fade Out 0db .. -INFdb'
create \
  $SINUS \
  "-v -t $TIMEM -r 0.0 10000.0" \
  10000.0Hz_left_0db \
  'Sinus 10000.0Hz Left 0db'
create \
  $SINUS \
  "-v -t $TIMEM -l 0.0 10000.0" \
  10000.0Hz_right_0db \
  'Sinus 10000.0Hz Right 0db'
create \
  $SINUS \
  "-v -t $TIMEM -p 10000.0" \
  10000.0Hz_phase_0db \
  'Sinus 10000.0Hz Phase 0db'

create \
  $SINUS \
  "-v -t $TIMES 20.0" \
  iso_20.0Hz_0db \
  'Sinus ISO 20.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 25.0" \
  iso_25.0Hz_0db \
  'Sinus ISO 25.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 31.5" \
  iso_31.5Hz_0db \
  'Sinus ISO 31.5Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 40.0" \
  iso_40.0Hz_0db \
  'Sinus ISO 40.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 50.0" \
  iso_50.0Hz_0db \
  'Sinus ISO 50.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 63.0" \
  iso_63.0Hz_0db \
  'Sinus ISO 63.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 80.0" \
  iso_80.0Hz_0db \
  'Sinus ISO 80.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 100.0" \
  iso_100.0Hz_0db \
  'Sinus ISO 100.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 125.0" \
  iso_125.0Hz_0db \
  'Sinus ISO 125.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 160.0" \
  iso_160.0Hz_0db \
  'Sinus ISO 160.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 200.0" \
  iso_200.0Hz_0db \
  'Sinus ISO 200.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 250.0" \
  iso_250.0Hz_0db \
  'Sinus ISO 250.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 315.0" \
  iso_315.0Hz_0db \
  'Sinus ISO 315.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 400.0" \
  iso_400.0Hz_0db \
  'Sinus ISO 400.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 500.0" \
  iso_500.0Hz_0db \
  'Sinus ISO 500.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 630.0" \
  iso_630.0Hz_0db \
  'Sinus ISO 630.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 800.0" \
  iso_800.0Hz_0db \
  'Sinus ISO 800.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 1000.0" \
  iso_1000.0Hz_0db \
  'Sinus ISO 1000.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 1250.0" \
  iso_1250.0Hz_0db \
  'Sinus ISO 1250.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 1600.0" \
  iso_1600.0Hz_0db \
  'Sinus ISO 1600.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 2000.0" \
  iso_2000.0Hz_0db \
  'Sinus ISO 2000.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 2500.0" \
  iso_2500.0Hz_0db \
  'Sinus ISO 2500.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 3150.0" \
  iso_3150.0Hz_0db \
  'Sinus ISO 3150.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 4000.0" \
  iso_4000.0Hz_0db \
  'Sinus ISO 4000.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 5000.0" \
  iso_5000.0Hz_0db \
  'Sinus ISO 5000.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 6300.0" \
  iso_6300.0Hz_0db \
  'Sinus ISO 6300.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 8000.0" \
  iso_8000.0Hz_0db \
  'Sinus ISO 8000.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 10000.0" \
  iso_10000.0Hz_0db \
  'Sinus ISO 10000.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 12500.0" \
  iso_12500.0Hz_0db \
  'Sinus ISO 12500.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 16000.0" \
  iso_16000.0Hz_0db \
  'Sinus ISO 16000.0Hz 0db'
create \
  $SINUS \
  "-v -t $TIMES 20000.0" \
  iso_20000.0Hz_0db \
  'Sinus ISO 20000.0Hz 0db'

create \
  $LINEAR \
  "-v -t $TIMEM 20.0 20000.0" \
  linear_20.0Hz-20000.0Hz_0db \
  'Sinus Linear Sweep 20.0Hz .. 20000.0Hz 0db'
create \
  $LINEAR \
  "-v -t $TIMEM 20000.0 20.0" \
  linear_20000.0Hz-20.0Hz_0db \
  'Sinus Linear Sweep 20000.0Hz .. 20.0Hz 0db'

create \
  $EXPONENTIAL \
  "-v -t $TIMEM 20.0 20000.0" \
  exponential_20.0Hz-20000.0Hz_0db \
  'Sinus Exponential Sweep 20.0Hz .. 20000.0Hz 0db'
create \
  $EXPONENTIAL \
  "-v -t $TIMEM 20000.0 20.0" \
  exponential_20000.0Hz-20.0Hz_0db \
  'Sinus Exponential Sweep 20000.0Hz .. 20.0Hz 0db'

create \
  $WHITE \
  "-v -t $TIMEL" \
  white_noise_0db \
  'White Noise 0db'
create \
  $WHITE \
  "-v -t $TIMEL -m" \
  white_noise_mono_0db \
  'White Noise Mono 0db'
create \
  $WHITE \
  "-v -t $TIMEL -m -p" \
  white_noise_mono_phase_0db \
  'White Noise Mono Phase 0db'

create \
  $PINK \
  "-v -t $TIMEL" \
  pink_noise_0db \
  'Pink Noise 0db'
create \
  $PINK \
  "-v -t $TIMEL -m" \
  pink_noise_mono_0db \
  'Pink Noise Mono 0db'
create \
  $PINK \
  "-v -t $TIMEL -m -p" \
  pink_noise_mono_phase_0db \
  'Pink Noise Mono Phase 0db'
