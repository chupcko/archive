#ifndef TOOL_H
#define TOOL_H

#define DOUBLE_M (((double)INT16_MAX+(double)INT16_MIN)/2)
#define DOUBLE_S (((double)INT16_MAX-(double)INT16_MIN)/2)

int16_t convert_double_to_int16(double v)
{
  return (int16_t)(DOUBLE_M+DOUBLE_S*v);
}

void write_int16(FILE *f,int16_t l,int16_t r)
{
  uint8_t b;

  b=(uint8_t)((l>>8)&0xff);
  fwrite(&b,sizeof(b),1,f);
  b=(uint8_t)(l&0xff);
  fwrite(&b,sizeof(b),1,f);

  b=(uint8_t)((r>>8)&0xff);
  fwrite(&b,sizeof(b),1,f);
  b=(uint8_t)(r&0xff);
  fwrite(&b,sizeof(b),1,f);
}

void init_double_random(void)
{
  srand((unsigned)time(NULL));
}

double double_random(void)
{
  return 2.0*(double)rand()/(double)(RAND_MAX-1)-1.0;
}

#endif
