#include "config.h"
#include "tool.h"

void help(void)
{
  fprintf
  (
    stderr,
    "Usage: pink [ switches ]\n"
    "Version: %s\n"
    "Switches:\n"
    "\t-t time\t\tduration in time secundes, default 60\n"
    "\t-l level\tleft level [0.0-1.0], default 1.0\n"
    "\t-r level\tright level [0.0-1.0], default 1.0\n"
    "\t-p\t\tchange right phase, default off\n"
    "\t-m\t\tmono, default off\n"
    "\t-v\t\tverbose, default off\n",
    VERSION
  );
  exit(1);
}

#define PINK_MAX_ROWS 32

typedef struct t_pink
{
  int number;
  int index;
  int mask;
  double sum;
  double rows[PINK_MAX_ROWS];
} pink;

void init_pink(pink *p,int n)
{
  int i;
  p->number=n;
  p->index=0;
  p->mask=(1<<n)-1;
  p->sum=0.0;
  for(i=0;i<n;i++)
    p->rows[i]=0.0;
  init_double_random();
}

double generate_pink(pink *p)
{
  p->index++;
  p->index&=p->mask;
  if(p->index)
  {
    int i;
    int n;
    n=p->index;
    i=0;
    while(!(n&1))
    {
      n=n>>1;
      i++;
    }
    p->sum-=p->rows[i];
    p->rows[i]=double_random();
    p->sum+=p->rows[i];
  }
  return (p->sum+double_random())/(double)(p->number+1);
}

int main(int argc,char *argv[])
{
  int time=60;
  double left=1.0;
  double right=1.0;
  double phase=1.0;
  int mono=0;
  int verbose=0;

  int t;
  long r;
  pink p;

  int c;
  opterr=0;
  while(1)
  {
    c=getopt(argc,argv,"t:l:r:pmv");
    if(c==-1)
      break;
    switch(c)
    {
      case 't':
        time=abs(atoi(optarg));
        break;
      case 'l':
        left=fabs(atof(optarg));
        break;
      case 'r':
        right=fabs(atof(optarg));
        break;
      case 'p':
        phase=-1.0;
        break;
      case 'm':
        mono=1;
        break;
      case 'v':
        verbose=1;
        break;
      default:
        help();
    }
  }
  if(argc>optind)
    help();
  if(verbose)
    fprintf
    (
      stderr,
      "pink noise:\n"
      "\ttime: %d\n"
      "\tleft volume: %f\n"
      "\tright volume: %f\n"
      "\tright phase: %f\n"
      "\tmono: %s\n",
      time,left,right,phase,mono?"yes":"no"
    );

  init_pink(&p,16);
  for(t=0;t<time;t++)
    for(r=0;r<RATE;r++)
    {
      double s;
      s=generate_pink(&p);
      if(mono)
        write_int16(stdout,convert_double_to_int16(left*s),convert_double_to_int16(phase*right*s));
      else
        write_int16(stdout,convert_double_to_int16(left*s),convert_double_to_int16(phase*right*generate_pink(&p)));
    }
  return 0;
}
