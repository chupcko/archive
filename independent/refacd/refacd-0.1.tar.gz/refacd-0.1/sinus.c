#include "config.h"
#include "tool.h"

void help(void)
{
  fprintf
  (
    stderr,
    "Usage: sinus [ switches ] [ frequency ]\n"
    "Version: %s\n"
    "Switches:\n"
    "\t-t time\t\tduration in time secundes, default 60\n"
    "\t-l level\tleft begin level [0.0-1.0], default 1.0\n"
    "\t-L level\tleft end level [0.0-1.0], default same as begin level\n"
    "\t-r level\tright begin level [0.0-1.0], default 1.0\n"
    "\t-R level\tright end level [0.0-1.0], default same as begin level\n"
    "\t-p\t\tchange right phase, default off\n"
    "\t-v\t\tverbose, default off\n",
    VERSION
  );
  exit(1);
}

int main(int argc,char *argv[])
{
  int time=60;
  double left_begin=1.0;
  double left_end=1.0;
  int left_end_set=0;
  double right_begin=1.0;
  double right_end=1.0;
  int right_end_set=0;
  double phase=1.0;
  double fq=1000.0;
  int verbose=0;

  int t;
  long r;
  double time_rate;

  int c;
  opterr=0;
  while(1)
  {
    c=getopt(argc,argv,"t:l:L:r:R:pv");
    if(c==-1)
      break;
    switch(c)
    {
      case 't':
        time=abs(atoi(optarg));
        break;
      case 'l':
        left_begin=fabs(atof(optarg));
        break;
      case 'L':
        left_end=fabs(atof(optarg));
        left_end_set=1;
        break;
      case 'r':
        right_begin=fabs(atof(optarg));
        break;
      case 'R':
        right_end=fabs(atof(optarg));
        right_end_set=1;
        break;
      case 'p':
        phase=-1.0;
        break;
      case 'v':
        verbose=1;
        break;
      default:
        help();
    }
  }
  if(argc>optind)
  {
    fq=fabs(atof(argv[optind]));
    optind++;
    if(argc>optind)
      help();
  }
  if(!left_end_set)
    left_end=left_begin;
  if(!right_end_set)
    right_end=right_begin;
  if(verbose)
    fprintf
    (
      stderr,
      "sinus:\n"
      "\ttime: %d\n"
      "\tleft begin volume: %f\n"
      "\tleft end volume: %f\n"
      "\tright begin volume: %f\n"
      "\tright end volume: %f\n"
      "\tright phase: %f\n"
      "\tfrequency: %f\n",
      time,left_begin,left_end,right_begin,right_end,phase,fq
    );

  left_end-=left_begin;
  right_end-=right_begin;
  time_rate=(double)((long)time*RATE);
  for(t=0;t<time;t++)
    for(r=0;r<RATE;r++)
    {
      double n;
      double s;
      n=(double)((long)t*RATE+r);
      s=sin(2.0*M_PI*fq*n/(double)RATE);
      write_int16(stdout,convert_double_to_int16((left_begin+left_end*n/time_rate)*s),convert_double_to_int16(phase*(right_begin+right_end*n/time_rate)*s));
    }
  return 0;
}
