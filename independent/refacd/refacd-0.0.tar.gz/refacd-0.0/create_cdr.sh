#!/bin/sh

SINUS=./sinus
LINEAR=./linear
EXPONENTIAL=./exponential
WHITE=./white
PINK=./pink

if [ ! \( -x $SINUS -a -x $LINEAR -a -x $EXPONENTIAL -a -x $WHITE -a -x $PINK \) ] ; then
  echo "First make"
  exit 1
fi

TIME=60
OUT=cdr
COUNT=0
COUNT2=00

function inc()
{
  let COUNT=COUNT+1
  COUNT2=`printf %02d $COUNT`
}

$SINUS       -t $TIME       -l 0    -r 0                  > ${OUT}_${COUNT2}_zero-INFdb.cdr
inc

$SINUS       -t $TIME                         440         > ${OUT}_${COUNT2}_440Hz_0db.cdr
inc
$SINUS       -t $TIME       -l 0.75 -r 0.75   440         > ${OUT}_${COUNT2}_440Hz_-2.5db.cdr
inc
$SINUS       -t $TIME       -l 0.5  -r 0.5    440         > ${OUT}_${COUNT2}_440Hz_-6db.cdr
inc
$SINUS       -t $TIME       -l 0.25 -r 0.25   440         > ${OUT}_${COUNT2}_440Hz_-12db.cdr
inc
$SINUS       -t $TIME               -r 0      440         > ${OUT}_${COUNT2}_440Hz_left_0db.cdr
inc
$SINUS       -t $TIME       -l 0              440         > ${OUT}_${COUNT2}_440Hz_right_0db.cdr
inc
$SINUS       -t $TIME    -p                   440         > ${OUT}_${COUNT2}_440Hz_phase_0db.cdr
inc

$SINUS       -t $TIME                        1000         > ${OUT}_${COUNT2}_1000Hz_0db.cdr
inc
$SINUS       -t $TIME       -l 0.75 -r 0.75  1000         > ${OUT}_${COUNT2}_1000Hz_-2.5db.cdr
inc
$SINUS       -t $TIME       -l 0.5  -r 0.5   1000         > ${OUT}_${COUNT2}_1000Hz_-6db.cdr
inc
$SINUS       -t $TIME       -l 0.25 -r 0.25  1000         > ${OUT}_${COUNT2}_1000Hz_-12db.cdr
inc
$SINUS       -t $TIME               -r 0     1000         > ${OUT}_${COUNT2}_1000Hz_left_0db.cdr
inc
$SINUS       -t $TIME       -l 0             1000         > ${OUT}_${COUNT2}_1000Hz_right_0db.cdr
inc
$SINUS       -t $TIME    -p                  1000         > ${OUT}_${COUNT2}_1000Hz_phase_0db.cdr
inc

$SINUS       -t $TIME                       10000         > ${OUT}_${COUNT2}_10000Hz_0db.cdr
inc
$SINUS       -t $TIME       -l 0.75 -r 0.75 10000         > ${OUT}_${COUNT2}_10000Hz_-2.5db.cdr
inc
$SINUS       -t $TIME       -l 0.5  -r 0.5  10000         > ${OUT}_${COUNT2}_10000Hz_-6db.cdr
inc
$SINUS       -t $TIME       -l 0.25 -r 0.25 10000         > ${OUT}_${COUNT2}_10000Hz_-12db.cdr
inc
$SINUS       -t $TIME               -r 0    10000         > ${OUT}_${COUNT2}_10000Hz_left_0db.cdr
inc
$SINUS       -t $TIME       -l 0            10000         > ${OUT}_${COUNT2}_10000Hz_right_0db.cdr
inc
$SINUS       -t $TIME    -p                 10000         > ${OUT}_${COUNT2}_10000Hz_phase_0db.cdr
inc

$SINUS       -t $TIME                          20         > ${OUT}_${COUNT2}_iso_20Hz_0db.cdr
inc
$SINUS       -t $TIME                          25         > ${OUT}_${COUNT2}_iso_25Hz_0db.cdr
inc
$SINUS       -t $TIME                          31.5       > ${OUT}_${COUNT2}_iso_31.5Hz_0db.cdr
inc
$SINUS       -t $TIME                          40         > ${OUT}_${COUNT2}_iso_40Hz_0db.cdr
inc
$SINUS       -t $TIME                          50         > ${OUT}_${COUNT2}_iso_50Hz_0db.cdr
inc
$SINUS       -t $TIME                          63         > ${OUT}_${COUNT2}_iso_63Hz_0db.cdr
inc
$SINUS       -t $TIME                          80         > ${OUT}_${COUNT2}_iso_80Hz_0db.cdr
inc
$SINUS       -t $TIME                         100         > ${OUT}_${COUNT2}_iso_100Hz_0db.cdr
inc
$SINUS       -t $TIME                         125         > ${OUT}_${COUNT2}_iso_125Hz_0db.cdr
inc
$SINUS       -t $TIME                         160         > ${OUT}_${COUNT2}_iso_160Hz_0db.cdr
inc
$SINUS       -t $TIME                         200         > ${OUT}_${COUNT2}_iso_200Hz_0db.cdr
inc
$SINUS       -t $TIME                         250         > ${OUT}_${COUNT2}_iso_250Hz_0db.cdr
inc
$SINUS       -t $TIME                         315         > ${OUT}_${COUNT2}_iso_315Hz_0db.cdr
inc
$SINUS       -t $TIME                         400         > ${OUT}_${COUNT2}_iso_400Hz_0db.cdr
inc
$SINUS       -t $TIME                         500         > ${OUT}_${COUNT2}_iso_500Hz_0db.cdr
inc
$SINUS       -t $TIME                         630         > ${OUT}_${COUNT2}_iso_630Hz_0db.cdr
inc
$SINUS       -t $TIME                         800         > ${OUT}_${COUNT2}_iso_800Hz_0db.cdr
inc
$SINUS       -t $TIME                        1000         > ${OUT}_${COUNT2}_iso_1000Hz_0db.cdr
inc
$SINUS       -t $TIME                        1250         > ${OUT}_${COUNT2}_iso_1250Hz_0db.cdr
inc
$SINUS       -t $TIME                        1600         > ${OUT}_${COUNT2}_iso_1600Hz_0db.cdr
inc
$SINUS       -t $TIME                        2000         > ${OUT}_${COUNT2}_iso_2000Hz_0db.cdr
inc
$SINUS       -t $TIME                        2500         > ${OUT}_${COUNT2}_iso_2500Hz_0db.cdr
inc
$SINUS       -t $TIME                        3150         > ${OUT}_${COUNT2}_iso_3150Hz_0db.cdr
inc
$SINUS       -t $TIME                        4000         > ${OUT}_${COUNT2}_iso_4000Hz_0db.cdr
inc
$SINUS       -t $TIME                        5000         > ${OUT}_${COUNT2}_iso_5000Hz_0db.cdr
inc
$SINUS       -t $TIME                        6300         > ${OUT}_${COUNT2}_iso_6300Hz_0db.cdr
inc
$SINUS       -t $TIME                        8000         > ${OUT}_${COUNT2}_iso_8000Hz_0db.cdr
inc
$SINUS       -t $TIME                       10000         > ${OUT}_${COUNT2}_iso_10000Hz_0db.cdr
inc
$SINUS       -t $TIME                       12500         > ${OUT}_${COUNT2}_iso_12500Hz_0db.cdr
inc
$SINUS       -t $TIME                       16000         > ${OUT}_${COUNT2}_iso_16000Hz_0db.cdr
inc
$SINUS       -t $TIME                       20000         > ${OUT}_${COUNT2}_iso_20000Hz_0db.cdr
inc

$LINEAR      -t $TIME                          20   20000 > ${OUT}_${COUNT2}_linear_20Hz-20000Hz_0db.cdr
inc
$LINEAR      -t $TIME                       20000      20 > ${OUT}_${COUNT2}_linear_20000Hz-20Hz_0db.cdr
inc

$EXPONENTIAL -t $TIME                          20   20000 > ${OUT}_${COUNT2}_exponential_20Hz-20000Hz_0db.cdr
inc
$EXPONENTIAL -t $TIME                       20000      20 > ${OUT}_${COUNT2}_exponential_20000Hz-20Hz_0db.cdr
inc

$WHITE       -t $TIME                                     > ${OUT}_${COUNT2}_white_noise_0db.cdr
inc
$WHITE       -t $TIME -m                                  > ${OUT}_${COUNT2}_white_noise_mono_0db.cdr
inc
$WHITE       -t $TIME -m -p                               > ${OUT}_${COUNT2}_white_noise_mono_phase_0db.cdr
inc

$PINK        -t $TIME                                     > ${OUT}_${COUNT2}_pink_noise_0db.cdr
inc
$PINK        -t $TIME -m                                  > ${OUT}_${COUNT2}_pink_noise_mono_0db.cdr
inc
$PINK        -t $TIME -m -p                               > ${OUT}_${COUNT2}_pink_noise_mono_phase_0db.cdr
inc
