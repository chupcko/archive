#include "config.h"
#include "tool.h"

void help(void)
{
  fprintf
  (
    stderr,
    "exponential -t time -l left -r right -p [ frequency min [ frequency max ] ]\n"
  );
  exit(1);
}

int main(int argc,char *argv[])
{
  int time=60;
  double left=1.0;
  double right=1.0;
  double phase=1.0;
  double fqmin=440.0;
  double fqmax=1000.0;

  int t;
  long r;
  double fend;
  double fx;
  int order;

  int c;
  opterr=0;
  while(1)
  {
    c=getopt(argc,argv,"t:l:r:p");
    if(c==-1)
      break;
    switch(c)
    {
      case 't':
        time=abs(atoi(optarg));
        break;
      case 'l':
        left=fabs(atof(optarg));
        break;
      case 'r':
        right=fabs(atof(optarg));
        break;
      case 'p':
        phase=-1.0;
        break;
      default:
        help();
    }
  }
  if(argc>optind)
  {
    fqmin=fabs(atof(argv[optind]));
    optind++;
    if(argc>optind)
    {
      fqmax=fabs(atof(argv[optind]));
      optind++;
      if(argc>optind)
        help();
    }
  }
  fprintf
  (
    stderr,
    "exponential sweep:\n"
    "\ttime: %d\n"
    "\tleft volume: %f\n"
    "\tright volume: %f\n"
    "\tright phase: %f\n"
    "\tfrequency min: %f\n"
    "\tfrequency max: %f\n",
    time,left,right,phase,fqmin,fqmax
  );

  order=1;
  if(fqmin>fqmax)
  {
    fx=fqmin;
    fqmin=fqmax;
    fqmax=fx;
    order=0;
  }
  fend=fqmax;
  do
  {
    fx=pow(fend,1.0/(time*fqmax));
    fx=1.0/(fqmin*time*(1.0-1.0/fx+1.0/(time*fqmax*fx)));
    fend=(fend+fx)/2.0;
  }
  while(fabs(fend-fx)>0.00000000001);
  if(order)
    for(t=0;t<time;t++)
      for(r=0;r<RATE;r++)
      {
        double n;
        double s;
        n=(double)((long)t*RATE+r);
        s=sin(2.0*M_PI*(fqmin*pow(fend,n/(double)((long)time*RATE)))*n/(double)RATE);
        write_int16(stdout,convert_double_to_int16(left*s),convert_double_to_int16(phase*right*s));
      }
  else
    for(t=time-1;t>=0;t--)
      for(r=RATE-1l;r>=0;r--)
      {
        double n;
        double s;
        n=(double)((long)t*RATE+r);
        s=sin(2.0*M_PI*(fqmin*pow(fend,n/(double)((long)time*RATE)))*n/(double)RATE);
        write_int16(stdout,convert_double_to_int16(left*s),convert_double_to_int16(phase*right*s));
      }
  return 0;
}
