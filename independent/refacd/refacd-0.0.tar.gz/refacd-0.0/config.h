#ifndef CONFIG_H
#define CONFIG_H

#include <getopt.h>
#include <limits.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define RATE 44100l

#endif
