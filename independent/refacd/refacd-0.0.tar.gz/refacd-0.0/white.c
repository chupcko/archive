#include "config.h"
#include "tool.h"

void help(void)
{
  fprintf
  (
    stderr,
    "white -t time -l left -r right -p -m\n"
  );
  exit(1);
}

int main(int argc,char *argv[])
{
  int time=60;
  double left=1.0;
  double right=1.0;
  double phase=1.0;
  int mono=0;

  int t;
  long r;

  int c;
  opterr=0;
  while(1)
  {
    c=getopt(argc,argv,"t:l:r:pm");
    if(c==-1)
      break;
    switch(c)
    {
      case 't':
        time=abs(atoi(optarg));
        break;
      case 'l':
        left=fabs(atof(optarg));
        break;
      case 'r':
        right=fabs(atof(optarg));
        break;
      case 'p':
        phase=-1.0;
        break;
      case 'm':
        mono=1;
        break;
      default:
        help();
    }
  }
  if(argc>optind)
    help();
  fprintf
  (
    stderr,
    "white noise:\n"
    "\ttime: %d\n"
    "\tleft volume: %f\n"
    "\tright volume: %f\n"
    "\tright phase: %f\n"
    "\tmono: %s\n",
    time,left,right,phase,mono?"yes":"no"
  );

  init_double_random();
  for(t=0;t<time;t++)
    for(r=0;r<RATE;r++)
    {
      double s;
      s=double_random();
      if(mono)
        write_int16(stdout,convert_double_to_int16(left*s),convert_double_to_int16(phase*right*s));
      else
        write_int16(stdout,convert_double_to_int16(left*s),convert_double_to_int16(phase*right*double_random()));
    }
  return 0;
}
