#ifndef	_DYPFS_H
#define	_DYPFS_H 1

#define VERSION "0.2"
#define PNAME "dypfs"
#define SOCKET_NAME "/tmp/"PNAME".sock"
#define CONFIGURE_NAME ".configure"
#define CONFIGURE_MODE 0600
#define MODE 0644
#define MAX_FILE 256
#define MAX_PATH 256

#ifdef DEBUG
#define dprintk(format,arg...) printk(KERN_INFO "%s %s: "format"\n",NAME,VERSION ,##arg)
#define dprintf(format,arg...) printf("%s %s: "format"\n",NAME,VERSION ,##arg)
#else
#define dprintk(format,arg...)
#define dprintf(format,arg...)
#endif

#endif
