#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <stdio.h>

#include "dypfs.h"

#define NAME PNAME "d"

void error_exit(char *s)
{
  fprintf(stderr,"%sd: %s error\n",NAME,s);
  exit(1);
}

#define LISTEN_LEN 5

int main(void)
{
  int sd;
  int fd;
  char s[MAX_PATH+1];
  char *socket_name;
  struct sockaddr_un sun;
  struct sockaddr_un fsun;
  int d;
  socket_name=SOCKET_NAME;
  if((sd=socket(PF_UNIX,SOCK_STREAM,0))<0)
    error_exit("socket");
  sun.sun_family=AF_UNIX;
  strcpy(sun.sun_path,socket_name);
  unlink(socket_name);
  d=umask(0);
  if(bind(sd,(struct sockaddr *)&sun,sizeof(sun.sun_family)+strlen(sun.sun_path))<0)
    error_exit("bind");
  umask(d);
  if(listen(sd,LISTEN_LEN)<0)
    error_exit("listen");
  while(1)
  {
    dprintf("Wait to command");
    if((fd=accept(sd,(struct sockaddr *)&fsun,&d))<0)
      error_exit("accept");
    if(fork()==0)
    {
      d=read(fd,s,MAX_PATH);
      s[d]='\0';
      dprintf("Command: %s",s);
      close(1);
      dup(fd);
      execlp(s,s,NULL);
      close(fd);
      exit(1);
    }
    close(fd);
  }
  return 0;
}
