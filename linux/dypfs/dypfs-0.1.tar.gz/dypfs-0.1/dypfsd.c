#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <stdio.h>

#include "dypfs.h"

#define NAME PNAME "d"

void error_exit(char *s)
{
  fprintf(stderr,"%sd: %s\n",NAME,s);
  exit(1);
}

#define LISTEN_LEN 5

int main(void)
{
  int sd;
  int fd;
  char s[MAX_PATH];
  char *socket_name=SOCKET_NAME;
  struct sockaddr_un sun;
  struct sockaddr_un fsun;
  int d;

  if((sd=socket(PF_UNIX,SOCK_STREAM,0))<0)
    error_exit("Ne mogu da socketujem");
  sun.sun_family=AF_UNIX;
  strcpy(sun.sun_path,socket_name);
  unlink(socket_name);
  if(bind(sd,(struct sockaddr *)&sun,sizeof(sun.sun_family)+strlen(sun.sun_path))<0)
    error_exit("Ne mogu da bindujem");
  if(listen(sd,LISTEN_LEN)<0)
    error_exit("Ne mogu da listujem");
  while(1)
  {
    dprintf("Wait to command");
    if((fd=accept(sd,(struct sockaddr *)&fsun,&d))<0)
      error_exit("Ne mogu da listujem");
    if(fork()==0)
    {
      d=read(fd,s,MAX_PATH);
      s[d]='\0';
      dprintf("Command: %s",s);
      close(1);
      dup(fd);
      execlp(s,s,NULL);
      close(fd);
      exit(1);
    }
    close(fd);
  }
  return 0;
}
