#ifndef	_DYPFS_H
#define	_DYPFS_H 1

#define VERSION "0.1"
#define PNAME "dypfs"
#define SOCKET_NAME "/tmp/"PNAME".sock"
#define CONFIGURE ".configure"
#define MODE 0600
#define MAX_PROC_FILE 256
#define MAX_PATH 256

#ifdef DEBUG
#define dprintk(format,arg...) printk(KERN_INFO "%s %s: "format"\n",NAME,VERSION ,##arg)
#define dprintf(format,arg...) printf("%s %s: "format"\n",NAME,VERSION ,##arg)
#else
#define dprintk(format,arg...)
#define dprintf(format,arg...)
#endif

#endif
