#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

#define NAME "/proc/dypfs/dnow"
#define MAX 20

int main(void)
{
  int fd1;
  int fd2;
  char s[MAX];
  int d;
  printf("%lu\n",(unsigned long)s);
  if((fd1=open(NAME,O_RDONLY))<0)
    exit(1);
  if((fd2=open(NAME,O_RDONLY))<0)
    exit(2);
  d=read(fd1,s,MAX);
  s[d]='\0';
  printf("1 %s\n",s);
  d=read(fd2,s,MAX);
  s[d]='\0';
  printf("2 %s\n",s);
  d=read(fd1,s,MAX);
  s[d]='\0';
  printf("1 %s\n",s);
  d=read(fd2,s,MAX);
  s[d]='\0';
  printf("2 %s\n",s);
/*
  sleep(10);
*/
  close(fd1);
  close(fd2);
  return 0;
}
