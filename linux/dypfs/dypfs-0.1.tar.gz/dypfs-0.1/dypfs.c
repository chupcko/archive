#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/proc_fs.h>
#include <linux/string.h>
#include <linux/socket.h>
#include <linux/un.h>
#include <asm/uaccess.h>
#include <asm/unistd.h>

#include "dypfs.h"

#define NAME PNAME

#define MODULE_VERSION VERSION
#define MODULE_NAME NAME

#define BEGIN_KMEM {mm_segment_t old_fs=get_fs();set_fs(KERNEL_DS);
#define END_KMEM set_fs(old_fs);}

extern void* sys_call_table[];

int (*orig_sys_socketcall)(int,unsigned long *);
ssize_t (*orig_sys_read)(int,const void *,size_t);
ssize_t (*orig_sys_write)(int,const void *,size_t);

#define MAX_LEN 65536

struct page_t
{
  char buffer[MAX_LEN];
  loff_t begin;
  size_t end;
  struct page_t *next;
};

struct proc_file_t
{
  struct proc_dir_entry *proc;
  char *file;
  char *exec;
  int sd;
  int nr_sd;
  struct page_t *page;
  struct page_t *last;
  loff_t len;
  int eof;
};

int nr_proc_file;
struct proc_file_t proc_file[MAX_PROC_FILE];

struct proc_dir_entry *p_dir;

int fill_buffer(struct proc_file_t *p)
{
  if(p->eof!=1)
  {
    size_t d;
    if(p->page==NULL)
    {
      if((p->page=kmalloc(sizeof(struct page_t),GFP_KERNEL))==NULL)
        return -EFAULT;
      p->last=p->page;
      p->last->next=NULL;
      p->last->begin=0;
      p->last->end=0;
    }
    else
      if(p->last->end==MAX_LEN)
      {
        if((p->last->next=kmalloc(sizeof(struct page_t),GFP_KERNEL))==NULL)
          return -EFAULT;
        p->last=p->last->next;
        p->last->next=NULL;
        p->last->begin=p->len;
        p->last->end=0;
      }
    BEGIN_KMEM
    d=orig_sys_read(p->sd,p->last->buffer+p->last->end,MAX_LEN-p->last->end);
    END_KMEM
    if(d<0)
      return -EFAULT;
    if(d==0)
      p->eof=1;
    else
    {
      p->last->end+=d;
      p->len+=d;
    }
  }
  dprintk("fill buffer %s",p->file);
  return 0;
}

static ssize_t p_proc_read(struct file *file, char *buf, size_t count, loff_t *ppos)
{
  struct page_t *p;
  loff_t d;
  loff_t i;
  struct proc_file_t *da=(struct proc_file_t *)((struct proc_dir_entry *)file->f_dentry->d_inode->u.generic_ip)->data;
  dprintk("read %s %d %lld",da->file,count,*ppos);
  if(da->nr_sd==0)
    return -EFAULT;
  if(count==0)
    return 0;
  while(da->eof!=1&&*ppos>=da->len)
    if(fill_buffer(da)<0)
      return -EFAULT;
  if(da->eof==1&&*ppos>=da->len)
    return 0;
  if(*ppos+count>da->len)
    d=da->len;
  else
    d=*ppos+count;
  p=da->page;
  if(p==NULL)
    return -EFAULT;
  while(*ppos>=p->begin+p->end)
  {
    if(p==NULL)
      return -EFAULT;
    p=p->next;
  }
  i=0;
  while(*ppos<d)
  {
    if(p==NULL)
      return -EFAULT;
    put_user(p->buffer[*ppos-p->begin],buf++);
    (*ppos)++;
    i++;
    if(*ppos>=p->begin+p->end)
      p=p->next;
  }
  return i;
}

static int p_proc_open(struct inode *inode, struct file *file)
{
  unsigned long a[3];
  struct proc_file_t *da=(struct proc_file_t *)((struct proc_dir_entry *)inode->u.generic_ip)->data;
  struct sockaddr_un sun;
  MOD_INC_USE_COUNT;
  dprintk("open %s",da->file);
  if(da->nr_sd==0)
  {
    ssize_t d;
    a[0]=PF_UNIX;
    a[1]=SOCK_STREAM;
    a[2]=0;
    BEGIN_KMEM
    da->sd=orig_sys_socketcall(SYS_SOCKET,a);
    END_KMEM
    if(da->sd<0)
      return -EFAULT;
    sun.sun_family=AF_UNIX;
    strcpy(sun.sun_path,SOCKET_NAME);
    a[0]=da->sd;
    a[1]=(unsigned long)&sun;
    a[2]=sizeof(sun.sun_family)+strlen(sun.sun_path);
    BEGIN_KMEM
    d=orig_sys_socketcall(SYS_CONNECT,a);
    END_KMEM
    if(d<0)
      return -EFAULT;
    BEGIN_KMEM
    d=orig_sys_write(da->sd,da->exec,strlen(da->exec));
    END_KMEM
    if(d<0)
      return -EFAULT;
    da->page=NULL;
    da->last=NULL;
    da->len=0;
    da->eof=0;
  }
  da->nr_sd++;
  return 0;
}

static int p_proc_release(struct inode *inode, struct file *file)
{
  struct proc_file_t *da=(struct proc_file_t *)((struct proc_dir_entry *)inode->u.generic_ip)->data;
  dprintk("release %s",da->file);
  if(da->nr_sd==0)
    return -EFAULT;
  da->nr_sd--;
  if(da->nr_sd==0)
  {
    struct page_t *p=da->page;
    while(p!=NULL)
    {
      struct page_t *q=p;
      p=p->next;
      kfree(q);
    }
  }
  MOD_DEC_USE_COUNT;
  return 0;
}

static struct file_operations p_proc_fops=
{
  read:
    p_proc_read,
  open:
    p_proc_open,
  release:
    p_proc_release,
};

static int p_proc_read_configure(char *page, char **start, off_t off, int count, int *eof, void *data)
{
  if(off==0)
  {
    int i;
    int len;
    len=snprintf(page,count,"%s %s\n",NAME,VERSION);
    for(i=0;i<nr_proc_file;i++)
    {
      if(len>=count)
        break;
      len+=snprintf(page+len,count-len,"%s\t%s\t%d\n",proc_file[i].file,proc_file[i].exec,proc_file[i].nr_sd);
    }
    return len;
  }
  return 0;
}

static int p_proc_write_configure(struct file *file, const char *buffer, unsigned long count, void *data)
{
  char s[MAX_PATH];
  char *r1;
  char *r2;
  int i;
  int j;
  int l;
  l=0;
  j=0;
  while(buffer[l]!=':'&&l<count)
  {
    if(buffer[l]!='\n')
    {
      s[j]=buffer[l];
      j++;
      if(j>MAX_PATH)
        return -ENOMEM;
    }
    l++;
  }
  if((r1=kmalloc(j+1,GFP_KERNEL))==NULL)
    return -ENOMEM;
  for(i=0;i<j;i++)
    r1[i]=s[i];
  r1[j]='\0';
  l++;
  j=0;
  while(l<count)
  {
    if(buffer[l]!='\n')
    {
      s[j]=buffer[l];
      j++;
      if(j>MAX_PATH)
      {
        kfree(r1);
        return -ENOMEM;
      }
    }
    l++;
  }
  if((r2=kmalloc(j+1,GFP_KERNEL))==NULL)
  {
    kfree(r1);
    return -ENOMEM;
  }
  for(i=0;i<j;i++)
    r2[i]=s[i];
  r2[j]='\0';
  if(r1[0]=='\0')
    return -EFAULT;
  i=0;
  while(i<nr_proc_file&&strcmp(proc_file[i].file,r1))
    i++;
  if(i<nr_proc_file)
  {
    if(proc_file[i].nr_sd>0)
      return -EFAULT;
    if(r2[0]!='\0')
    {
      kfree(proc_file[i].exec);
      proc_file[i].exec=r2;
    }
    else
    {
      remove_proc_entry(proc_file[i].file,p_dir);
      kfree(proc_file[i].file);
      kfree(proc_file[i].exec);
      nr_proc_file--;
      while(i<nr_proc_file)
      {
        proc_file[i].file=proc_file[i+1].file;
        proc_file[i].exec=proc_file[i+1].exec;
        proc_file[i].proc=proc_file[i+1].proc;
        proc_file[i].proc->data=&proc_file[i];
        proc_file[i].sd=proc_file[i+1].sd;
        proc_file[i].nr_sd=proc_file[i+1].nr_sd;
        i++;
      }
    }
  }
  else
    if(r2[0]!='\0')
    {
      if(nr_proc_file==MAX_PROC_FILE)
      {
        kfree(r1);
        kfree(r2);
        return -ENOMEM;
      }
      proc_file[nr_proc_file].file=r1;
      proc_file[nr_proc_file].exec=r2;
      if((proc_file[nr_proc_file].proc=create_proc_entry(r1,MODE,p_dir))==NULL)
      {
        kfree(r1);
        kfree(r2);
        return -ENOMEM;
      }
      proc_file[nr_proc_file].proc->owner=THIS_MODULE;
      proc_file[nr_proc_file].proc->data=&proc_file[nr_proc_file];
      proc_file[nr_proc_file].proc->proc_fops=&p_proc_fops;
      proc_file[nr_proc_file].nr_sd=0;
      nr_proc_file++;
    }
  return count;
}

static int __init init_dypfs(void)
{
  struct proc_dir_entry *p_file;
  orig_sys_socketcall=sys_call_table[__NR_socketcall];
  orig_sys_read=sys_call_table[__NR_read];
  orig_sys_write=sys_call_table[__NR_write];
  if((p_dir=proc_mkdir(NAME, NULL))==NULL)
    return -ENOMEM;
  p_dir->owner=THIS_MODULE;
  if((p_file=create_proc_entry(CONFIGURE,MODE,p_dir))==NULL)
  {
    remove_proc_entry(NAME,NULL);
    return -ENOMEM;
  }
  p_file->owner=THIS_MODULE;
  p_file->read_proc=p_proc_read_configure;
  p_file->write_proc=p_proc_write_configure;
  nr_proc_file=0;
  printk(KERN_INFO "%s %s: inserted\n",NAME,VERSION);
  return 0;
}

static void __exit cleanup_dypfs(void)
{
  int i;
  for(i=0;i<nr_proc_file;i++)
  {
    remove_proc_entry(proc_file[i].file,p_dir);
    kfree(proc_file[i].file);
    kfree(proc_file[i].exec);
  }
  remove_proc_entry(CONFIGURE,p_dir);
  remove_proc_entry(NAME,NULL);
  printk(KERN_INFO "%s %s: removed\n",NAME,VERSION);
}

module_init(init_dypfs);
module_exit(cleanup_dypfs);

MODULE_AUTHOR("Goran \"CHUPCKO\" Lazic");
MODULE_DESCRIPTION("DYnamic Proc File System");
MODULE_LICENSE("PUBLIC DOMAIN");

EXPORT_NO_SYMBOLS;
