#ifndef	_DYPFS_H
#define	_DYPFS_H 1

#define VERSION "0.0"
#define NAME "dypfs"
#define FIFO_NAME_IN "/tmp/dypfs.in"
#define FIFO_NAME_OUT "/tmp/dypfs.out"
#define CONFIGURE ".configure"
#define MODE 0600
#define MAX_PROC_FILE 256
#define MAX_PATH 256

#endif
