typedef int va_list;
