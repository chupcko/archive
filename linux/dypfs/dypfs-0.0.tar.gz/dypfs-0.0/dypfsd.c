#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

#include "dypfs.h"

void error_exit(char *s)
{
  fprintf(stderr,"%sd: %s\n",NAME,s);
  exit(1);
}

int main(void)
{
  int fd;
  int d;
  char s[MAX_PATH];
  struct stat fifo_stat;
  if(stat(FIFO_NAME_IN,&fifo_stat))
  {
    if(mkfifo(FIFO_NAME_IN,MODE))
      error_exit("Ne mogu da napravim fifo.in");
  }
  else
    if(!S_ISFIFO(fifo_stat.st_mode))
      error_exit("Ima ga ali nije fifo.in");
  if(stat(FIFO_NAME_OUT,&fifo_stat))
  {
    if(mkfifo(FIFO_NAME_OUT,MODE))
      error_exit("Ne mogu da napravim fifo.out");
  }
  else
    if(!S_ISFIFO(fifo_stat.st_mode))
      error_exit("Ima ga ali nije fifo.out");
  while(1)
  {
    printf("%sd: Wait to command\n",NAME);
    if((fd=open(FIFO_NAME_IN,O_RDONLY))<0)
      error_exit("Ne mogu da otvorim fifo.in");
    d=read(fd,s,MAX_PATH);
    s[d]='\0';
    printf("%sd: Command: %s\n",NAME,s);
    if(fork()==0)
    {
      close(1);
      if(open(FIFO_NAME_OUT,O_WRONLY)<0)
        error_exit("Ne mogu da otvorim fifo.out");
      execlp(s,s,NULL);
      exit(1);
    }
    printf("%sd: Wait to child\n",NAME);
    wait(&d);
    close(fd);
  }
  return 0;
}
