#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/proc_fs.h>
#include <linux/string.h>
#include <asm/uaccess.h>
#include <asm/unistd.h>

#include "dypfs.h"

#define MODULE_VERSION VERSION
#define MODULE_NAME NAME

#define BEGIN_KMEM {mm_segment_t old_fs=get_fs();set_fs(KERNEL_DS);
#define END_KMEM set_fs(old_fs);}

extern void* sys_call_table[];

int (*orig_sys_open)(const char *,int);
ssize_t (*orig_sys_read)(int,const void *,size_t);
ssize_t (*orig_sys_write)(int,const void *,size_t);
int (*orig_sys_close)(int);

struct proc_file_t
{
  struct proc_dir_entry *proc;
  char *file;
  char *exec;
};

int nr_proc_file;
struct proc_file_t proc_file[MAX_PROC_FILE];

struct proc_dir_entry *p_dir;

int lock=0;
int fd;

static int p_proc_read(char *page, char **start, off_t off, int count, int *eof, void *data)
{
  char s[count];
  struct proc_file_t *d=(struct proc_file_t*)data;
  int r;
  if(off==0)
  {
    while(lock!=0);
    lock=1;
    BEGIN_KMEM
    fd=orig_sys_open(FIFO_NAME_IN,O_WRONLY);
    END_KMEM
    if(fd<0)
    {
      printk(KERN_INFO "%s %s nema fifo.in-a\n",NAME,VERSION);
      return -EFAULT;
    }
    BEGIN_KMEM
    orig_sys_write(fd,d->exec,strlen(d->exec));
    orig_sys_close(fd);
    fd=orig_sys_open(FIFO_NAME_OUT,O_RDONLY);
    END_KMEM
    if(fd<0)
    {
      printk(KERN_INFO "%s %s nema fifo.out-a\n",NAME,VERSION);
      return -EFAULT;
    }
  }
  BEGIN_KMEM
  r=orig_sys_read(fd,s,count);
  END_KMEM
  if(r==0)
  {
    BEGIN_KMEM
    orig_sys_close(fd);
    END_KMEM
    lock=0;
  }
  else
  {
    int i;
    for(i=0;i<r;i++)
      page[off+i]=s[i];
  }
  return off+r;
}

static int p_proc_write(struct file *file, const char *buffer, unsigned long count, void *data)
{
  printk(KERN_INFO "%s %s write\n",NAME,VERSION);
  return count;
}

static int p_proc_read_configure(char *page, char **start, off_t off, int count, int *eof, void *data)
{
  if(!off)
  {
    int i;
    int len;
    len=sprintf(page,"%s %s\n",NAME,VERSION);
    for(i=0;i<nr_proc_file;i++)
      len+=sprintf(page+len,"%s\t%s\n",proc_file[i].file,proc_file[i].exec);
    return len;
  }
  return 0;
}

static int p_proc_write_configure(struct file *file, const char *buffer, unsigned long count, void *data)
{
  char s[MAX_PATH];
  char *r1;
  char *r2;
  int i;
  int j;
  int l;
  l=0;
  j=0;
  while(buffer[l]!=':'&&l<count)
  {
    if(buffer[l]!='\n')
    {
      s[j]=buffer[l];
      j++;
      if(j>MAX_PATH)
        return -ENOMEM;
    }
    l++;
  }
  if((r1=kmalloc(j+1,GFP_KERNEL))==NULL)
    return -ENOMEM;
  for(i=0;i<j;i++)
    r1[i]=s[i];
  r1[j]='\0';

  l++;
  j=0;
  while(l<count)
  {
    if(buffer[l]!='\n')
    {
      s[j]=buffer[l];
      j++;
      if(j>MAX_PATH)
      {
        kfree(r1);
        return -ENOMEM;
      }
    }
    l++;
  }
  if((r2=kmalloc(j+1,GFP_KERNEL))==NULL)
  {
    kfree(r1);
    return -ENOMEM;
  }
  for(i=0;i<j;i++)
    r2[i]=s[i];
  r2[j]='\0';

  if(r1[0]=='\0')
    return -EFAULT;

  if(r2[0]!='\0')
  {
    i=0;
    while(i<nr_proc_file&&strcmp(proc_file[i].file,r1))
      i++;
    if(i<nr_proc_file)
    {
      kfree(proc_file[i].exec);
      proc_file[i].exec=r2;
    }
    else
    {
      if(nr_proc_file==MAX_PROC_FILE)
      {
        kfree(r1);
        kfree(r2);
        return -ENOMEM;
      }
      proc_file[nr_proc_file].file=r1;
      proc_file[nr_proc_file].exec=r2;
      if((proc_file[nr_proc_file].proc=create_proc_entry(r1,MODE,p_dir))==NULL)
      {
        kfree(r1);
        kfree(r2);
        return -ENOMEM;
      }
      proc_file[nr_proc_file].proc->owner=THIS_MODULE;
      proc_file[nr_proc_file].proc->data=&proc_file[nr_proc_file];
      proc_file[nr_proc_file].proc->read_proc=p_proc_read;
      proc_file[nr_proc_file].proc->write_proc=p_proc_write;
      nr_proc_file++;
    }
  }
  else
  {
    i=0;
    while(i<nr_proc_file&&strcmp(proc_file[i].file,r1))
      i++;
    if(i<nr_proc_file)
    {
      remove_proc_entry(proc_file[i].file,p_dir);
      kfree(proc_file[i].file);
      kfree(proc_file[i].exec);
      nr_proc_file--;
      while(i<nr_proc_file)
      {
        proc_file[i].proc=proc_file[i+1].proc;
        proc_file[i].proc->data=&proc_file[i];
        proc_file[i].file=proc_file[i+1].file;
        proc_file[i].exec=proc_file[i+1].exec;
        i++;
      }
    }
  }
  return count;
}

static int __init init_dypfs(void)
{
  struct proc_dir_entry *p_file;
  orig_sys_open=sys_call_table[__NR_open];
  orig_sys_read=sys_call_table[__NR_read];
  orig_sys_write=sys_call_table[__NR_write];
  orig_sys_close=sys_call_table[__NR_close];
  if((p_dir=proc_mkdir(NAME, NULL))==NULL)
    return -ENOMEM;
  p_dir->owner=THIS_MODULE;
  if((p_file=create_proc_entry(CONFIGURE,MODE,p_dir))==NULL)
  {
    remove_proc_entry(NAME,NULL);
    return -ENOMEM;
  }
  p_file->owner=THIS_MODULE;
  p_file->read_proc=p_proc_read_configure;
  p_file->write_proc=p_proc_write_configure;
  nr_proc_file=0;
  printk(KERN_INFO "%s %s inserted\n",NAME,VERSION);
  return 0;
}

static void __exit cleanup_dypfs(void)
{
  int i;
  for(i=0;i<nr_proc_file;i++)
  {
    remove_proc_entry(proc_file[i].file,p_dir);
    kfree(proc_file[i].file);
    kfree(proc_file[i].exec);
  }
  remove_proc_entry(CONFIGURE,p_dir);
  remove_proc_entry(NAME,NULL);
  printk(KERN_INFO "%s %s removed\n",NAME,VERSION);
}

module_init(init_dypfs);
module_exit(cleanup_dypfs);

MODULE_AUTHOR("Goran \"CHUPCKO\" Lazic");
MODULE_DESCRIPTION("dynamic proc file system");
MODULE_LICENSE("PUBLIC DOMAIN");

EXPORT_NO_SYMBOLS;
